import { setLocale, getLocale } from '@vue-lowcode/utils';

export { setLocale, getLocale };

export * from './en-US';
export * from './zh-CN';
