/**
 * Vue3 LowCode Engine - Utils Package
 * 原型获取相关工具
 */

export const getPrototypeOf = Object.getPrototypeOf;
