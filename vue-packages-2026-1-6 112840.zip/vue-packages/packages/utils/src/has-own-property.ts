/**
 * Vue3 LowCode Engine - Utils Package
 * 属性检查相关工具
 */

export const hasOwnProperty = Object.prototype.hasOwnProperty;
