/**
 * Vue3 LowCode Engine - Utils Package
 * 原型设置相关工具
 */

export const setPrototypeOf = Object.setPrototypeOf;
