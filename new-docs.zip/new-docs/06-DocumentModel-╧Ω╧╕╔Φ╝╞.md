# DocumentModel 模块详细设计

## 1. 模块概述

### 1.1 功能定位

DocumentModel 是 LowCodeEngine 的文档模型模块，负责管理单个文档（页面）的节点树、选择器、历史记录等核心功能。它是设计器中最重要的模型层，提供统一的文档操作接口。

### 1.2 核心职责

1. **节点树管理**：管理文档中的所有节点及其层级关系
2. **选择器管理**：管理当前选中的节点
3. **历史记录管理**：提供撤销/重做功能
4. **节点创建与销毁**：节点的创建、删除、销毁
5. **Schema导入导出**：文档Schema的导入和导出
6. **嵌套规则验证**：验证节点嵌套是否符合规则
7. **模态节点管理**：管理模态框节点
8. **拖拽位置管理**：管理拖拽投放位置

### 1.3 在整体架构中的位置

```
┌─────────────────────────────────────────────────────────────┐
│                    应用层 (Application)                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │   插件系统    │  │   面板组件    │  │   自定义扩展   │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                     Shell层 (Shell)                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Editor Core                             │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                   核心层 (Core)                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Designer                               │  │
│  │  ┌──────────────────────────────────────────────┐  │  │
│  │  │          Project                             │  │  │
│  │  └──────────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                   文档层 (Document)                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │        DocumentModel (本模块)              │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  │  │
│  │  │  Node    │  │Selection │  │ History  │  │  │
│  │  └──────────┘  └──────────┘  └──────────┘  │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  │  │
│  │  │   Props  │  │  Dragon  │  │  Modal   │  │  │
│  │  └──────────┘  └──────────┘  └──────────┘  │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## 2. 核心设计与实现

### 2.1 核心类/组件结构图

```mermaid
classDiagram
    class DocumentModel {
        -rootNode: IRootNode
        -id: string
        -selection: ISelection
        -history: IHistory
        -modalNodesManager: IModalNodesManager
        -nodes: Set~INode~
        -nodesMap: Map~string, INode~
        +createNode()
        +removeNode()
        +insertNode()
        +import()
        +export()
        +checkNesting()
        +getNode()
    }
    
    class Node {
        -id: string
        -componentName: string
        -props: IProps
        -_children: INodeChildren
        -_parent: INode
        +remove()
        +insertBefore()
        +insertAfter()
        +export()
        +import()
        +contains()
    }
    
    class Selection {
        -selected: string[]
        +select()
        +getTopNodes()
        +clear()
        +has()
    }
    
    class History {
        -data: any[]
        -cursor: number
        -state: HistoryState
        +record()
        +undo()
        +redo()
        +isSavePoint()
    }
    
    class Props {
        -node: INode
        -props: Map~string, IProp~
        +get()
        +set()
        +merge()
        +export()
        +import()
    }
    
    class ModalNodesManager {
        -document: IDocumentModel
        -modalNodes: INode[]
        +add()
        +remove()
        +get()
    }
    
    DocumentModel --> Node
    DocumentModel --> Selection
    DocumentModel --> History
    DocumentModel --> ModalNodesManager
    Node --> Props
    Node --> NodeChildren
```

### 2.2 DocumentModel 类详解

#### 2.2.1 类定义

**源文件**: [`packages/designer/src/document/document-model.ts`](packages/designer/src/document/document-model.ts:156)

```typescript
export class DocumentModel implements IDocumentModel {
  /**
   * 根节点 类型有：Page/Component/Block
   */
  rootNode: IRootNode | null;

  /**
   * 文档编号
   */
  id: string = uniqueId('doc');

  /**
   * 选区控制
   */
  readonly selection: ISelection = new Selection(this);

  /**
   * 操作记录控制
   */
  readonly history: IHistory;

  /**
   * 模态节点管理
   */
  modalNodesManager: IModalNodesManager;

  private _nodesMap = new Map<string, INode>();

  readonly project: IProject;

  readonly designer: IDesigner;

  @obx.shallow private nodes = new Set<INode>();

  private seqId = 0;

  private emitter: IEventBus;

  private rootNodeVisitorMap: { [visitorName: string]: any } = {};

  /**
   * 模拟器
   */
  get simulator(): ISimulatorHost | null {
    return this.project.simulator;
  }

  get nodesMap(): Map<string, INode> {
    return this._nodesMap;
  }

  get fileName(): string {
    return this.rootNode?.getExtraProp('fileName', false)?.getAsString() || this.id;
  }

  set fileName(fileName: string) {
    this.rootNode?.getExtraProp('fileName', true)?.setValue(fileName);
  }

  get focusNode(): INode | null {
    if (this._drillDownNode) {
      return this._drillDownNode;
    }
    const selector = engineConfig.get('focusNodeSelector');
    if (selector && typeof selector === 'function') {
      return selector(this.rootNode!);
    }
    return this.rootNode;
  }

  @obx.ref private _drillDownNode: INode | null = null;

  private _modalNode?: INode;

  private _blank?: boolean;

  private inited = false;

  @obx.shallow private willPurgeSpace: INode[] = [];

  @obx.shallow private activeNodes?: INode[];

  @obx.ref private _dropLocation: IDropLocation | null = null;

  set dropLocation(loc: IDropLocation | null) {
    this._dropLocation = loc;
    this.designer.editor.eventBus.emit(
      'document.dropLocation.changed',
      { document: this, location: loc },
    );
  }

  /**
   * 投放插入位置标记
   */
  get dropLocation() {
    return this._dropLocation;
  }

  /**
   * 导出 schema 数据
   */
  get schema(): IPublicTypeRootSchema {
    return this.rootNode?.schema as any;
  }

  @obx.ref private _opened = false;

  @obx.ref private _suspensed = false;

  /**
   * 是否为非激活状态
   */
  get suspensed(): boolean {
    return this._suspensed || !this._opened;
  }

  /**
   * 与 suspensed 相反，是否为激活状态，这个函数可能用的更多一点
   */
  get active(): boolean {
    return !this._suspensed;
  }

  /**
   * 是否打开
   */
  get opened() {
    return this._opened;
  }

  get root() {
    return this.rootNode;
  }

  constructor(project: IProject, schema?: IPublicTypeRootSchema) {
    makeObservable(this);
    this.project = project;
    this.designer = this.project?.designer;
    this.emitter = createModuleEventBus('DocumentModel');

    if (!schema) {
      this._blank = true;
    }

    // 兼容 vision
    this.id = project.getSchema()?.id || this.id;

    this.rootNode = this.createNode(
      schema || {
        componentName: 'Page',
        id: 'root',
        fileName: '',
      },
    );

    this.history = new History(
      () => this.export(IPublicEnumTransformStage.Serilize),
      (schema) => {
        this.import(schema as IPublicTypeRootSchema, true);
        this.simulator?.rerender();
      },
      this,
    );

    this.setupListenActiveNodes();
    this.modalNodesManager = new ModalNodesManager(this);
    this.inited = true;
  }
}
```

#### 2.2.2 关键方法详解

##### 2.2.2.1 createNode() - 创建节点

**源码位置**: [`packages/designer/src/document/document-model.ts:427-469`](packages/designer/src/document/document-model.ts:427)

```typescript
@action
createNode<T extends INode = INode, C = undefined>(data: GetDataType<C, T>): T {
  let schema: any;
  if (isDOMText(data) || isJSExpression(data)) {
    schema = {
      componentName: 'Leaf',
      children: data,
    };
  } else {
    schema = data;
  }

  let node: INode | null = null;
  if (this.hasNode(schema?.id)) {
    schema.id = null;
  }
  /* istanbul ignore next */
  if (schema.id) {
    node = this.getNode(schema.id);
    // TODO: 底下这几段代码似乎永远都进不去
    if (node && node.componentName === schema.componentName) {
      if (node.parent) {
        node.internalSetParent(null, false);
        // will move to another position
        // todo: this.activeNodes?.push(node);
      }
      node.import(schema, true);
    } else if (node) {
      node = null;
    }
  }
  if (!node) {
    node = new Node(this, schema);
    // will add
    // todo: this.activeNodes?.push(node);
  }

  this._nodesMap.set(node.id, node);
  this.nodes.add(node);

  this.emitter.emit('nodecreate', node);
  return node as any;
}
```

**实现逻辑**:
1. 处理DOM文本或JS表达式，转换为Leaf节点
2. 检查节点ID是否已存在，如果存在则重新生成ID
3. 尝试从现有节点中查找（这部分代码似乎不会执行）
4. 如果找不到现有节点，创建新节点
5. 将节点添加到节点映射和节点集合
6. 发布节点创建事件
7. 返回节点实例

**使用示例**:
```typescript
// 创建普通节点
const node = document.createNode({
  componentName: 'Button',
  props: {
    type: 'primary',
    children: 'Click me'
  }
});

// 创建文本节点
const textNode = document.createNode('Hello World');

// 创建表达式节点
const exprNode = document.createNode({
  type: 'JSExpression',
  value: 'this.state.count'
});
```

##### 2.2.2.2 removeNode() - 移除节点

**源码位置**: [`packages/designer/src/document/document-model.ts:492-506`](packages/designer/src/document/document-model.ts:492)

```typescript
removeNode(idOrNode: string | INode) {
  let id: string;
  let node: INode | null = null;
  if (typeof idOrNode === 'string') {
    id = idOrNode;
    node = this.getNode(id);
  } else if (idOrNode.id) {
    id = idOrNode.id;
    node = this.getNode(id);
  }
  if (!node) {
    return;
  }
  this.internalRemoveAndPurgeNode(node, true);
}
```

**实现逻辑**:
1. 处理输入参数，支持字符串或节点对象
2. 根据ID获取节点
3. 如果节点不存在，直接返回
4. 调用内部方法移除和销毁节点

**使用示例**:
```typescript
// 按ID移除
document.removeNode('node_123');

// 按节点对象移除
document.removeNode(nodeInstance);
```

##### 2.2.2.3 import() - 导入Schema

**源码位置**: [`packages/designer/src/document/document-model.ts:545-561`](packages/designer/src/document/document-model.ts:545)

```typescript
@action
import(schema: IPublicTypeRootSchema, checkId = false) {
  const drillDownNodeId = this._drillDownNode?.id;
  runWithGlobalEventOff(() => {
    // TODO: 暂时用饱和式删除，原因是 Slot 节点并不是树节点，无法正常递归删除
    this.nodes.forEach(node => {
      if (node.isRoot()) return;
      this.internalRemoveAndPurgeNode(node, true);
    });
    this.rootNode?.import(schema as any, checkId);
    this.modalNodesManager = new ModalNodesManager(this);
    // todo: select added and active track added
    if (drillDownNodeId) {
      this.drillDown(this.getNode(drillDownNodeId));
    }
  });
}
```

**实现逻辑**:
1. 保存当前下钻节点ID
2. 关闭全局事件（避免触发大量事件）
3. 饱和式删除所有非根节点（包括Slot节点）
4. 导入新的Schema到根节点
5. 重新创建模态节点管理器
6. 恢复下钻节点
7. 恢复全局事件

**使用示例**:
```typescript
// 导入完整Schema
document.import({
  componentName: 'Page',
  id: 'page1',
  props: {},
  children: [
    {
      componentName: 'Button',
      props: { type: 'primary' }
    }
  ]
});

// 导入时不检查ID
document.import(schema, false);
```

##### 2.2.2.4 export() - 导出Schema

**源码位置**: [`packages/designer/src/document/document-model.ts:563-577`](packages/designer/src/document/document-model.ts:563)

```typescript
export(stage: IPublicEnumTransformStage = IPublicEnumTransformStage.Serilize): IPublicTypeRootSchema | undefined {
  stage = compatStage(stage);
  // 置顶只作用于 Page 的第一级子节点，目前还用不到里层的置顶；如果后面有需要可以考虑将这段写到 node-children 中的 export
  const currentSchema = this.rootNode?.export<IPublicTypeRootSchema>(stage);
  if (Array.isArray(currentSchema?.children) && currentSchema?.children?.length && currentSchema?.children?.length > 0) {
    const FixedTopNodeIndex = currentSchema?.children
      .filter(i => isPlainObject(i))
      .findIndex((i => (i as IPublicTypeNodeSchema).props?.__isTopFixed__));
    if (FixedTopNodeIndex > 0) {
      const FixedTopNode = currentSchema?.children.splice(FixedTopNodeIndex, 1);
      currentSchema?.children.unshift(FixedTopNode[0]);
    }
  }
  return currentSchema;
}
```

**实现逻辑**:
1. 兼容处理转换阶段
2. 导出根节点的Schema
3. 处理置顶节点（`__isTopFixed__`属性）
4. 将置顶节点移到子节点数组首位
5. 返回完整的Schema

**使用示例**:
```typescript
// 导出保存阶段的Schema
const schema = document.export(IPublicEnumTransformStage.Save);

// 导出渲染阶段的Schema
const renderSchema = document.export(IPublicEnumTransformStage.Render);

// 导出序列化阶段的Schema
const serilizeSchema = document.export(IPublicEnumTransformStage.Serilize);
```

##### 2.2.2.5 checkNesting() - 检查嵌套规则

**源码位置**: [`packages/designer/src/document/document-model.ts:673-689`](packages/designer/src/document/document-model.ts:673)

```typescript
checkNesting(
  dropTarget: INode,
  dragObject: IPublicTypeDragNodeObject | IPublicTypeNodeSchema | INode | IPublicTypeDragNodeDataObject,
): boolean {
  let items: Array<INode | IPublicTypeNodeSchema>;
  if (isDragNodeDataObject(dragObject)) {
    items = Array.isArray(dragObject.data) ? dragObject.data : [dragObject.data];
  } else if (isDragNodeObject<INode>(dragObject)) {
    items = dragObject.nodes;
  } else if (isNode<INode>(dragObject) || isNodeSchema(dragObject)) {
    items = [dragObject];
  } else {
    console.warn('the dragObject is not in the correct type, dragObject:', dragObject);
    return true;
  }
  return items.every((item) => this.checkNestingDown(dropTarget, item) && this.checkNestingUp(dropTarget, item));
}
```

**实现逻辑**:
1. 处理不同类型的拖拽对象
2. 将拖拽对象转换为节点或Schema数组
3. 检查每个项目的向下嵌套规则（父节点对子节点的要求）
4. 检查每个项目的向上嵌套规则（子节点对父节点的要求）
5. 所有项目都通过检查才返回true

**使用示例**:
```typescript
// 检查单个节点是否可以嵌套
const canNest = document.checkNesting(parentNode, childNode);

// 检查多个节点是否可以嵌套
const canNestMultiple = document.checkNesting(parentNode, {
  type: 'drag-node-data',
  data: [node1, node2]
});

// 检查Schema是否可以嵌套
const canNestSchema = document.checkNesting(parentNode, {
  componentName: 'Button',
  props: {}
});
```

##### 2.2.2.6 getNode() - 获取节点

**源码位置**: [`packages/designer/src/document/document-model.ts:397-399`](packages/designer/src/document/document-model.ts:397)

```typescript
getNode(id: string): INode | null {
  return this._nodesMap.get(id) || null;
}
```

**实现逻辑**:
- 从节点映射中查找节点
- 如果不存在返回null

**使用示例**:
```typescript
const node = document.getNode('node_123');
if (node) {
  console.log('Node found:', node.componentName);
}
```

##### 2.2.2.7 insertNode() - 插入节点

**源码位置**: [`packages/designer/src/document/document-model.ts:478-480`](packages/designer/src/document/document-model.ts:478)

```typescript
insertNode(parent: INode, thing: INode | IPublicTypeNodeData, at?: number | null, copy?: boolean): INode | null {
  return insertChild(parent, thing, at, copy);
}
```

**实现逻辑**:
- 调用insertChild工具函数
- 支持指定插入位置
- 支持复制模式

**使用示例**:
```typescript
// 在父节点末尾插入
document.insertNode(parentNode, newNode);

// 在指定位置插入
document.insertNode(parentNode, newNode, 2);

// 插入Schema
document.insertNode(parentNode, {
  componentName: 'Button',
  props: {}
});

// 复制插入
document.insertNode(parentNode, existingNode, null, true);
```

##### 2.2.2.8 insertNodes() - 插入多个节点

**源码位置**: [`packages/designer/src/document/document-model.ts:485-487`](packages/designer/src/document/document-model.ts:485)

```typescript
insertNodes(parent: INode, thing: INode[] | IPublicTypeNodeData[], at?: number | null, copy?: boolean) {
  return insertChildren(parent, thing, at, copy);
}
```

**实现逻辑**:
- 调用insertChildren工具函数
- 支持批量插入
- 节点按倒序插入（保持相对顺序）

**使用示例**:
```typescript
// 批量插入节点
document.insertNodes(parentNode, [node1, node2, node3]);

// 批量插入Schema
document.insertNodes(parentNode, [
  { componentName: 'Button', props: {} },
  { componentName: 'Input', props: {} }
]);
```

##### 2.2.2.9 open() - 打开文档

**源码位置**: [`packages/designer/src/document/document-model.ts:635-647`](packages/designer/src/document/document-model.ts:635)

```typescript
open(): DocumentModel {
  const originState = this._opened;
  this._opened = true;
  if (originState === false) {
    this.designer.postEvent('document-open', this);
  }
  if (this._suspensed) {
    this.setSuspense(false);
  } else {
    this.project.checkExclusive(this);
  }
  return this;
}
```

**实现逻辑**:
1. 保存原始状态
2. 设置打开状态为true
3. 如果之前是关闭状态，发布文档打开事件
4. 如果之前是挂起状态，取消挂起
5. 否则，检查文档独占性
6. 返回当前文档实例

**使用示例**:
```typescript
// 打开文档
document.open();

// 监听文档打开事件
designer.emitter.on('document-open', (doc) => {
  console.log('Document opened:', doc.fileName);
});
```

##### 2.2.2.10 close() - 关闭文档

**源码位置**: [`packages/designer/src/document/document-model.ts:652-656`](packages/designer/src/document/document-model.ts:652)

```typescript
close(): void {
  this.setSuspense(true);
  this._opened = false;
}
```

**实现逻辑**:
1. 设置挂起状态
2. 设置打开状态为false

**使用示例**:
```typescript
// 关闭文档
document.close();
```

##### 2.2.2.11 remove() - 移除文档

**源码位置**: [`packages/designer/src/document/document-model.ts:660-664`](packages/designer/src/document/document-model.ts:660)

```typescript
remove() {
  this.designer.postEvent('document.remove', { id: this.id });
  this.purge();
  this.project.removeDocument(this);
}
```

**实现逻辑**:
1. 发布文档移除事件
2. 清理文档资源
3. 从项目中移除文档

**使用示例**:
```typescript
// 移除文档
document.remove();
```

##### 2.2.2.12 getComponentsMap() - 获取组件映射

**源码位置**: [`packages/designer/src/document/document-model.ts:825-867`](packages/designer/src/document/document-model.ts:825)

```typescript
getComponentsMap(extraComps?: string[]) {
  const componentsMap: IPublicTypeComponentsMap = [];
  // 组件去重
  const exsitingMap: { [componentName: string]: boolean } = {};
  for (const node of this._nodesMap.values()) {
    const { componentName } = node || {};
    if (componentName === 'Slot') continue;
    if (!exsitingMap[componentName]) {
      exsitingMap[componentName] = true;
      if (node.componentMeta?.npm?.package) {
        componentsMap.push({
          ...node.componentMeta.npm,
          componentName,
        });
      } else {
        componentsMap.push({
          devMode: 'lowCode',
          componentName,
        });
      }
    }
  }
  // 合并外界传入的自定义渲染的组件
  if (Array.isArray(extraComps)) {
    extraComps.forEach((componentName) => {
      if (componentName && !exsitingMap[componentName]) {
        const meta = this.getComponentMeta(componentName);
        if (meta?.npm?.package) {
          componentsMap.push({
            ...meta?.npm,
            componentName,
          });
        } else {
          componentsMap.push({
            devMode: 'lowCode',
            componentName,
          });
        }
      }
    });
  }
  return componentsMap;
}
```

**实现逻辑**:
1. 遍历所有节点
2. 跳过Slot节点
3. 去重组件名称
4. 根据组件元数据生成组件映射
5. 支持外部传入额外组件
6. 返回组件映射数组

**使用示例**:
```typescript
// 获取文档中的所有组件
const componentsMap = document.getComponentsMap();

// 获取组件映射并包含额外组件
const componentsMap = document.getComponentsMap(['CustomComponent']);
```

### 2.3 节点树管理机制

#### 2.3.1 节点存储结构

**实现方式**: 使用Map和Set双重存储

**核心代码**:
```typescript
private _nodesMap = new Map<string, INode>();
@obx.shallow private nodes = new Set<INode>();
```

**特点**:
- `nodesMap`: 按ID快速查找节点
- `nodes`: 响应式节点集合，用于遍历
- 双重存储兼顾查找和响应式需求

#### 2.3.2 节点ID生成

**实现方式**: 基于文档ID和序列号生成唯一ID

**核心代码**:
```typescript
private seqId = 0;

nextId(possibleId: string | undefined): string {
  let id = possibleId;
  while (!id || this.nodesMap.get(id)) {
    id = `node_${(String(this.id).slice(-10) + (++this.seqId).toString(36)).toLocaleLowerCase()}`;
  }
  return id;
}
```

**特点**:
- 使用文档ID后10位 + 序列号（36进制）
- 确保ID唯一性
- 自动处理ID冲突

#### 2.3.3 节点生命周期

**生命周期流程**:
```
createNode()
    ↓
添加到 nodesMap 和 nodes
    ↓
发布 nodecreate 事件
    ↓
节点被使用
    ↓
removeNode()
    ↓
internalRemoveAndPurgeNode()
    ↓
节点从父节点移除
    ↓
purge()
    ↓
发布 nodedestroy 事件
    ↓
从 nodesMap 和 nodes 移除
```

### 2.4 历史记录管理

#### 2.4.1 History类定义

**源文件**: [`packages/designer/src/document/history.ts`](packages/designer/src/document/history.ts)

```typescript
export class History implements IHistory {
  readonly document: IDocumentModel;
  private data: any[] = [];
  private cursor: number = -1;
  private state: HistoryState = 'idle';
  private savePoint: number = -1;
  private emitter: IEventBus;
  
  constructor(
    document: IDocumentModel,
    getData: () => any,
    setData: (data: any) => void,
  ) {
    this.document = document;
    this.emitter = createModuleEventBus('History');
    this.getData = getData;
    this.setData = setData;
    this.record();
  }
}
```

#### 2.4.2 历史记录工作流程

**记录状态**:
```
用户操作
    ↓
触发 record()
    ↓
获取当前数据
    ↓
删除后续状态（如果不在最新位置）
    ↓
添加新状态
    ↓
移动 cursor
    ↓
限制历史记录数量
    ↓
发布 change 事件
```

**撤销操作**:
```
用户点击撤销
    ↓
触发 undo()
    ↓
检查状态（必须是 idle）
    ↓
检查是否可以撤销（cursor > 0）
    ↓
设置状态为 undoing
    ↓
移动 cursor 到上一个状态
    ↓
恢复数据
    ↓
设置状态为 idle
    ↓
发布 change 事件
```

**重做操作**:
```
用户点击重做
    ↓
触发 redo()
    ↓
检查状态（必须是 idle）
    ↓
检查是否可以重做（cursor < length - 1）
    ↓
设置状态为 redoing
    ↓
移动 cursor 到下一个状态
    ↓
恢复数据
    ↓
设置状态为 idle
    ↓
发布 change 事件
```

### 2.5 选择器管理

#### 2.5.1 Selection类定义

**源文件**: [`packages/designer/src/document/selection.ts`](packages/designer/src/document/selection.ts)

```typescript
export class Selection implements ISelection {
  readonly document: IDocumentModel;
  @obx.shallow private selected: string[] = [];
  private emitter: IEventBus;
  
  constructor(document: IDocumentModel) {
    this.document = document;
    this.emitter = createModuleEventBus('Selection');
  }
}
```

#### 2.5.2 选择器工作流程

**选择节点**:
```
调用 select(id)
    ↓
清空选择（如果 clear = true）
    ↓
添加节点ID到选择列表
    ↓
发布 change 事件
```

**获取顶层节点**:
```
调用 getTopNodes()
    ↓
根据ID获取所有节点
    ↓
过滤掉被其他节点包含的节点
    ↓
返回顶层节点列表
```

## 3. 交互与通信

### 3.1 模块内部数据流向

```
┌─────────────────────────────────────────────────────────────┐
│              DocumentModel 内部数据流                      │
│                                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐  │  │
│  │  │  nodesMap   │  │   nodes     │  │  │
│  │  │   (Map)     │  │   (Set)     │  │  │
│  │  └──────────────┘  └──────────────┘  │  │
│  │                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐  │  │
│  │  │  rootNode   │  │  selection  │  │  │
│  │  └──────────────┘  └──────────────┘  │  │
│  │                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐  │  │
│  │  │   history   │  │modalNodesMgr│  │  │
│  │  └──────────────┘  └──────────────┘  │  │
│  │                                        │  │
│  └──────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

### 3.2 与其他模块的具体交互方式

#### 3.2.1 与Project交互

**交互方式**: Project创建和管理DocumentModel

**代码示例**:
```typescript
// Project中创建DocumentModel
const doc = new DocumentModel(this, schema);
this.documents.push(doc);

// Project中移除DocumentModel
this.documents.splice(index, 1);
this.documentsMap.delete(doc.id);
```

**API引用**:
- [`project.createDocument()`](packages/designer/src/project/project.ts:301) - 创建文档
- [`project.open()`](packages/designer/src/project/project.ts:309) - 打开文档
- [`project.removeDocument()`](packages/designer/src/project/project.ts:252) - 移除文档

#### 3.2.2 与Node交互

**交互方式**: DocumentModel创建和管理Node

**代码示例**:
```typescript
// 创建节点
const node = document.createNode({
  componentName: 'Button',
  props: {}
});

// 获取节点
const node = document.getNode('node_123');

// 移除节点
document.removeNode('node_123');
```

**API引用**:
- [`document.createNode()`](packages/designer/src/document/document-model.ts:427) - 创建节点
- [`document.getNode()`](packages/designer/src/document/document-model.ts:397) - 获取节点
- [`document.removeNode()`](packages/designer/src/document/document-model.ts:492) - 移除节点

#### 3.2.3 与Selection交互

**交互方式**: DocumentModel包含Selection实例

**代码示例**:
```typescript
// 获取选择器
const selection = document.selection;

// 选择节点
selection.select('node_123');

// 获取顶层节点
const topNodes = selection.getTopNodes();
```

**API引用**:
- [`document.selection`](packages/designer/src/document/document-model.ts:170) - 选择器实例
- [`selection.select()`](packages/designer/src/document/selection.ts) - 选择节点
- [`selection.getTopNodes()`](packages/designer/src/document/selection.ts) - 获取顶层节点

#### 3.2.4 与History交互

**交互方式**: DocumentModel包含History实例

**代码示例**:
```typescript
// 获取历史记录
const history = document.history;

// 记录状态
history.record();

// 撤销
history.undo();

// 重做
history.redo();
```

**API引用**:
- [`document.history`](packages/designer/src/document/document-model.ts:175) - 历史记录实例
- [`history.record()`](packages/designer/src/document/history.ts) - 记录状态
- [`history.undo()`](packages/designer/src/document/history.ts) - 撤销
- [`history.redo()`](packages/designer/src/document/history.ts) - 重做

#### 3.2.5 与Simulator交互

**交互方式**: 通过Project获取Simulator

**代码示例**:
```typescript
// 获取模拟器
const simulator = document.simulator;

// 重新渲染
simulator.rerender();

// 获取组件实例
const instances = simulator.getComponentInstances(node);
```

**API引用**:
- [`document.simulator`](packages/designer/src/document/document-model.ts:204) - 模拟器实例
- [`simulator.rerender()`](packages/designer/src/simulator) - 重新渲染

## 4. 依赖关系

### 4.1 外部库依赖

| 依赖包 | 版本 | 用途 |
|--------|------|------|
| `@alilc/lowcode-editor-core` | ^1.1.0 | 编辑器核心（EventBus、Config等） |
| `@alilc/lowcode-types` | ^1.3.2 | 类型定义 |
| `@alilc/lowcode-utils` | ^1.3.2 | 工具函数 |
| `mobx` | ^6.3.0 | 响应式状态管理 |

### 4.2 内部模块依赖

| 模块 | 依赖方式 | 用途 |
|------|---------|------|
| `Node` | 直接导入 | 节点模型 |
| `Selection` | 直接导入 | 选择器 |
| `History` | 直接导入 | 历史记录 |
| `ModalNodesManager` | 直接导入 | 模态节点管理 |
| `Project` | 构造函数参数 | 项目实例 |
| `Designer` | 通过Project | 设计器实例 |

### 4.3 依赖关系图

```mermaid
graph TD
    DocumentModel[DocumentModel] --> Node[Node]
    DocumentModel --> Selection[Selection]
    DocumentModel --> History[History]
    DocumentModel --> ModalNodesManager[ModalNodesManager]
    DocumentModel --> Project[Project]
    
    Project --> Designer[Designer]
    Designer --> EditorCore[Editor Core]
    
    Node --> Props[Props]
    Node --> NodeChildren[NodeChildren]
    Node --> ComponentMeta[ComponentMeta]
    
    Selection --> EditorCore[Editor Core]
    History --> EditorCore[Editor Core]
```

## 5. 关键技术点

### 5.1 应用的设计模式

#### 5.1.1 组合模式（Composite Pattern）

**实现方式**: Node树形结构

**代码示例**:
```typescript
class Node {
  private _children?: INodeChildren;
  
  get children(): INodeChildren | null {
    return this._children || null;
  }
  
  contains(node: INode): boolean {
    return contains(this, node);
  }
}

function contains(node1: INode, node2: INode): boolean {
  if (node1 === node2) {
    return true;
  }
  if (!node1.isParentalNode || !node2.parent) {
    return false;
  }
  const p = getZLevelTop(node2, node1.zLevel);
  if (!p) {
    return false;
  }
  return node1 === p;
}
```

**优势**:
- 统一处理单个节点和节点树
- 便于遍历和操作
- 支持递归操作

#### 5.1.2 命令模式（Command Pattern）

**实现方式**: History记录和执行操作

**代码示例**:
```typescript
class History {
  private data: any[] = [];
  private cursor: number = -1;
  
  record(): void {
    if (this.state !== 'idle') {
      return;
    }
    const data = this.getData();
    
    if (this.cursor < this.data.length - 1) {
      this.data = this.data.slice(0, this.cursor + 1);
    }
    
    this.data.push(data);
    this.cursor++;
    
    if (this.data.length > MAX_HISTORY_SIZE) {
      this.data.shift();
      this.cursor--;
    }
    
    this.emitter.emit('change', this.state);
  }
  
  undo(): void {
    if (this.state !== 'idle') {
      return;
    }
    if (this.cursor <= 0) {
      return;
    }
    
    this.state = 'undoing';
    this.cursor--;
    this.setData(this.data[this.cursor]);
    this.state = 'idle';
    this.emitter.emit('change', this.state);
  }
}
```

**优势**:
- 支持撤销/重做
- 操作可记录和回放
- 状态机保护

#### 5.1.3 观察者模式（Observer Pattern）

**实现方式**: EventBus发布节点事件

**代码示例**:
```typescript
export class DocumentModel implements IDocumentModel {
  private emitter: IEventBus;
  
  createNode<T extends INode = INode, C = undefined>(data: GetDataType<C, T>): T {
    // ... 创建节点逻辑
    
    this.emitter.emit('nodecreate', node);
    return node as any;
  }
  
  destroyNode(node: INode) {
    this.emitter.emit('nodedestroy', node);
  }
  
  onNodeCreate(func: (node: INode) => void) {
    const wrappedFunc = wrapWithEventSwitch(func);
    this.emitter.on('nodecreate', wrappedFunc);
    return () => {
      this.emitter.removeListener('nodecreate', wrappedFunc);
    };
  }
  
  onNodeDestroy(func: (node: INode) => void) {
    const wrappedFunc = wrapWithEventSwitch(func);
    this.emitter.on('nodedestroy', wrappedFunc);
    return () => {
      this.emitter.removeListener('nodedestroy', wrappedFunc);
    };
  }
}
```

**优势**:
- 松耦合
- 易于扩展
- 支持多个订阅者

#### 5.1.4 状态模式（State Pattern）

**实现方式**: History状态机

**代码示例**:
```typescript
type HistoryState = 'idle' | 'undoing' | 'redoing';

class History {
  private state: HistoryState = 'idle';
  
  record(): void {
    if (this.state !== 'idle') {
      return;
    }
    // ... 记录逻辑
  }
  
  undo(): void {
    if (this.state !== 'idle') {
      return;
    }
    this.state = 'undoing';
    // ... 撤销逻辑
    this.state = 'idle';
  }
  
  redo(): void {
    if (this.state !== 'idle') {
      return;
    }
    this.state = 'redoing';
    // ... 重做逻辑
    this.state = 'idle';
  }
}
```

**优势**:
- 防止并发操作
- 确保操作顺序
- 避免状态混乱

### 5.2 技术难点的解决方案

#### 5.2.1 节点ID唯一性保证

**问题**: 如何确保节点ID在文档中唯一

**解决方案**: 基于文档ID和序列号生成唯一ID

**核心代码**:
```typescript
private seqId = 0;

nextId(possibleId: string | undefined): string {
  let id = possibleId;
  while (!id || this.nodesMap.get(id)) {
    id = `node_${(String(this.id).slice(-10) + (++this.seqId).toString(36)).toLocaleLowerCase()}`;
  }
  return id;
}
```

**特点**:
- 使用文档ID后10位 + 序列号（36进制）
- 自动检测ID冲突
- 循环生成直到找到唯一ID

#### 5.2.2 Slot节点的特殊处理

**问题**: Slot节点不是树节点，无法正常递归删除

**解决方案**: 饱和式删除所有非根节点

**核心代码**:
```typescript
import(schema: IPublicTypeRootSchema, checkId = false) {
  const drillDownNodeId = this._drillDownNode?.id;
  runWithGlobalEventOff(() => {
    // TODO: 暂时用饱和式删除，原因是 Slot 节点并不是树节点，无法正常递归删除
    this.nodes.forEach(node => {
      if (node.isRoot()) return;
      this.internalRemoveAndPurgeNode(node, true);
    });
    this.rootNode?.import(schema as any, checkId);
    this.modalNodesManager = new ModalNodesManager(this);
    if (drillDownNodeId) {
      this.drillDown(this.getNode(drillDownNodeId));
    }
  });
}
```

**特点**:
- 遍历所有节点
- 跳过根节点
- 删除所有其他节点
- 关闭全局事件避免触发大量事件

#### 5.2.3 历史记录的内存管理

**问题**: 历史记录无限增长会导致内存溢出

**解决方案**: 限制历史记录数量

**核心代码**:
```typescript
const MAX_HISTORY_SIZE = 100;

record(): void {
  if (this.state !== 'idle') {
    return;
  }
  const data = this.getData();
  
  if (this.cursor < this.data.length - 1) {
    this.data = this.data.slice(0, this.cursor + 1);
  }
  
  this.data.push(data);
  this.cursor++;
  
  if (this.data.length > MAX_HISTORY_SIZE) {
    this.data.shift();
    this.cursor--;
  }
  
  this.emitter.emit('change', this.state);
}
```

**特点**:
- 限制历史记录数量为100条
- 超出限制时删除最早的记录
- 调整cursor保持一致性

#### 5.2.4 嵌套规则验证

**问题**: 如何确保节点嵌套符合组件规则

**解决方案**: 双向验证（向上和向下）

**核心代码**:
```typescript
checkNesting(
  dropTarget: INode,
  dragObject: IPublicTypeDragNodeObject | IPublicTypeNodeSchema | INode | IPublicTypeDragNodeDataObject,
): boolean {
  let items: Array<INode | IPublicTypeNodeSchema>;
  if (isDragNodeDataObject(dragObject)) {
    items = Array.isArray(dragObject.data) ? dragObject.data : [dragObject.data];
  } else if (isDragNodeObject<INode>(dragObject)) {
    items = dragObject.nodes;
  } else if (isNode<INode>(dragObject) || isNodeSchema(dragObject)) {
    items = [dragObject];
  } else {
    console.warn('the dragObject is not in the correct type, dragObject:', dragObject);
    return true;
  }
  return items.every((item) => this.checkNestingDown(dropTarget, item) && this.checkNestingUp(dropTarget, item));
}

checkNestingUp(parent: INode, obj: IPublicTypeNodeSchema | INode): boolean {
  if (isNode(obj) || isNodeSchema(obj)) {
    const config = isNode(obj) ? obj.componentMeta : this.getComponentMeta(obj.componentName);
    if (config) {
      return config.checkNestingUp(obj, parent);
    }
  }
  return true;
}

checkNestingDown(parent: INode, obj: IPublicTypeNodeSchema | INode): boolean {
  const config = parent.componentMeta;
  return config.checkNestingDown(parent, obj);
}
```

**特点**:
- 检查父节点对子节点的要求（checkNestingDown）
- 检查子节点对父节点的要求（checkNestingUp）
- 支持多种拖拽对象类型
- 所有项目都通过检查才允许嵌套

### 5.3 性能优化手段

#### 5.3.1 节点查找优化

**实现**: 使用Map存储节点

**代码**:
```typescript
private _nodesMap = new Map<string, INode>();

getNode(id: string): INode | null {
  return this._nodesMap.get(id) || null;
}
```

**优势**:
- O(1)时间复杂度查找
- 快速定位节点
- 减少遍历开销

#### 5.3.2 MobX响应式优化

**实现**: 使用`@obx.shallow`装饰器

**代码**:
```typescript
@obx.shallow private nodes = new Set<INode>();
@obx.shallow private willPurgeSpace: INode[] = [];
```

**优势**:
- `shallow`模式：只监听集合本身的引用变化
- 减少响应式追踪开销
- 提升性能

#### 5.3.3 事件批量处理

**实现**: 使用runWithGlobalEventOff

**代码**:
```typescript
import(schema: IPublicTypeRootSchema, checkId = false) {
  const drillDownNodeId = this._drillDownNode?.id;
  runWithGlobalEventOff(() => {
    this.nodes.forEach(node => {
      if (node.isRoot()) return;
      this.internalRemoveAndPurgeNode(node, true);
    });
    this.rootNode?.import(schema as any, checkId);
    this.modalNodesManager = new ModalNodesManager(this);
    if (drillDownNodeId) {
      this.drillDown(this.getNode(drillDownNodeId));
    }
  });
}
```

**优势**:
- 批量操作时关闭全局事件
- 避免触发大量事件
- 提升批量操作性能

### 5.4 安全性考虑

#### 5.4.1 节点ID冲突检测

**实现**: 自动检测并解决ID冲突

**代码**:
```typescript
createNode<T extends INode = INode, C = undefined>(data: GetDataType<C, T>): T {
  let schema: any;
  if (isDOMText(data) || isJSExpression(data)) {
    schema = {
      componentName: 'Leaf',
      children: data,
    };
  } else {
    schema = data;
  }

  let node: INode | null = null;
  if (this.hasNode(schema?.id)) {
    schema.id = null;
  }
  // ... 创建节点逻辑
}
```

**特点**:
- 检测ID是否已存在
- 自动重新生成ID
- 确保ID唯一性

#### 5.4.2 历史记录状态机保护

**实现**: 使用状态机防止并发操作

**代码**:
```typescript
private state: HistoryState = 'idle';

record(): void {
  if (this.state !== 'idle') {
    return;
  }
  // ... 记录逻辑
}

undo(): void {
  if (this.state !== 'idle') {
    return;
  }
  this.state = 'undoing';
  // ... 撤销逻辑
  this.state = 'idle';
}
```

**特点**:
- 防止并发操作
- 确保操作顺序
- 避免状态混乱

#### 5.4.3 嵌套规则验证

**实现**: 双向验证机制

**代码**:
```typescript
checkNesting(
  dropTarget: INode,
  dragObject: IPublicTypeDragNodeObject | IPublicTypeNodeSchema | INode | IPublicTypeDragNodeDataObject,
): boolean {
  // ... 处理不同类型
  return items.every((item) => this.checkNestingDown(dropTarget, item) && this.checkNestingUp(dropTarget, item));
}
```

**特点**:
- 白名单机制
- 双向验证
- 防止非法嵌套

## 6. 总结

DocumentModel模块是LowCodeEngine的文档模型核心，提供了：

1. **完善的节点树管理**：节点创建、删除、查找、遍历
2. **强大的选择器**：单选、多选、顶层节点过滤
3. **可靠的历史记录**：撤销/重做、保存点、状态机保护
4. **灵活的Schema导入导出**：多阶段转换、置顶节点处理
5. **严格的嵌套规则验证**：双向验证、白名单机制
6. **高效的节点查找**：Map存储、O(1)查找
7. **完整的事件系统**：节点创建/销毁事件、选择变化事件

该模块设计精巧，功能完善，是整个低代码引擎的"文档模型核心"，负责管理所有文档级别的状态和逻辑。
