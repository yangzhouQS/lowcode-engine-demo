# Config 模块详细设计

## 1. 模块概述

### 1.1 功能定位

Config 是 LowCodeEngine 的配置管理模块，负责引擎的全局配置管理。它提供配置的读写、等待机制、用户偏好存储等功能，是整个引擎的"配置中心"。

### 1.2 核心职责

1. **配置存储**：存储引擎的全局配置
2. **配置读取**：提供配置的读取接口
3. **配置写入**：提供配置的写入接口
4. **配置等待**：支持异步等待配置就绪
5. **配置验证**：严格模式下验证配置项
6. **用户偏好**：管理用户偏好设置
7. **配置批量设置**：支持批量设置配置

### 1.3 在整体架构中的位置

```
┌─────────────────────────────────────────────────────────────┐
│                    应用层 (Application)                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │   插件系统    │  │   面板组件    │  │   自定义扩展   │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                     Shell层 (Shell)                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Editor Core                             │  │
│  │  ┌──────────────────────────────────────────────┐  │  │
│  │  │          Config (本模块)            │  │  │
│  │  │  ┌────────────────────────────────────┐  │  │  │
│  │  │  │     EngineConfig                │  │  │  │
│  │  │  │  ┌────────────────────────────┐  │  │  │
│  │  │  │  │  config: Object          │  │  │  │
│  │  │  │  │  waits: Map              │  │  │  │
│  │  │  │  │  preference: Preference   │  │  │  │
│  │  │  │  └────────────────────────────┘  │  │  │
│  │  │  └────────────────────────────────────┘  │  │  │
│  │  └──────────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                   核心层 (Core)                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │  Designer    │  │  Renderer  │  │  Skeleton  │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## 2. 核心设计与实现

### 2.1 核心类/组件结构图

```mermaid
classDiagram
    class EngineConfig {
        -config: Object
        -waits: Map
        -preference: Preference
        +get(key, defaultValue)
        +set(key, value)
        +has(key)
        +setConfig(config)
        +onceGot(key)
        +onGot(key, fn)
        +getPreference()
        +setEngineOptions(options)
    }
    
    class Preference {
        -storage: Storage
        +get(key, defaultValue)
        +set(key, value)
        +remove(key)
    }
    
    class VALID_ENGINE_OPTIONS {
        +enableCondition: Object
        +designMode: Object
        +locale: Object
        +device: Object
        +...更多配置项
    }
    
    EngineConfig --> Preference
    EngineConfig --> VALID_ENGINE_OPTIONS
```

### 2.2 EngineConfig 类详解

#### 2.2.1 类定义

**源文件**: [`packages/editor-core/src/config.ts`](packages/editor-core/src/config.ts:42)

```typescript
export class EngineConfig implements IEngineConfig {
  private config: { [key: string]: any } = {};

  private waits = new Map<string, Array<{ once?: boolean; resolve: (data: any) => void }>>();

  readonly preference: IPublicModelPreference;

  constructor(preference?: IPublicModelPreference) {
    this.preference = preference || new Preference();
  }
}
```

**实现逻辑**:
1. 存储配置对象
2. 存储等待队列（Map）
3. 创建或使用传入的Preference实例

#### 2.2.2 关键方法详解

##### 2.2.2.1 get() - 获取配置

**源码位置**: [`packages/editor-core/src/config.ts:48-52`](packages/editor-core/src/config.ts:48)

```typescript
get(key: string, defaultValue?: any): any {
  return lodashGet(this.config, key, defaultValue);
}
```

**实现逻辑**:
1. 使用lodashGet获取嵌套配置
2. 支持默认值
3. 支持点号路径访问

**使用示例**:
```typescript
// 获取简单配置
const enableCondition = engineConfig.get('enableCondition', false);

// 获取嵌套配置
const locale = engineConfig.get('designer.locale', 'zh-CN');

// 获取不存在的配置
const value = engineConfig.get('nonexistent', 'default');
```

##### 2.2.2.2 set() - 设置配置

**源码位置**: [`packages/editor-core/src/config.ts:54-60`](packages/editor-core/src/config.ts:54)

```typescript
set(key: string, value: any): void {
  this.config[key] = value;
  this.notifyGot(key);
}
```

**实现逻辑**:
1. 设置配置值
2. 触发等待队列的回调
3. 支持点号路径设置

**使用示例**:
```typescript
// 设置简单配置
engineConfig.set('enableCondition', true);

// 设置嵌套配置
engineConfig.set('designer.locale', 'en-US');
```

##### 2.2.2.3 has() - 检查配置是否存在

**源码位置**: [`packages/editor-core/src/config.ts:62-64`](packages/editor-core/src/config.ts:62)

```typescript
has(key: string): boolean {
  return lodashGet(this.config, key, undefined) !== undefined;
}
```

**实现逻辑**:
1. 使用lodashGet获取配置
2. 检查是否为undefined
3. 返回布尔值

**使用示例**:
```typescript
// 检查配置是否存在
if (engineConfig.has('enableCondition')) {
  console.log('enableCondition exists');
}
```

##### 2.2.2.4 setConfig() - 批量设置配置

**源码位置**: [`packages/editor-core/src/config.ts:66-72`](packages/editor-core/src/config.ts:66)

```typescript
setConfig(config: { [key: string]: any }): void {
  Object.keys(config).forEach((key) => {
    this.set(key, config[key]);
  });
}
```

**实现逻辑**:
1. 遍历配置对象的所有key
2. 逐个调用set方法设置
3. 自动触发等待队列

**使用示例**:
```typescript
// 批量设置配置
engineConfig.setConfig({
  enableCondition: true,
  designMode: 'design',
  locale: 'zh-CN'
});
```

##### 2.2.2.5 onceGot() - 异步等待配置

**源码位置**: [`packages/editor-core/src/config.ts:74-82`](packages/editor-core/src/config.ts:74)

```typescript
onceGot(key: string): Promise<any> {
  const x = this.get(key);
  if (x !== undefined) {
    return Promise.resolve(x);
  }
  return new Promise((resolve) => {
    this.setWait(key, resolve, true);
  });
}
```

**实现逻辑**:
1. 首先检查配置是否已存在
2. 如果存在，直接返回Promise.resolve
3. 如果不存在，创建Promise并注册到等待队列
4. `once=true`表示只触发一次

**使用示例**:
```typescript
// 等待配置就绪
const enableCondition = await engineConfig.onceGot('enableCondition');

// 在异步函数中使用
async function init() {
  const config = await engineConfig.onceGot('customConfig');
  console.log('Config ready:', config);
}
```

##### 2.2.2.6 onGot() - 监听配置变化

**源码位置**: [`packages/editor-core/src/config.ts:84-92`](packages/editor-core/src/config.ts:84)

```typescript
onGot(key: string, fn: (data: any) => void): () => void {
  const x = this.get(key);
  if (x !== undefined) {
    fn(x);
  }
  this.setWait(key, fn);
  return () => {
    this.delWait(key, fn);
  };
}
```

**实现逻辑**:
1. 如果配置已存在，立即调用回调
2. 注册回调到等待队列
3. 返回解绑函数

**使用示例**:
```typescript
// 监听配置变化
const dispose = engineConfig.onGot('enableCondition', (value) => {
  console.log('enableCondition changed:', value);
});

// 取消监听
dispose();
```

##### 2.2.2.7 getPreference() - 获取用户偏好

**源码位置**: [`packages/editor-core/src/config.ts:94-96`](packages/editor-core/src/config.ts:94)

```typescript
getPreference(): IPublicModelPreference {
  return this.preference;
}
```

**实现逻辑**:
- 返回Preference实例

**使用示例**:
```typescript
// 获取用户偏好
const preference = engineConfig.getPreference();

// 设置用户偏好
preference.set('theme', 'dark');

// 获取用户偏好
const theme = preference.get('theme', 'light');
```

##### 2.2.2.8 setEngineOptions() - 设置引擎选项

**源码位置**: [`packages/editor-core/src/config.ts:98-122`](packages/editor-core/src/config.ts:98)

```typescript
setEngineOptions(engineOptions: IPublicTypeEngineOptions) {
  const strictMode = getStrictModeValue(engineOptions, STRICT_PLUGIN_MODE_DEFAULT) === true;
  if (strictMode) {
    const isValidKey = (key: string) => {
      const result = (VALID_ENGINE_OPTIONS as any)[key];
      return !(result === undefined || result === null);
    };
    Object.keys(engineOptions).forEach((key) => {
      if (isValidKey(key)) {
        this.set(key, (engineOptions as any)[key]);
      } else {
        logger.warn(`failed to config ${key} to engineConfig, only predefined options can be set under strict mode`);
      }
    });
  } else {
    this.setConfig(engineOptions as any);
  }
}
```

**实现逻辑**:
1. 检查是否为严格模式
2. 如果是严格模式，验证配置项是否在预定义列表中
3. 只允许设置预定义的配置项
4. 如果不是严格模式，直接设置所有配置

**使用示例**:
```typescript
// 严格模式设置配置
engineConfig.setEngineOptions({
  enableCondition: true,
  designMode: 'design'
});

// 非严格模式设置配置
engineConfig.setEngineOptions({
  enableCondition: true,
  customOption: 'value'  // 严格模式下会警告
});
```

### 2.3 VALID_ENGINE_OPTIONS 定义

#### 2.3.1 预定义配置项

**源码位置**: [`packages/editor-core/src/config.ts:6-40`](packages/editor-core/src/config.ts:6)

```typescript
const VALID_ENGINE_OPTIONS = {
  enableCondition: {
    type: 'boolean',
    description: '是否启用条件配置功能',
    default: false,
  },
  designMode: {
    type: 'string',
    description: '设计器模式',
    enum: ['design', 'live'],
    default: 'design',
  },
  locale: {
    type: 'string',
    description: '语言',
    default: 'zh-CN',
  },
  device: {
    type: 'string',
    description: '设备类型',
    default: 'desktop',
  },
  // ... 更多配置项
};
```

**配置项类型**:
- `boolean`: 布尔值
- `string`: 字符串
- `number`: 数字
- `object`: 对象
- `array`: 数组

**配置项属性**:
- `type`: 配置类型
- `description`: 配置描述
- `default`: 默认值
- `enum`: 可选值（仅string类型）

### 2.4 Preference 类详解

#### 2.4.1 类定义

**源文件**: [`packages/editor-core/src/config.ts`](packages/editor-core/src/config.ts:127)

```typescript
export class Preference implements IPublicModelPreference {
  private storage: Storage;

  constructor(storage?: Storage) {
    this.storage = storage || window.localStorage;
  }
}
```

**实现逻辑**:
1. 接受可选的Storage实例
2. 如果不提供，使用window.localStorage

#### 2.4.2 关键方法详解

##### 2.4.2.1 get() - 获取用户偏好

**源码位置**: [`packages/editor-core/src/config.ts:129-133`](packages/editor-core/src/config.ts:129)

```typescript
get(key: string, defaultValue?: any): any {
  const value = this.storage.getItem(key);
  if (value === null) {
    return defaultValue;
  }
  try {
    return JSON.parse(value);
  } catch (e) {
    return value;
  }
}
```

**实现逻辑**:
1. 从Storage中获取值
2. 如果值为null，返回默认值
3. 尝试JSON解析
4. 解析失败返回原始值

**使用示例**:
```typescript
// 获取用户偏好
const theme = preference.get('theme', 'light');

// 获取嵌套偏好
const settings = preference.get('settings', {});
```

##### 2.4.2.2 set() - 设置用户偏好

**源码位置**: [`packages/editor-core/src/config.ts:135-139`](packages/editor-core/src/config.ts:135)

```typescript
set(key: string, value: any): void {
  this.storage.setItem(key, JSON.stringify(value));
}
```

**实现逻辑**:
1. 将值转换为JSON字符串
2. 存储到Storage

**使用示例**:
```typescript
// 设置用户偏好
preference.set('theme', 'dark');

// 设置嵌套偏好
preference.set('settings', {
  fontSize: 14,
  fontFamily: 'Arial'
});
```

##### 2.4.2.3 remove() - 移除用户偏好

**源码位置**: [`packages/editor-core/src/config.ts:141-143`](packages/editor-core/src/config.ts:141)

```typescript
remove(key: string): void {
  this.storage.removeItem(key);
}
```

**实现逻辑**:
- 从Storage中移除指定key

**使用示例**:
```typescript
// 移除用户偏好
preference.remove('theme');
```

### 2.5 等待队列机制

#### 2.5.1 setWait() - 注册等待

**源码位置**: [`packages/editor-core/src/config.ts:145-151`](packages/editor-core/src/config.ts:145)

```typescript
private setWait(key: string, resolve: (data: any) => void, once?: boolean) {
  let waits = this.waits.get(key);
  if (!waits) {
    waits = [];
    this.waits.set(key, waits);
  }
  waits.push({ resolve, once });
}
```

**实现逻辑**:
1. 获取指定key的等待队列
2. 如果不存在，创建新队列
3. 将回调添加到队列

#### 2.5.2 delWait() - 删除等待

**源码位置**: [`packages/editor-core/src/config.ts:153-159`](packages/editor-core/src/config.ts:153)

```typescript
private delWait(key: string, resolve: (data: any) => void) {
  const waits = this.waits.get(key);
  if (!waits) {
    return;
  }
  const i = waits.findIndex((item) => item.resolve === resolve);
  if (i > -1) {
    waits.splice(i, 1);
  }
}
```

**实现逻辑**:
1. 获取指定key的等待队列
2. 查找回调在队列中的索引
3. 如果找到，从队列中删除

#### 2.5.3 notifyGot() - 通知等待

**源码位置**: [`packages/editor-core/src/config.ts:161-173`](packages/editor-core/src/config.ts:161)

```typescript
private notifyGot(key: string) {
  let waits = this.waits.get(key);
  if (!waits) {
    return;
  }
  waits = waits.slice().reverse();
  let i = waits.length;
  while (i--) {
    waits[i].resolve(this.get(key));
    if (waits[i].once) {
      waits.splice(i, 1);
    }
  }
  if (waits.length > 0) {
    this.waits.set(key, waits);
  } else {
    this.waits.delete(key);
  }
}
```

**实现逻辑**:
1. 获取指定key的等待队列
2. 倒序遍历队列（保证顺序）
3. 调用每个回调，传入配置值
4. 如果是once，从队列中删除
5. 如果队列不为空，更新队列
6. 如果队列为空，删除key

## 3. 交互与通信

### 3.1 模块内部数据流向

```
┌─────────────────────────────────────────────────────────────┐
│              Config 内部数据流                             │
│                                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐  │  │
│  │  │   config    │  │    waits    │  │  │
│  │  │   (Object)  │  │   (Map)     │  │  │
│  │  └──────────────┘  └──────────────┘  │  │
│  │                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐  │  │
│  │  │ preference  │  │  VALID_     │  │  │
│  │  │             │  │  ENGINE_     │  │  │
│  │  │             │  │  OPTIONS     │  │  │
│  │  └──────────────┘  └──────────────┘  │  │
│  │                                        │  │
│  └──────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

### 3.2 与其他模块的具体交互方式

#### 3.2.1 与EditorCore交互

**交互方式**: EditorCore使用engineConfig单例

**代码示例**:
```typescript
// Editor中设置配置
engineConfig.set('designer', designerInstance);

// Editor中获取配置
const designer = engineConfig.get('designer');

// Editor中等待配置
const simulator = await engineConfig.onceGot('simulator');
```

**API引用**:
- [`engineConfig.get()`](packages/editor-core/src/config.ts:48) - 获取配置
- [`engineConfig.set()`](packages/editor-core/src/config.ts:54) - 设置配置
- [`engineConfig.onceGot()`](packages/editor-core/src/config.ts:74) - 等待配置

#### 3.2.2 与Designer交互

**交互方式**: Designer通过engineConfig获取配置

**代码示例**:
```typescript
// Designer中获取配置
const enableCondition = engineConfig.get('enableCondition', false);

// Designer中设置配置
engineConfig.set('currentDocument', documentModel);
```

**API引用**:
- [`engineConfig.get()`](packages/editor-core/src/config.ts:48) - 获取配置
- [`engineConfig.set()`](packages/editor-core/src/config.ts:54) - 设置配置

#### 3.2.3 与DocumentModel交互

**交互方式**: DocumentModel通过engineConfig获取配置

**代码示例**:
```typescript
// DocumentModel中获取配置
const selector = engineConfig.get('focusNodeSelector');

// DocumentModel中设置配置
engineConfig.set('currentDocument', this);
```

**API引用**:
- [`engineConfig.get()`](packages/editor-core/src/config.ts:48) - 获取配置
- [`engineConfig.set()`](packages/editor-core/src/config.ts:54) - 设置配置

## 4. 依赖关系

### 4.1 外部库依赖

| 依赖包 | 版本 | 用途 |
|--------|------|------|
| `lodash` | ^4.17.0 | 工具函数（lodashGet） |
| `@alilc/lowcode-types` | ^1.3.2 | 类型定义 |

### 4.2 内部模块依赖

| 模块 | 依赖方式 | 用途 |
|------|---------|------|
| `Logger` | 直接导入 | 日志系统 |

### 4.3 依赖关系图

```mermaid
graph TD
    EngineConfig[EngineConfig] --> Preference[Preference]
    EngineConfig --> VALID_ENGINE_OPTIONS[VALID_ENGINE_OPTIONS]
    EngineConfig --> Logger[Logger]
    
    EditorCore[Editor Core] --> EngineConfig
    Designer[Designer] --> EngineConfig
    DocumentModel[DocumentModel] --> EngineConfig
    Node[Node] --> EngineConfig
    
    Preference --> Storage[Storage]
```

## 5. 关键技术点

### 5.1 应用的设计模式

#### 5.1.1 单例模式（Singleton Pattern）

**实现方式**: 导出单例实例

**代码示例**:
```typescript
export const engineConfig = new EngineConfig();

export function setEngineConfig(config: IEngineConfig) {
  Object.assign(engineConfig, config);
}
```

**优势**:
- 全局唯一实例
- 便于访问
- 统一管理

#### 5.1.2 Promise模式（Promise Pattern）

**实现方式**: 使用Promise解决异步配置问题

**代码示例**:
```typescript
onceGot(key: string): Promise<any> {
  const x = this.get(key);
  if (x !== undefined) {
    return Promise.resolve(x);
  }
  return new Promise((resolve) => {
    this.setWait(key, resolve, true);
  });
}
```

**优势**:
- 标准化：使用ES6 Promise
- 可组合：支持Promise.all、Promise.race等
- 错误处理：统一的错误处理机制

#### 5.1.3 观察者模式（Observer Pattern）

**实现方式**: 等待队列机制

**代码示例**:
```typescript
onGot(key: string, fn: (data: any) => void): () => void {
  const x = this.get(key);
  if (x !== undefined) {
    fn(x);
  }
  this.setWait(key, fn);
  return () => {
    this.delWait(key, fn);
  };
}
```

**优势**:
- 松耦合：发布者和订阅者互不依赖
- 异步：支持异步配置加载
- 可扩展：易于添加新的事件类型

### 5.2 技术难点的解决方案

#### 5.2.1 异步配置加载问题

**问题**: 某些配置可能异步加载，如何处理？

**解决方案**: 实现等待队列机制

**核心代码**:
```typescript
private waits = new Map<string, Array<{ once?: boolean; resolve: (data: any) => void }>>();

onceGot(key: string): Promise<any> {
  const x = this.get(key);
  if (x !== undefined) {
    return Promise.resolve(x);
  }
  return new Promise((resolve) => {
    this.setWait(key, resolve, true);
  });
}

private notifyGot(key: string) {
  let waits = this.waits.get(key);
  if (!waits) {
    return;
  }
  waits = waits.slice().reverse();
  let i = waits.length;
  while (i--) {
    waits[i].resolve(this.get(key));
    if (waits[i].once) {
      waits.splice(i, 1);
    }
  }
  if (waits.length > 0) {
    this.waits.set(key, waits);
  } else {
    this.waits.delete(key);
  }
}
```

**特点**:
- 支持once和多次触发模式
- 倒序遍历保证顺序
- 自动清理空队列

#### 5.2.2 配置验证问题

**问题**: 如何防止插件传入未经验证的配置？

**解决方案**: 严格模式 + 预定义配置项

**核心代码**:
```typescript
const VALID_ENGINE_OPTIONS = {
  enableCondition: {
    type: 'boolean',
    description: '是否启用条件配置功能',
    default: false,
  },
  // ... 更多配置项
};

setEngineOptions(engineOptions: IPublicTypeEngineOptions) {
  const strictMode = getStrictModeValue(engineOptions, STRICT_PLUGIN_MODE_DEFAULT) === true;
  if (strictMode) {
    const isValidKey = (key: string) => {
      const result = (VALID_ENGINE_OPTIONS as any)[key];
      return !(result === undefined || result === null);
    };
    Object.keys(engineOptions).forEach((key) => {
      if (isValidKey(key)) {
        this.set(key, (engineOptions as any)[key]);
      } else {
        logger.warn(`failed to config ${key} to engineConfig, only predefined options can be set under strict mode`);
      }
    });
  } else {
    this.setConfig(engineOptions as any);
  }
}
```

**特点**:
- 严格模式只允许预定义配置项
- 非严格模式允许任意配置
- 提供清晰的警告信息

#### 5.2.3 用户偏好持久化问题

**问题**: 如何持久化用户偏好设置？

**解决方案**: 使用localStorage

**核心代码**:
```typescript
export class Preference implements IPublicModelPreference {
  private storage: Storage;

  constructor(storage?: Storage) {
    this.storage = storage || window.localStorage;
  }

  get(key: string, defaultValue?: any): any {
    const value = this.storage.getItem(key);
    if (value === null) {
      return defaultValue;
    }
    try {
      return JSON.parse(value);
    } catch (e) {
      return value;
    }
  }

  set(key: string, value: any): void {
    this.storage.setItem(key, JSON.stringify(value));
  }

  remove(key: string): void {
    this.storage.removeItem(key);
  }
}
```

**特点**:
- 使用localStorage持久化
- 支持JSON序列化
- 支持自定义Storage

### 5.3 性能优化手段

#### 5.3.1 配置查找优化

**实现**: 使用lodashGet

**代码**:
```typescript
get(key: string, defaultValue?: any): any {
  return lodashGet(this.config, key, defaultValue);
}
```

**优势**:
- 支持点号路径访问
- 支持默认值
- 高效的嵌套查找

#### 5.3.2 等待队列优化

**实现**: 使用Map存储等待队列

**代码**:
```typescript
private waits = new Map<string, Array<{ once?: boolean; resolve: (data: any) => void }>>();
```

**优势**:
- O(1)时间复杂度查找
- 快速定位等待队列
- 减少遍历开销

### 5.4 安全性考虑

#### 5.4.1 配置验证

**实现**: 严格模式 + 预定义配置项

**代码示例**:
```typescript
setEngineOptions(engineOptions: IPublicTypeEngineOptions) {
  const strictMode = getStrictModeValue(engineOptions, STRICT_PLUGIN_MODE_DEFAULT) === true;
  if (strictMode) {
    const isValidKey = (key: string) => {
      const result = (VALID_ENGINE_OPTIONS as any)[key];
      return !(result === undefined || result === null);
    };
    Object.keys(engineOptions).forEach((key) => {
      if (isValidKey(key)) {
        this.set(key, (engineOptions as any)[key]);
      } else {
        logger.warn(`failed to config ${key} to engineConfig, only predefined options can be set under strict mode`);
      }
    });
  } else {
    this.setConfig(engineOptions as any);
  }
}
```

**特点**:
- 严格模式只允许预定义配置项
- 非严格模式允许任意配置
- 提供清晰的警告信息

#### 5.4.2 用户偏好错误处理

**实现**: JSON解析错误处理

**代码示例**:
```typescript
get(key: string, defaultValue?: any): any {
  const value = this.storage.getItem(key);
  if (value === null) {
    return defaultValue;
  }
  try {
    return JSON.parse(value);
  } catch (e) {
    return value;
  }
}
```

**特点**:
- JSON解析失败返回原始值
- 防止解析错误导致异常
- 提供默认值

## 6. 总结

Config模块是LowCodeEngine的配置管理核心，提供了：

1. **完善的配置管理**：get、set、has、setConfig
2. **强大的等待机制**：onceGot、onGot支持异步配置
3. **灵活的用户偏好**：Preference支持持久化
4. **严格的配置验证**：严格模式 + 预定义配置项
5. **高效的配置查找**：lodashGet支持嵌套查找
6. **完整的类型定义**：TypeScript类型支持
7. **单例模式**：全局唯一实例
8. **Promise支持**：异步配置加载

该模块设计简洁高效，功能完善，是整个低代码引擎的"配置中心"，负责管理所有全局配置和用户偏好。
