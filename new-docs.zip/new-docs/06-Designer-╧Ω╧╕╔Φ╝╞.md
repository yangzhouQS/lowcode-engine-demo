# Designer 模块详细设计

## 1. 模块概述

### 1.1 功能定位

Designer 是 LowCodeEngine 的设计器核心模块，负责管理整个设计器的状态、文档模型、组件元数据、选择器、历史记录等核心功能。它是连接编辑器和渲染器的桥梁，提供统一的模型层。

### 1.2 核心职责

1. **文档模型管理**：管理项目中的多个文档（页面）
2. **组件元数据管理**：管理组件的元数据和配置
3. **选择器管理**：管理当前选中的节点
4. **历史记录管理**：提供撤销/重做功能
5. **拖拽系统**：管理节点的拖拽和投放
6. **属性转换**：提供属性在不同阶段的转换机制
7. **模拟器集成**：与渲染器模拟器进行交互

### 1.3 在整体架构中的位置

```
┌─────────────────────────────────────────────────────────────┐
│                    应用层 (Application)                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │   插件系统    │  │   面板组件    │  │   自定义扩展   │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                     Shell层 (Shell)                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Editor Core                             │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                   核心层 (Core)                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Designer (本模块)               │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  │  │
│  │  │ Project  │  │ Component│  │ Selection│  │  │
│  │  │          │  │  Meta    │  │          │  │  │
│  │  └──────────┘  └──────────┘  └──────────┘  │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  │  │
│  │  │ Dragon   │  │ History  │  │ Detecting│  │  │
│  │  └──────────┘  └──────────┘  └──────────┘  │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                   文档层 (Document)                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │DocumentModel │  │     Node     │  │    Props     │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## 2. 核心设计与实现

### 2.1 核心类/组件结构图

```mermaid
classDiagram
    class Designer {
        -editor: IEditor
        -project: IProject
        -componentMetas: Map
        -shellModelFactory: ShellModelFactory
        -componentsMap: Map
        +getComponentMeta()
        +transformProps()
        +postEvent()
        +createSettingEntry()
    }
    
    class Project {
        -documents: IDocumentModel[]
        -data: ProjectSchema
        -simulator: ISimulatorHost
        +createDocument()
        +open()
        +getSchema()
        +mountSimulator()
    }
    
    class ComponentMeta {
        -componentName: string
        -npm: NpmPackage
        -configure: Configure
        +checkNestingUp()
        +checkNestingDown()
        +getMetadata()
    }
    
    class Selection {
        -document: IDocumentModel
        -selected: string[]
        +select()
        +getTopNodes()
        +clear()
        +has()
    }
    
    class History {
        -document: IDocumentModel
        -data: any[]
        -cursor: number
        +record()
        +redo()
        +undo()
        +isSavePoint()
    }
    
    class Dragon {
        -designer: IDesigner
        -dragging: boolean
        +drag()
        +drop()
        +clear()
    }
    
    Designer --> Project
    Designer --> ComponentMeta
    Designer --> Selection
    Designer --> History
    Designer --> Dragon
```

### 2.2 Designer 类详解

#### 2.2.1 类定义

**源文件**: [`packages/designer/src/designer.ts`](packages/designer/src/designer.ts)

```typescript
export class Designer implements IDesigner {
  readonly editor: IEditor;
  
  // 项目实例
  readonly project: IProject;
  
  // 组件元数据缓存
  readonly componentMetas = new Map<string, IComponentMeta>();
  
  // Shell模型工厂
  readonly shellModelFactory: ShellModelFactory;
  
  // 组件映射
  readonly componentsMap = new Map<string, any>();
  
  // 事件总线
  readonly emitter: IEventBus;
  
  // 拖拽系统
  readonly dragon: Dragon;
  
  // 悬停检测
  readonly detecting: Detecting;
  
  // 位置监听器
  readonly locating: Locating;
  
  constructor(editor: IEditor, options: IDesignerOptions = {}) {
    this.editor = editor;
    this.emitter = createModuleEventBus('Designer');
    this.shellModelFactory = new ShellModelFactory(this);
    this.project = new Project(this, options.projectSchema, options.viewName);
    
    // 初始化子系统
    this.dragon = new Dragon(this);
    this.detecting = new Detecting(this);
    this.locating = new Locating(this);
  }
}
```

#### 2.2.2 关键方法详解

##### 2.2.2.1 getComponentMeta() - 获取组件元数据

**源码位置**: [`packages/designer/src/designer.ts`](packages/designer/src/designer.ts)

```typescript
getComponentMeta(
  componentName: string,
  generateMetadata?: (componentName: string) => IPublicTypeComponentMetadata | null,
): IComponentMeta {
  let meta = this.componentMetas.get(componentName);
  if (!meta) {
    if (generateMetadata) {
      const metadata = generateMetadata(componentName);
      if (metadata) {
        meta = new ComponentMeta(this, componentName, metadata);
        this.componentMetas.set(componentName, meta);
      }
    }
  }
  return meta;
}
```

**实现逻辑**:
1. 首先从缓存中查找组件元数据
2. 如果缓存中不存在，调用`generateMetadata`生成元数据
3. 创建`ComponentMeta`实例并缓存
4. 返回组件元数据

**使用示例**:
```typescript
const meta = designer.getComponentMeta('Button', (componentName) => {
  return simulator.generateComponentMetadata(componentName);
});
```

##### 2.2.2.2 transformProps() - 属性转换

**源码位置**: [`packages/designer/src/designer.ts`](packages/designer/src/designer.ts)

```typescript
transformProps(
  props: any,
  node: INode,
  stage: IPublicEnumTransformStage,
): any {
  const componentName = node.componentName;
  const meta = this.getComponentMeta(componentName);
  const { propsTransducers = [] } = meta.getMetadata();
  let result = props;
  for (const transducer of propsTransducers) {
    if (transducer.stage === stage || transducer.stage === '*') {
      result = transducer.consumer(result, node);
    }
  }
  return result;
}
```

**实现逻辑**:
1. 获取节点的组件元数据
2. 获取所有属性转换器（propsTransducers）
3. 遍历转换器，匹配当前阶段
4. 应用转换器处理属性
5. 返回转换后的属性

**转换阶段**:
- `Init`: 初始化阶段
- `Upgrade`: 升级阶段
- `Render`: 渲染阶段
- `Save`: 保存阶段
- `Serilize`: 序列化阶段
- `Clone`: 克隆阶段

**使用示例**:
```typescript
// 在Init阶段转换属性
const transformedProps = designer.transformProps(
  { className: 'btn' },
  node,
  IPublicEnumTransformStage.Init
);
```

##### 2.2.2.3 postEvent() - 发布事件

**源码位置**: [`packages/designer/src/designer.ts`](packages/designer/src/designer.ts)

```typescript
postEvent(event: string, ...args: any[]) {
  this.emitter.emit(event, ...args);
}
```

**实现逻辑**:
- 通过事件总线发布事件
- 支持多个参数传递
- 所有订阅者都会收到通知

**使用示例**:
```typescript
// 发布文档打开事件
designer.postEvent('document-open', documentModel);

// 发布节点添加事件
designer.postEvent('node-add', { node, parent });
```

##### 2.2.2.4 createSettingEntry() - 创建设置面板入口

**源码位置**: [`packages/designer/src/designer.ts`](packages/designer/src/designer.ts)

```typescript
createSettingEntry(nodes: INode[]): ISettingTopEntry {
  return this.shellModelFactory.createSettingEntry(nodes);
}
```

**实现逻辑**:
- 通过Shell模型工厂创建设置面板入口
- 支持单个节点或多个节点
- 返回统一的设置面板接口

**使用示例**:
```typescript
// 为选中的节点创建设置面板
const selectedNodes = document.selection.getTopNodes();
const settingEntry = designer.createSettingEntry(selectedNodes);
```

### 2.3 Project 类详解

#### 2.3.1 类定义

**源文件**: [`packages/designer/src/project/project.ts`](packages/designer/src/project/project.ts:90)

```typescript
export class Project implements IProject {
  private emitter: IEventBus = createModuleEventBus('Project');
  
  // 文档列表
  @obx.shallow readonly documents: IDocumentModel[] = [];
  
  // 项目数据
  private data: IPublicTypeProjectSchema = {
    version: '1.0.0',
    componentsMap: [],
    componentsTree: [],
    i18n: {},
  };
  
  // 模拟器
  private _simulator?: ISimulatorHost;
  
  // 文档映射
  private documentsMap = new Map<string, DocumentModel>();
  
  // 配置
  @obx private _config: any = {};
  
  // 国际化
  @obx.ref private _i18n: any = {};
  
  constructor(readonly designer: IDesigner, schema?: IPublicTypeProjectSchema, readonly viewName = 'global') {
    makeObservable(this);
    this.load(schema);
  }
}
```

#### 2.3.2 关键方法详解

##### 2.3.2.1 createDocument() - 创建文档

**源码位置**: [`packages/designer/src/project/project.ts:301-307`](packages/designer/src/project/project.ts:301)

```typescript
@action
createDocument(data?: IPublicTypeRootSchema): IDocumentModel {
  const doc = new DocumentModel(this, data || this?.data?.componentsTree?.[0]);
  this.documents.push(doc);
  this.documentsMap.set(doc.id, doc);
  return doc;
}
```

**实现逻辑**:
1. 创建`DocumentModel`实例
2. 将文档添加到文档列表
3. 将文档ID映射到文档实例
4. 返回文档实例

**使用示例**:
```typescript
// 创建新文档
const doc = project.createDocument({
  componentName: 'Page',
  id: 'page1',
  fileName: 'index',
  props: {},
  children: []
});
```

##### 2.3.2.2 open() - 打开文档

**源码位置**: [`packages/designer/src/project/project.ts:309-344`](packages/designer/src/project/project.ts:309)

```typescript
open(doc?: string | IDocumentModel | IPublicTypeRootSchema): IDocumentModel | null {
  if (!doc) {
    const got = this.documents.find((item) => item.isBlank());
    if (got) {
      return got.open();
    }
    doc = this.createDocument();
    return doc.open();
  }
  if (typeof doc === 'string' || typeof doc === 'number') {
    const got = this.documents.find((item) => item.fileName === String(doc) || String(item.id) === String(doc));
    if (got) {
      return got.open();
    }

    const data = this.data.componentsTree.find((data) => data.fileName === String(doc));
    if (data) {
      doc = this.createDocument(data);
      return doc.open();
    }

    return null;
  } else if (isDocumentModel(doc)) {
    return doc.open();
  }

  doc = this.createDocument(doc);
  return doc.open();
}
```

**实现逻辑**:
1. 如果不传参数，查找空白文档或创建新文档
2. 如果传入字符串，按fileName或ID查找文档
3. 如果传入DocumentModel实例，直接打开
4. 如果传入Schema，创建新文档并打开
5. 返回打开的文档

**使用示例**:
```typescript
// 按文件名打开
project.open('index');

// 按ID打开
project.open('doc_123');

// 打开文档实例
project.open(documentModel);

// 从Schema创建并打开
project.open({
  componentName: 'Page',
  fileName: 'about'
});
```

##### 2.3.2.3 getSchema() - 获取项目Schema

**源码位置**: [`packages/designer/src/project/project.ts:176-187`](packages/designer/src/project/project.ts:176)

```typescript
getSchema(
  stage: IPublicEnumTransformStage = IPublicEnumTransformStage.Save,
): IPublicTypeProjectSchema {
  return {
    ...this.data,
    componentsMap: this.getComponentsMap(),
    componentsTree: this.documents
      .filter((doc) => !doc.isBlank())
      .map((doc) => doc.export(stage) || {} as IPublicTypeRootSchema),
    i18n: this.i18n,
  };
}
```

**实现逻辑**:
1. 合并项目基础数据
2. 聚合所有文档的组件映射
3. 导出所有非空白文档的Schema
4. 包含国际化数据
5. 返回完整的项目Schema

**使用示例**:
```typescript
// 获取保存阶段的Schema
const schema = project.getSchema(IPublicEnumTransformStage.Save);

// 获取渲染阶段的Schema
const renderSchema = project.getSchema(IPublicEnumTransformStage.Render);
```

##### 2.3.2.4 mountSimulator() - 挂载模拟器

**源码位置**: [`packages/designer/src/project/project.ts:363-367`](packages/designer/src/project/project.ts:363)

```typescript
mountSimulator(simulator: ISimulatorHost) {
  this._simulator = simulator;
  this.emitter.emit('lowcode_engine_simulator_ready', simulator);
}
```

**实现逻辑**:
1. 保存模拟器实例
2. 发布模拟器就绪事件
3. 通知所有等待模拟器的模块

**使用示例**:
```typescript
// 在渲染器中挂载模拟器
project.mountSimulator(simulatorHost);
```

### 2.4 ComponentMeta 类详解

#### 2.4.1 类定义

**源文件**: [`packages/designer/src/component-meta/index.ts`](packages/designer/src/component-meta/index.ts)

```typescript
export class ComponentMeta implements IComponentMeta {
  readonly designer: IDesigner;
  readonly componentName: string;
  readonly npm: IPublicTypeNpmInfo | null;
  readonly configure: Configure;
  private metadata: IPublicTypeComponentMetadata;
  
  constructor(
    designer: IDesigner,
    componentName: string,
    metadata: IPublicTypeComponentMetadata,
  ) {
    this.designer = designer;
    this.componentName = componentName;
    this.metadata = metadata;
    this.npm = metadata.npm || null;
    this.configure = new Configure(this);
  }
}
```

#### 2.4.2 关键方法详解

##### 2.4.2.1 checkNestingUp() - 检查父级嵌套规则

**源码位置**: [`packages/designer/src/component-meta/index.ts`](packages/designer/src/component-meta/index.ts)

```typescript
checkNestingUp(target: INode | IPublicTypeNodeSchema, parent: INode): boolean {
  const { parentWhitelist = [] } = this.getMetadata();
  if (parentWhitelist.length === 0) {
    return true;
  }
  return parentWhitelist.some((item) => {
    if (typeof item === 'string') {
      return parent.componentName === item;
    }
    if (typeof item === 'function') {
      return item(target, parent);
    }
    return false;
  });
}
```

**实现逻辑**:
1. 获取父级白名单（parentWhitelist）
2. 如果白名单为空，允许任何父级
3. 遍历白名单，检查父级是否匹配
4. 支持字符串和函数形式的白名单
5. 返回是否允许嵌套

**使用示例**:
```typescript
// 在组件元数据中配置
const metadata = {
  componentName: 'Button',
  parentWhitelist: [
    'Form',  // 字符串形式
    (target, parent) => {
      // 函数形式
      return parent.componentName === 'Container' && parent.props.get('type') === 'button-container';
    }
  ]
};
```

##### 2.4.2.2 checkNestingDown() - 检查子级嵌套规则

**源码位置**: [`packages/designer/src/component-meta/index.ts`](packages/designer/src/component-meta/index.ts)

```typescript
checkNestingDown(parent: INode, target: INode | IPublicTypeNodeSchema): boolean {
  const { childWhitelist = [] } = this.getMetadata();
  if (childWhitelist.length === 0) {
    return true;
  }
  const targetComponentName = isNode(target) ? target.componentName : target.componentName;
  return childWhitelist.some((item) => {
    if (typeof item === 'string') {
      return targetComponentName === item;
    }
    if (typeof item === 'function') {
      return item(target, parent);
    }
    return false;
  });
}
```

**实现逻辑**:
1. 获取子级白名单（childWhitelist）
2. 如果白名单为空，允许任何子级
3. 获取目标组件名称
4. 遍历白名单，检查子级是否匹配
5. 返回是否允许嵌套

**使用示例**:
```typescript
// 在组件元数据中配置
const metadata = {
  componentName: 'Form',
  childWhitelist: [
    'Button',  // 字符串形式
    'Input',
    (target, parent) => {
      // 函数形式
      return target.componentName === 'CustomField';
    }
  ]
};
```

##### 2.4.2.3 getMetadata() - 获取元数据

**源码位置**: [`packages/designer/src/component-meta/index.ts`](packages/designer/src/component-meta/index.ts)

```typescript
getMetadata(): IPublicTypeComponentMetadata {
  return this.metadata;
}
```

**实现逻辑**:
- 返回完整的组件元数据
- 包含组件的所有配置信息

**元数据结构**:
```typescript
interface IPublicTypeComponentMetadata {
  componentName: string;
  title?: string | IPublicTypeI18nData;
  description?: string;
  docUrl?: string;
  screenshot?: string;
  devMode?: 'lowCode' | 'proCode';
  npm?: IPublicTypeNpmInfo;
  snippets?: IPublicTypeSnippet[];
  configure?: IPublicTypeConfigure;
  parentWhitelist?: (string | Function)[];
  childWhitelist?: (string | Function)[];
  propsTransducers?: IPublicTypePropsTransducer[];
  // ... 更多配置
}
```

### 2.5 Selection 类详解

#### 2.5.1 类定义

**源文件**: [`packages/designer/src/document/selection.ts`](packages/designer/src/document/selection.ts)

```typescript
export class Selection implements ISelection {
  readonly document: IDocumentModel;
  @obx.shallow private selected: string[] = [];
  private emitter: IEventBus;
  
  constructor(document: IDocumentModel) {
    this.document = document;
    this.emitter = createModuleEventBus('Selection');
  }
}
```

#### 2.5.2 关键方法详解

##### 2.5.2.1 select() - 选择节点

**源码位置**: [`packages/designer/src/document/selection.ts`](packages/designer/src/document/selection.ts)

```typescript
@action
select(id: string | string[], clear: boolean = true): void {
  if (clear) {
    this.selected = [];
  }
  const ids = Array.isArray(id) ? id : [id];
  ids.forEach((id) => {
    if (!this.selected.includes(id)) {
      this.selected.push(id);
    }
  });
  this.emitter.emit('change', this.selected);
}
```

**实现逻辑**:
1. 如果clear为true，清空当前选择
2. 将id转换为数组
3. 遍历id，添加到选择列表（去重）
4. 发布选择变化事件

**使用示例**:
```typescript
// 选择单个节点
selection.select('node_123');

// 选择多个节点
selection.select(['node_123', 'node_456']);

// 追加选择
selection.select('node_789', false);
```

##### 2.5.2.2 getTopNodes() - 获取顶层节点

**源码位置**: [`packages/designer/src/document/selection.ts`](packages/designer/src/document/selection.ts)

```typescript
getTopNodes(includeRoot = false): INode[] {
  if (this.selected.length === 0) {
    return [];
  }
  const nodes = this.selected
    .map((id) => this.document.getNode(id))
    .filter((node) => node) as INode[];
  
  if (includeRoot) {
    return nodes;
  }
  
  // 过滤掉被其他选中节点包含的节点
  const topNodes: INode[] = [];
  for (const node of nodes) {
    if (!nodes.some((other) => other.contains(node) && other !== node)) {
      topNodes.push(node);
    }
  }
  return topNodes;
}
```

**实现逻辑**:
1. 根据选择的ID获取所有节点
2. 如果includeRoot为true，返回所有节点
3. 否则，过滤掉被其他节点包含的节点
4. 返回顶层节点列表

**使用示例**:
```typescript
// 获取顶层选中节点
const topNodes = selection.getTopNodes();

// 包含根节点
const allNodes = selection.getTopNodes(true);
```

##### 2.5.2.3 has() - 检查节点是否被选中

**源码位置**: [`packages/designer/src/document/selection.ts`](packages/designer/src/document/selection.ts)

```typescript
has(id: string): boolean {
  return this.selected.includes(id);
}
```

**实现逻辑**:
- 检查节点ID是否在选择列表中
- 返回布尔值

**使用示例**:
```typescript
if (selection.has('node_123')) {
  console.log('节点已被选中');
}
```

### 2.6 History 类详解

#### 2.6.1 类定义

**源文件**: [`packages/designer/src/document/history.ts`](packages/designer/src/document/history.ts)

```typescript
export class History implements IHistory {
  readonly document: IDocumentModel;
  private data: any[] = [];
  private cursor: number = -1;
  private state: HistoryState = 'idle';
  private emitter: IEventBus;
  
  constructor(
    document: IDocumentModel,
    getData: () => any,
    setData: (data: any) => void,
  ) {
    this.document = document;
    this.emitter = createModuleEventBus('History');
    this.getData = getData;
    this.setData = setData;
    this.record();
  }
}
```

#### 2.6.2 关键方法详解

##### 2.6.2.1 record() - 记录状态

**源码位置**: [`packages/designer/src/document/history.ts`](packages/designer/src/document/history.ts)

```typescript
@action
record(): void {
  if (this.state !== 'idle') {
    return;
  }
  const data = this.getData();
  
  // 如果当前不是最新状态，删除后续状态
  if (this.cursor < this.data.length - 1) {
    this.data = this.data.slice(0, this.cursor + 1);
  }
  
  // 添加新状态
  this.data.push(data);
  this.cursor++;
  
  // 限制历史记录数量
  if (this.data.length > MAX_HISTORY_SIZE) {
    this.data.shift();
    this.cursor--;
  }
  
  this.emitter.emit('change', this.state);
}
```

**实现逻辑**:
1. 检查当前状态，如果不是idle则不记录
2. 获取当前数据
3. 如果不是最新状态，删除后续状态
4. 添加新状态到历史记录
5. 限制历史记录数量（默认100条）
6. 发布状态变化事件

**使用示例**:
```typescript
// 记录状态
history.record();

// 在操作后自动记录
node.remove();  // 会自动触发history.record()
```

##### 2.6.2.2 undo() - 撤销

**源码位置**: [`packages/designer/src/document/history.ts`](packages/designer/src/document/history.ts)

```typescript
@action
undo(): void {
  if (this.state !== 'idle') {
    return;
  }
  if (this.cursor <= 0) {
    return;
  }
  
  this.state = 'undoing';
  this.cursor--;
  this.setData(this.data[this.cursor]);
  this.state = 'idle';
  this.emitter.emit('change', this.state);
}
```

**实现逻辑**:
1. 检查当前状态，如果不是idle则不执行
2. 检查是否可以撤销（cursor > 0）
3. 设置状态为undoing
4. 移动cursor到上一个状态
5. 恢复数据
6. 重置状态为idle
7. 发布状态变化事件

**使用示例**:
```typescript
// 撤销上一步操作
history.undo();
```

##### 2.6.2.3 redo() - 重做

**源码位置**: [`packages/designer/src/document/history.ts`](packages/designer/src/document/history.ts)

```typescript
@action
redo(): void {
  if (this.state !== 'idle') {
    return;
  }
  if (this.cursor >= this.data.length - 1) {
    return;
  }
  
  this.state = 'redoing';
  this.cursor++;
  this.setData(this.data[this.cursor]);
  this.state = 'idle';
  this.emitter.emit('change', this.state);
}
```

**实现逻辑**:
1. 检查当前状态，如果不是idle则不执行
2. 检查是否可以重做（cursor < length - 1）
3. 设置状态为redoing
4. 移动cursor到下一个状态
5. 恢复数据
6. 重置状态为idle
7. 发布状态变化事件

**使用示例**:
```typescript
// 重做上一步撤销的操作
history.redo();
```

##### 2.6.2.4 isSavePoint() - 检查是否为保存点

**源码位置**: [`packages/designer/src/document/history.ts`](packages/designer/src/document/history.ts)

```typescript
isSavePoint(): boolean {
  return this.cursor !== this.savePoint;
}
```

**实现逻辑**:
- 比较当前cursor和保存点
- 返回是否已修改

**使用示例**:
```typescript
// 检查文档是否已修改
if (history.isSavePoint()) {
  console.log('文档已修改，需要保存');
}
```

## 3. 交互与通信

### 3.1 模块内部数据流向

```
┌─────────────────────────────────────────────────────────────┐
│                    Designer 内部数据流                      │
│                                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐  │  │
│  │  │   Project   │  │ComponentMeta │  │  │
│  │  │              │  │              │  │  │
│  │  │  ┌────────┐ │  │  ┌────────┐ │  │  │
│  │  │  │Document│ │  │  │Metadata│ │  │  │
│  │  │  └────────┘ │  │  └────────┘ │  │  │
│  │  └──────────────┘  └──────────────┘  │  │
│  │                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐  │  │
│  │  │  Selection  │  │   History   │  │  │
│  │  └──────────────┘  └──────────────┘  │  │
│  │                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐  │  │
│  │  │    Dragon   │  │  Detecting  │  │  │
│  │  └──────────────┘  └──────────────┘  │  │
│  │                                        │  │
│  └──────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

### 3.2 与其他模块的具体交互方式

#### 3.2.1 与EditorCore交互

**交互方式**: 通过IoC容器

**代码示例**:
```typescript
// Editor中存储Designer
editor.set('designer', designerInstance);

// 其他模块获取Designer
const designer = editor.get('designer');
```

**API引用**:
- [`editor.get('designer')`](packages/editor-core/src/editor.ts:107) - 获取Designer实例

#### 3.2.2 与DocumentModel交互

**交互方式**: 通过Project管理DocumentModel

**代码示例**:
```typescript
// 创建文档
const doc = project.createDocument(schema);

// 获取当前文档
const currentDoc = project.currentDocument;

// 导出文档Schema
const schema = doc.export(IPublicEnumTransformStage.Save);
```

**API引用**:
- [`project.createDocument()`](packages/designer/src/project/project.ts:301) - 创建文档
- [`project.open()`](packages/designer/src/project/project.ts:309) - 打开文档
- [`document.export()`](packages/designer/src/document/document-model.ts:563) - 导出Schema

#### 3.2.3 与Simulator交互

**交互方式**: 通过Project挂载Simulator

**代码示例**:
```typescript
// 挂载模拟器
project.mountSimulator(simulatorHost);

// 获取模拟器
const simulator = project.simulator;

// 通知模拟器重新渲染
simulator.rerender();
```

**API引用**:
- [`project.mountSimulator()`](packages/designer/src/project/project.ts:363) - 挂载模拟器
- [`project.simulator`](packages/designer/src/project/project.ts:109) - 获取模拟器

#### 3.2.4 与ComponentMeta交互

**交互方式**: 通过Designer获取ComponentMeta

**代码示例**:
```typescript
// 获取组件元数据
const meta = designer.getComponentMeta('Button');

// 检查嵌套规则
const canNest = meta.checkNestingUp(node, parentNode);

// 获取元数据
const metadata = meta.getMetadata();
```

**API引用**:
- [`designer.getComponentMeta()`](packages/designer/src/designer.ts) - 获取组件元数据
- [`componentMeta.checkNestingUp()`](packages/designer/src/component-meta/index.ts) - 检查父级嵌套规则
- [`componentMeta.checkNestingDown()`](packages/designer/src/component-meta/index.ts) - 检查子级嵌套规则

## 4. 依赖关系

### 4.1 外部库依赖

| 依赖包 | 版本 | 用途 |
|--------|------|------|
| `@alilc/lowcode-editor-core` | ^1.1.0 | 编辑器核心（EventBus、Config等） |
| `@alilc/lowcode-types` | ^1.3.2 | 类型定义 |
| `@alilc/lowcode-utils` | ^1.3.2 | 工具函数 |
| `mobx` | ^6.3.0 | 响应式状态管理 |

### 4.2 内部模块依赖

| 模块 | 依赖方式 | 用途 |
|------|---------|------|
| `Project` | 直接导入 | 项目管理 |
| `DocumentModel` | 直接导入 | 文档模型 |
| `ComponentMeta` | 直接导入 | 组件元数据 |
| `Selection` | 直接导入 | 选择器 |
| `History` | 直接导入 | 历史记录 |
| `Dragon` | 直接导入 | 拖拽系统 |
| `Detecting` | 直接导入 | 悬停检测 |
| `Locating` | 直接导入 | 位置监听 |
| `ShellModelFactory` | 直接导入 | Shell模型工厂 |

### 4.3 依赖关系图

```mermaid
graph TD
    Designer[Designer] --> Project[Project]
    Designer --> ComponentMeta[ComponentMeta]
    Designer --> Selection[Selection]
    Designer --> History[History]
    Designer --> Dragon[Dragon]
    Designer --> Detecting[Detecting]
    Designer --> Locating[Locating]
    Designer --> ShellModelFactory[ShellModelFactory]
    
    Project --> DocumentModel[DocumentModel]
    Project --> SimulatorHost[SimulatorHost]
    
    DocumentModel --> Node[Node]
    DocumentModel --> Selection
    DocumentModel --> History
    
    Node --> Props[Props]
    Node --> NodeChildren[NodeChildren]
    
    ComponentMeta --> Configure[Configure]
    
    Designer --> EditorCore[Editor Core]
```

## 5. 关键技术点

### 5.1 应用的设计模式

#### 5.1.1 单例模式（Singleton Pattern）

**实现方式**: 通过EditorCore的IoC容器管理Designer实例

**代码示例**:
```typescript
// Editor中创建Designer实例
const designer = new Designer(editor, options);
editor.set('designer', designer);

// 其他模块获取Designer
const designer = editor.get('designer');
```

**优势**:
- 全局唯一实例
- 便于状态管理
- 避免重复创建

#### 5.1.2 工厂模式（Factory Pattern）

**实现方式**: ShellModelFactory创建Shell模型

**代码示例**:
```typescript
class ShellModelFactory {
  createSettingEntry(nodes: INode[]): ISettingTopEntry {
    return new SettingTopEntry(this.designer, nodes);
  }
  
  createNode(node: INode): IPublicModelNode {
    return new ShellNode(this.designer, node);
  }
}
```

**优势**:
- 统一创建接口
- 封装创建逻辑
- 便于扩展

#### 5.1.3 观察者模式（Observer Pattern）

**实现方式**: 使用EventBus实现事件发布订阅

**代码示例**:
```typescript
// 发布事件
designer.emitter.emit('document-open', documentModel);

// 订阅事件
designer.emitter.on('document-open', (doc) => {
  console.log('Document opened:', doc);
});
```

**优势**:
- 松耦合
- 易于扩展
- 支持多个订阅者

#### 5.1.4 策略模式（Strategy Pattern）

**实现方式**: PropsTransducer实现属性转换策略

**代码示例**:
```typescript
interface IPublicTypePropsTransducer {
  stage: IPublicEnumTransformStage | '*';
  consumer: (props: any, node: INode) => any;
}

// 不同的转换策略
const transducers: IPublicTypePropsTransducer[] = [
  {
    stage: IPublicEnumTransformStage.Init,
    consumer: (props, node) => {
      // 初始化阶段转换逻辑
      return transformForInit(props);
    }
  },
  {
    stage: IPublicEnumTransformStage.Render,
    consumer: (props, node) => {
      // 渲染阶段转换逻辑
      return transformForRender(props);
    }
  }
];
```

**优势**:
- 算法可替换
- 易于扩展
- 职责分离

### 5.2 技术难点的解决方案

#### 5.2.1 组件嵌套规则验证

**问题**: 如何确保组件只能嵌套在允许的父组件中

**解决方案**: 实现parentWhitelist和childWhitelist机制

**核心代码**:
```typescript
checkNestingUp(target: INode | IPublicTypeNodeSchema, parent: INode): boolean {
  const { parentWhitelist = [] } = this.getMetadata();
  if (parentWhitelist.length === 0) {
    return true;
  }
  return parentWhitelist.some((item) => {
    if (typeof item === 'string') {
      return parent.componentName === item;
    }
    if (typeof item === 'function') {
      return item(target, parent);
    }
    return false;
  });
}
```

**特点**:
- 支持字符串和函数两种形式
- 函数形式支持复杂判断逻辑
- 白名单为空时允许任何嵌套

#### 5.2.2 历史记录管理

**问题**: 如何高效管理撤销/重做历史记录

**解决方案**: 实现基于cursor的历史记录栈

**核心代码**:
```typescript
record(): void {
  if (this.state !== 'idle') {
    return;
  }
  const data = this.getData();
  
  // 如果当前不是最新状态，删除后续状态
  if (this.cursor < this.data.length - 1) {
    this.data = this.data.slice(0, this.cursor + 1);
  }
  
  // 添加新状态
  this.data.push(data);
  this.cursor++;
  
  // 限制历史记录数量
  if (this.data.length > MAX_HISTORY_SIZE) {
    this.data.shift();
    this.cursor--;
  }
  
  this.emitter.emit('change', this.state);
}
```

**特点**:
- 使用cursor指针管理当前状态
- 支持在历史中间插入新状态
- 限制历史记录数量防止内存溢出
- 状态机管理（idle/undoing/redoing）

#### 5.2.3 多文档管理

**问题**: 如何管理项目中的多个文档（页面）

**解决方案**: 实现Project类管理DocumentModel列表

**核心代码**:
```typescript
@obx.shallow readonly documents: IDocumentModel[] = [];
private documentsMap = new Map<string, DocumentModel>();

@computed get currentDocument(): IDocumentModel | null | undefined {
  return this.documents.find((doc) => doc.active);
}

createDocument(data?: IPublicTypeRootSchema): IDocumentModel {
  const doc = new DocumentModel(this, data || this?.data?.componentsTree?.[0]);
  this.documents.push(doc);
  this.documentsMap.set(doc.id, doc);
  return doc;
}
```

**特点**:
- 使用MobX响应式数组
- 使用Map快速查找文档
- 支持当前文档概念
- 支持文档激活/挂起

#### 5.2.4 属性转换机制

**问题**: 如何在不同阶段对属性进行不同的转换

**解决方案**: 实现PropsTransducer机制

**核心代码**:
```typescript
transformProps(
  props: any,
  node: INode,
  stage: IPublicEnumTransformStage,
): any {
  const componentName = node.componentName;
  const meta = this.getComponentMeta(componentName);
  const { propsTransducers = [] } = meta.getMetadata();
  let result = props;
  for (const transducer of propsTransducers) {
    if (transducer.stage === stage || transducer.stage === '*') {
      result = transducer.consumer(result, node);
    }
  }
  return result;
}
```

**特点**:
- 支持多个转换阶段
- 支持通配符'*'匹配所有阶段
- 转换器按顺序执行
- 每个转换器可以修改props

### 5.3 性能优化手段

#### 5.3.1 组件元数据缓存

**实现**: 使用Map缓存ComponentMeta实例

**代码**:
```typescript
readonly componentMetas = new Map<string, IComponentMeta>();

getComponentMeta(
  componentName: string,
  generateMetadata?: (componentName: string) => IPublicTypeComponentMetadata | null,
): IComponentMeta {
  let meta = this.componentMetas.get(componentName);
  if (!meta) {
    if (generateMetadata) {
      const metadata = generateMetadata(componentName);
      if (metadata) {
        meta = new ComponentMeta(this, componentName, metadata);
        this.componentMetas.set(componentName, meta);
      }
    }
  }
  return meta;
}
```

**优势**:
- 避免重复创建ComponentMeta
- 提升查询性能
- 减少内存占用

#### 5.3.2 MobX响应式优化

**实现**: 使用`@obx.shallow`装饰器

**代码**:
```typescript
@obx.shallow readonly documents: IDocumentModel[] = [];
@obx private _config: any = {};
@obx.ref private _i18n: any = {};
```

**优势**:
- `shallow`模式：只监听数组本身的引用变化
- `ref`模式：只监听对象的引用变化
- 减少响应式追踪开销
- 提升性能

#### 5.3.3 历史记录限制

**实现**: 限制历史记录数量

**代码**:
```typescript
const MAX_HISTORY_SIZE = 100;

if (this.data.length > MAX_HISTORY_SIZE) {
  this.data.shift();
  this.cursor--;
}
```

**优势**:
- 防止内存溢出
- 限制历史记录数量
- 保持性能稳定

### 5.4 安全性考虑

#### 5.4.1 嵌套规则验证

**实现**: parentWhitelist和childWhitelist机制

**代码示例**:
```typescript
checkNestingUp(target: INode | IPublicTypeNodeSchema, parent: INode): boolean {
  const { parentWhitelist = [] } = this.getMetadata();
  if (parentWhitelist.length === 0) {
    return true;
  }
  return parentWhitelist.some((item) => {
    if (typeof item === 'string') {
      return parent.componentName === item;
    }
    if (typeof item === 'function') {
      return item(target, parent);
    }
    return false;
  });
}
```

**特点**:
- 白名单机制，默认拒绝
- 支持字符串和函数形式
- 防止非法嵌套

#### 5.4.2 状态机保护

**实现**: 使用状态机防止并发操作

**代码示例**:
```typescript
private state: HistoryState = 'idle';

record(): void {
  if (this.state !== 'idle') {
    return;
  }
  // ... 记录逻辑
}

undo(): void {
  if (this.state !== 'idle') {
    return;
  }
  this.state = 'undoing';
  // ... 撤销逻辑
  this.state = 'idle';
}
```

**特点**:
- 防止并发操作
- 确保操作顺序
- 避免状态混乱

## 6. 总结

Designer模块是LowCodeEngine的设计器核心，提供了：

1. **完善的文档管理**：支持多文档、文档切换、文档导入导出
2. **强大的组件元数据系统**：组件描述、嵌套规则、属性转换
3. **灵活的选择器**：单选、多选、顶层节点过滤
4. **可靠的历史记录**：撤销/重做、保存点、状态机保护
5. **完整的拖拽系统**：拖拽、投放、位置检测
6. **属性转换机制**：多阶段转换、转换器链
7. **模拟器集成**：与渲染器无缝对接

该模块设计完善，功能强大，是整个低代码引擎的"设计器大脑"，负责管理所有设计时状态和逻辑。
