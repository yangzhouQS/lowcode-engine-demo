# EventBus 模块详细设计

## 1. 模块概述

### 1.1 功能定位

EventBus 是 LowCodeEngine 的事件总线模块，基于 Node.js 的 EventEmitter 实现，提供模块间的事件发布订阅机制。它是整个引擎的"神经系统"，负责模块间的通信和解耦。

### 1.2 核心职责

1. **事件发布**：发布事件到所有订阅者
2. **事件订阅**：订阅感兴趣的事件
3. **事件取消订阅**：取消事件订阅
4. **一次性订阅**：订阅事件并自动取消
5. **前置监听**：在其他监听器之前触发
6. **事件清理**：清理所有事件监听器
7. **日志集成**：集成日志系统记录事件

### 1.3 在整体架构中的位置

```
┌─────────────────────────────────────────────────────────────┐
│                    应用层 (Application)                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │   插件系统    │  │   面板组件    │  │   自定义扩展   │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                     Shell层 (Shell)                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Editor Core                             │  │
│  │  ┌──────────────────────────────────────────────┐  │  │
│  │  │          EventBus (本模块)           │  │  │
│  │  │  ┌────────────────────────────────────┐  │  │  │
│  │  │  │      EventEmitter (Node.js)      │  │  │  │
│  │  │  └────────────────────────────────────┘  │  │  │
│  │  └──────────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                   核心层 (Core)                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │  Designer    │  │  Renderer  │  │  Skeleton  │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## 2. 核心设计与实现

### 2.1 核心类/组件结构图

```mermaid
classDiagram
    class EventBus {
        -eventEmitter: EventEmitter
        -name: string
        +on(event, listener)
        +off(event, listener)
        +emit(event, ...args)
        +once(event, listener)
        +prependListener(event, listener)
        +removeAllListeners(event?)
        +listenerCount(event)
    }
    
    class EventEmitter {
        +on(event, listener)
        +off(event, listener)
        +emit(event, ...args)
        +once(event, listener)
        +prependListener(event, listener)
        +removeAllListeners(event?)
        +listenerCount(event)
        +eventNames()
        +setMaxListeners(n)
        +getMaxListeners()
    }
    
    class Logger {
        +log(level, message, ...args)
        +debug(message, ...args)
        +info(message, ...args)
        +warn(message, ...args)
        +error(message, ...args)
    }
    
    EventBus --> EventEmitter
    EventBus --> Logger
```

### 2.2 EventBus 类详解

#### 2.2.1 类定义

**源文件**: [`packages/editor-core/src/event-bus.ts`](packages/editor-core/src/event-bus.ts:18)

```typescript
export class EventBus implements IEventBus {
  private readonly eventEmitter: EventEmitter;
  private readonly name?: string;

  constructor(eventEmitter?: EventEmitter, name?: string) {
    this.eventEmitter = eventEmitter || new EventEmitter();
    this.name = name;
  }
}
```

**实现逻辑**:
1. 接受可选的EventEmitter实例
2. 如果不提供，创建新的EventEmitter
3. 可选的name用于日志标识

#### 2.2.2 关键方法详解

##### 2.2.2.1 on() - 订阅事件

**源码位置**: [`packages/editor-core/src/event-bus.ts:27-35`](packages/editor-core/src/event-bus.ts:27)

```typescript
on(event: string, listener: (...args: any[]) => void): () => void {
  this.eventEmitter.on(event, listener);
  return () => {
    this.off(event, listener);
  };
}
```

**实现逻辑**:
1. 调用EventEmitter的on方法订阅事件
2. 返回解绑函数
3. 解绑函数调用off方法取消订阅

**使用示例**:
```typescript
// 订阅事件
const dispose = eventBus.on('customEvent', (data) => {
  console.log('Event received:', data);
});

// 取消订阅
dispose();
```

##### 2.2.2.2 off() - 取消订阅

**源码位置**: [`packages/editor-core/src/event-bus.ts:37-40`](packages/editor-core/src/event-bus.ts:37)

```typescript
off(event: string, listener: (...args: any[]) => void): void {
  this.eventEmitter.off(event, listener);
}
```

**实现逻辑**:
- 调用EventEmitter的off方法取消订阅

**使用示例**:
```typescript
// 定义监听器
const listener = (data) => {
  console.log('Event received:', data);
};

// 订阅事件
eventBus.on('customEvent', listener);

// 取消订阅
eventBus.off('customEvent', listener);
```

##### 2.2.2.3 emit() - 发布事件

**源码位置**: [`packages/editor-core/src/event-bus.ts:42-47`](packages/editor-core/src/event-bus.ts:42)

```typescript
emit(event: string, ...args: any[]) {
  logger.debug(`[${this.name || 'EventBus'}] emit ${event}`, ...args);
  this.eventEmitter.emit(event, ...args);
}
```

**实现逻辑**:
1. 记录日志（debug级别）
2. 调用EventEmitter的emit方法发布事件
3. 传递事件名和参数

**使用示例**:
```typescript
// 发布事件
eventBus.emit('customEvent', { data: 'value' });

// 发布多个参数
eventBus.emit('customEvent', { data: 'value' }, { extra: 'info' });
```

##### 2.2.2.4 once() - 一次性订阅

**源码位置**: [`packages/editor-core/src/event-bus.ts:49-57`](packages/editor-core/src/event-bus.ts:49)

```typescript
once(event: string, listener: (...args: any[]) => void): () => void {
  this.eventEmitter.once(event, listener);
  return () => {
    this.off(event, listener);
  };
}
```

**实现逻辑**:
1. 调用EventEmitter的once方法订阅事件
2. 事件触发后自动取消订阅
3. 返回解绑函数（虽然通常不需要）

**使用示例**:
```typescript
// 一次性订阅
eventBus.once('init', (data) => {
  console.log('Initialized:', data);
  // 只会触发一次
});
```

##### 2.2.2.5 prependListener() - 前置监听

**源码位置**: [`packages/editor-core/src/event-bus.ts:59-67`](packages/editor-core/src/event-bus.ts:59)

```typescript
prependListener(event: string, listener: (...args: any[]) => void): () => void {
  this.eventEmitter.prependListener(event, listener);
  return () => {
    this.off(event, listener);
  };
}
```

**实现逻辑**:
1. 调用EventEmitter的prependListener方法
2. 监听器会被添加到监听器数组的前面
3. 返回解绑函数

**使用示例**:
```typescript
// 前置监听（在其他监听器之前触发）
eventBus.prependListener('customEvent', (data) => {
  console.log('First listener:', data);
});

// 普通监听
eventBus.on('customEvent', (data) => {
  console.log('Second listener:', data);
});
```

##### 2.2.2.6 removeAllListeners() - 清除所有监听器

**源码位置**: [`packages/editor-core/src/event-bus.ts:69-74`](packages/editor-core/src/event-bus.ts:69)

```typescript
removeAllListeners(event?: string): void {
  if (event) {
    this.eventEmitter.removeAllListeners(event);
  } else {
    this.eventEmitter.removeAllListeners();
  }
}
```

**实现逻辑**:
1. 如果指定了event，清除该事件的所有监听器
2. 如果没有指定event，清除所有事件的监听器

**使用示例**:
```typescript
// 清除指定事件的所有监听器
eventBus.removeAllListeners('customEvent');

// 清除所有事件的所有监听器
eventBus.removeAllListeners();
```

##### 2.2.2.7 listenerCount() - 获取监听器数量

**源码位置**: [`packages/editor-core/src/event-bus.ts:76-79`](packages/editor-core/src/event-bus.ts:76)

```typescript
listenerCount(event: string): number {
  return this.eventEmitter.listenerCount(event);
}
```

**实现逻辑**:
- 调用EventEmitter的listenerCount方法
- 返回指定事件的监听器数量

**使用示例**:
```typescript
// 获取监听器数量
const count = eventBus.listenerCount('customEvent');
console.log('Listener count:', count);
```

### 2.3 模块级EventBus创建

#### 2.3.1 createModuleEventBus函数

**源码位置**: [`packages/editor-core/src/event-bus.ts:82-87`](packages/editor-core/src/event-bus.ts:82)

```typescript
export function createModuleEventBus(name: string): IEventBus {
  const emitter = new EventEmitter();
  emitter.setMaxListeners(200);
  return new EventBus(emitter, name);
}
```

**实现逻辑**:
1. 创建新的EventEmitter实例
2. 设置最大监听器数量为200
3. 创建并返回EventBus实例

**使用示例**:
```typescript
// 创建模块级EventBus
const eventBus = createModuleEventBus('Designer');

// 使用EventBus
eventBus.on('node-add', (node) => {
  console.log('Node added:', node);
});
```

## 3. 交互与通信

### 3.1 模块内部数据流向

```
┌─────────────────────────────────────────────────────────────┐
│              EventBus 内部数据流                          │
│                                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │                                        │  │
│  │  ┌──────────────────────────────────────────┐  │  │
│  │  │         EventEmitter                   │  │  │
│  │  │  ┌────────────────────────────────┐   │  │  │
│  │  │  │  _events: Map<string, []>    │   │  │  │
│  │  │  └────────────────────────────────┘   │  │  │
│  │  │  ┌────────────────────────────────┐   │  │  │
│  │  │  │  _maxListeners: number      │   │  │  │
│  │  │  └────────────────────────────────┘   │  │  │
│  │  └──────────────────────────────────────────┘  │  │
│  │                                        │  │
│  │  ┌──────────────────────────────────────────┐  │  │
│  │  │         Logger                      │  │  │
│  │  └──────────────────────────────────────────┘  │  │
│  │                                        │  │
│  └──────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

### 3.2 与其他模块的具体交互方式

#### 3.2.1 与EditorCore交互

**交互方式**: EditorCore包含全局EventBus实例

**代码示例**:
```typescript
// Editor中创建EventBus
export class Editor extends EventEmitter {
  eventBus: EventBus;

  constructor(readonly viewName: string = 'global', readonly workspaceMode: boolean = false) {
    super();
    this.setMaxListeners(200);
    this.eventBus = new EventBus(this);
  }
}

// 使用EventBus
editor.eventBus.on('customEvent', (data) => {
  console.log('Event received:', data);
});

editor.eventBus.emit('customEvent', { data: 'value' });
```

**API引用**:
- [`editor.eventBus`](packages/editor-core/src/editor.ts) - 全局EventBus实例
- [`eventBus.on()`](packages/editor-core/src/event-bus.ts:27) - 订阅事件
- [`eventBus.emit()`](packages/editor-core/src/event-bus.ts:42) - 发布事件

#### 3.2.2 与Designer交互

**交互方式**: Designer包含模块级EventBus实例

**代码示例**:
```typescript
// Designer中创建EventBus
export class Designer implements IDesigner {
  readonly emitter: IEventBus;

  constructor(editor: IEditor, options: IDesignerOptions = {}) {
    this.editor = editor;
    this.emitter = createModuleEventBus('Designer');
    // ... 其他初始化
  }
}

// 使用EventBus
designer.emitter.on('document-open', (doc) => {
  console.log('Document opened:', doc);
});

designer.emitter.emit('document-open', documentModel);
```

**API引用**:
- [`designer.emitter`](packages/designer/src/designer.ts) - Designer的EventBus实例
- [`designer.postEvent()`](packages/designer/src/designer.ts) - 发布事件

#### 3.2.3 与DocumentModel交互

**交互方式**: DocumentModel包含模块级EventBus实例

**代码示例**:
```typescript
// DocumentModel中创建EventBus
export class DocumentModel implements IDocumentModel {
  private emitter: IEventBus;

  constructor(project: IProject, schema?: IPublicTypeRootSchema) {
    makeObservable(this);
    this.project = project;
    this.designer = this.project?.designer;
    this.emitter = createModuleEventBus('DocumentModel');
    // ... 其他初始化
  }
}

// 使用EventBus
document.emitter.on('nodecreate', (node) => {
  console.log('Node created:', node);
});

document.emitter.emit('nodecreate', node);
```

**API引用**:
- [`document.emitter`](packages/designer/src/document/document-model.ts) - DocumentModel的EventBus实例
- [`document.onNodeCreate()`](packages/designer/src/document/document-model.ts:882) - 监听节点创建

#### 3.2.4 与Node交互

**交互方式**: Node包含模块级EventBus实例

**代码示例**:
```typescript
// Node中创建EventBus
export class Node<Schema extends IPublicTypeNodeSchema = IPublicTypeNodeSchema> implements IBaseNode {
  private emitter: IEventBus;

  constructor(readonly document: IDocumentModel, nodeSchema: Schema) {
    makeObservable(this);
    // ... 其他初始化
    this.isInited = true;
    this.emitter = createModuleEventBus('Node');
    // ... 其他初始化
  }
}

// 使用EventBus
node.emitter.on('visibleChange', (visible) => {
  console.log('Node visibility changed:', visible);
});

node.emitter.emit('visibleChange', true);
```

**API引用**:
- [`node.emitter`](packages/designer/src/document/node/node.ts) - Node的EventBus实例
- [`node.onVisibleChange()`](packages/designer/src/document/node/node.ts:805) - 监听可见性变化

## 4. 依赖关系

### 4.1 外部库依赖

| 依赖包 | 版本 | 用途 |
|--------|------|------|
| `events` | 内置 | EventEmitter，事件发射器 |
| `strict-event-emitter-types` | ^2.0.0 | EventEmitter类型定义 |

### 4.2 内部模块依赖

| 模块 | 依赖方式 | 用途 |
|------|---------|------|
| `Logger` | 直接导入 | 日志系统 |

### 4.3 依赖关系图

```mermaid
graph TD
    EventBus[EventBus] --> EventEmitter[EventEmitter]
    EventBus --> Logger[Logger]
    
    EditorCore[Editor Core] --> EventBus
    Designer[Designer] --> EventBus
    DocumentModel[DocumentModel] --> EventBus
    Node[Node] --> EventBus
    
    EditorCore --> Logger
```

## 5. 关键技术点

### 5.1 应用的设计模式

#### 5.1.1 观察者模式（Observer Pattern）

**实现方式**: 基于EventEmitter的发布订阅模式

**代码示例**:
```typescript
export class EventBus implements IEventBus {
  private readonly eventEmitter: EventEmitter;

  on(event: string, listener: (...args: any[]) => void): () => void {
    this.eventEmitter.on(event, listener);
    return () => {
      this.off(event, listener);
    };
  }

  emit(event: string, ...args: any[]) {
    logger.debug(`[${this.name || 'EventBus'}] emit ${event}`, ...args);
    this.eventEmitter.emit(event, ...args);
  }
}
```

**优势**:
- 松耦合：发布者和订阅者互不依赖
- 异步：支持异步事件处理
- 可扩展：易于添加新的事件类型
- 多对多：一个事件可以有多个订阅者，一个订阅者可以订阅多个事件

#### 5.1.2 Disposable模式

**实现方式**: 事件监听返回解绑函数

**代码示例**:
```typescript
on(event: string, listener: (...args: any[]) => void): () => void {
  this.eventEmitter.on(event, listener);
  return () => {
    this.off(event, listener);
  };
}
```

**优势**:
- 自动清理：调用解绑函数即可清理
- 防止内存泄漏：确保监听器被正确清理
- 易于使用：不需要手动管理监听器

### 5.2 技术难点的解决方案

#### 5.2.1 事件监听器内存泄漏问题

**问题**: 事件监听器未正确清理导致内存泄漏

**解决方案**: Disposable模式，返回解绑函数

**核心代码**:
```typescript
on(event: string, listener: (...args: any[]) => void): () => void {
  this.eventEmitter.on(event, listener);
  return () => {
    this.off(event, listener);
  };
}
```

**特点**:
- 返回解绑函数
- 调用解绑函数即可清理
- 防止内存泄漏

**最佳实践**:
```typescript
class MyPlugin {
  private disposes: (() => void)[] = [];

  init(editor) {
    const dispose1 = editor.eventBus.on('event1', this.handle1);
    const dispose2 = editor.eventBus.on('event2', this.handle2);
    
    this.disposes.push(dispose1, dispose2);
  }

  destroy() {
    this.disposes.forEach(dispose => dispose());
  }
}
```

#### 5.2.2 事件监听器数量限制

**问题**: 单个事件的监听器过多可能导致性能问题

**解决方案**: 设置最大监听器数量

**核心代码**:
```typescript
export function createModuleEventBus(name: string): IEventBus {
  const emitter = new EventEmitter();
  emitter.setMaxListeners(200);
  return new EventBus(emitter, name);
}
```

**特点**:
- 默认最大监听器数量为200
- 超过限制会发出警告
- 防止内存泄漏

#### 5.2.3 事件监听器顺序控制

**问题**: 需要控制监听器的执行顺序

**解决方案**: 提供prependListener方法

**核心代码**:
```typescript
prependListener(event: string, listener: (...args: any[]) => void): () => void {
  this.eventEmitter.prependListener(event, listener);
  return () => {
    this.off(event, listener);
  };
}
```

**特点**:
- 监听器被添加到监听器数组的前面
- 在其他监听器之前触发
- 支持优先级控制

**使用场景**:
```typescript
// 前置监听（在其他监听器之前触发）
eventBus.prependListener('customEvent', (data) => {
  console.log('First listener:', data);
  // 可以在这里做一些预处理或拦截
});

// 普通监听
eventBus.on('customEvent', (data) => {
  console.log('Second listener:', data);
});
```

### 5.3 性能优化手段

#### 5.3.1 事件监听器数量限制

**实现**: 设置最大监听器数量

**代码**:
```typescript
export function createModuleEventBus(name: string): IEventBus {
  const emitter = new EventEmitter();
  emitter.setMaxListeners(200);
  return new EventBus(emitter, name);
}
```

**优势**:
- 防止内存泄漏
- 限制单个事件的监听器数量
- 提供警告提示

#### 5.3.2 日志优化

**实现**: 只在debug级别记录事件

**代码**:
```typescript
emit(event: string, ...args: any[]) {
  logger.debug(`[${this.name || 'EventBus'}] emit ${event}`, ...args);
  this.eventEmitter.emit(event, ...args);
}
```

**优势**:
- 生产环境不记录日志
- 减少日志开销
- 便于调试

### 5.4 安全性考虑

#### 5.4.1 事件监听器错误隔离

**实现**: EventEmitter自动隔离监听器错误

**特点**:
- 一个监听器的错误不会影响其他监听器
- 错误会通过'error'事件发出
- 需要监听'error'事件来处理错误

**代码示例**:
```typescript
// 监听错误事件
eventBus.on('error', (err) => {
  console.error('EventBus error:', err);
});

// 订阅事件
eventBus.on('customEvent', (data) => {
  // 如果这里抛出错误，不会影响其他监听器
  console.log('Event received:', data);
});
```

#### 5.4.2 事件监听器清理

**实现**: 提供removeAllListeners方法

**代码**:
```typescript
removeAllListeners(event?: string): void {
  if (event) {
    this.eventEmitter.removeAllListeners(event);
  } else {
    this.eventEmitter.removeAllListeners();
  }
}
```

**特点**:
- 支持清除指定事件的所有监听器
- 支持清除所有事件的所有监听器
- 防止内存泄漏

## 6. 总结

EventBus模块是LowCodeEngine的事件总线核心，提供了：

1. **完善的事件发布订阅机制**：on、off、emit、once
2. **灵活的监听器管理**：prependListener、removeAllListeners、listenerCount
3. **Disposable模式**：返回解绑函数，防止内存泄漏
4. **模块级EventBus**：createModuleEventBus创建独立的EventBus
5. **日志集成**：自动记录事件发布
6. **监听器数量限制**：防止内存泄漏
7. **监听器顺序控制**：prependListener支持优先级
8. **错误隔离**：监听器错误不会影响其他监听器

该模块设计简洁高效，功能完善，是整个低代码引擎的"神经系统"，负责模块间的通信和解耦。
