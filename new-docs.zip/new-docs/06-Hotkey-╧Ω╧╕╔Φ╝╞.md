# Hotkey 模块详细设计

## 1. 模块概述

### 1.1 功能定位

Hotkey 是 LowCodeEngine 的快捷键管理模块，负责管理编辑器的键盘快捷键。它支持单键、组合键、序列键等多种快捷键形式，提供灵活的快捷键绑定和触发机制。

### 1.2 核心职责

1. **快捷键绑定**：绑定快捷键到回调函数
2. **快捷键解绑**：解绑快捷键
3. **快捷键触发**：监听键盘事件并触发对应的快捷键
4. **序列支持**：支持按键序列（如 `g g`）
5. **跨平台支持**：自动处理不同平台的修饰键（Mac的Cmd vs Windows的Ctrl）
6. **快捷键冲突处理**：处理快捷键冲突

### 1.3 在整体架构中的位置

```
┌─────────────────────────────────────────────────────────────┐
│                    应用层 (Application)                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │   插件系统    │  │   面板组件    │  │   自定义扩展   │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                     Shell层 (Shell)                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Editor Core                             │  │
│  │  ┌──────────────────────────────────────────────┐  │  │
│  │  │          Hotkey (本模块)            │  │  │
│  │  │  ┌────────────────────────────────────┐  │  │  │
│  │  │  │  hotkeys: Map<string, []> │  │  │  │
│  │  │  │  sequences: Map<string, []>  │  │  │  │
│  │  │  │  keyMaps: Object                │  │  │  │
│  │  │  └────────────────────────────────────┘  │  │  │
│  │  └──────────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## 2. 核心设计与实现

### 2.1 核心类/组件结构图

```mermaid
classDiagram
    class Hotkey {
        -hotkeys: Map
        -sequences: Map
        -keyMaps: Object
        +bind(key, handler)
        +unbind(key, handler)
        +handleKeyDown(e)
        +handleKeyUp(e)
        +parseKey(key)
        +resetSequences()
    }
    
    class KeyMap {
        +MAP: Object
        +KEYCODE_MAP: Object
        +SHIFT_MAP: Object
        +SPECIAL_ALIASES: Object
    }
    
    Hotkey --> KeyMap
```

### 2.2 Hotkey 类详解

#### 2.2.1 类定义

**源文件**: [`packages/editor-core/src/hotkey.ts`](packages/editor-core/src/hotkey.ts)

```typescript
export class Hotkey implements IHotkey {
  private hotkeys = new Map<string, Array<() => void>>();

  private sequences = new Map<string, Array<{ handler: () => void; resetTimer: number }>>();

  private keyMaps: any;
}
```

**实现逻辑**:
1. 存储快捷键映射（Map）
2. 存储序列快捷键映射（Map）
3. 存储按键映射表

#### 2.2.2 关键方法详解

##### 2.2.2.1 bind() - 绑定快捷键

**源码位置**: [`packages/editor-core/src/hotkey.ts`](packages/editor-core/src/hotkey.ts)

```typescript
bind(key: string, handler: () => void): () => void {
  const keys = this.parseKey(key);
  
  if (keys.length === 1) {
    // 单个快捷键
    const k = keys[0];
    let handlers = this.hotkeys.get(k);
    if (!handlers) {
      handlers = [];
      this.hotkeys.set(k, handlers);
    }
    handlers.push(handler);
  } else {
    // 序列快捷键
    const seqKey = keys.join(',');
    let handlers = this.sequences.get(seqKey);
    if (!handlers) {
      handlers = [];
      this.sequences.set(seqKey, handlers);
    }
    handlers.push({
      handler,
      resetTimer: 0,
    });
  }
  
  return () => {
    this.unbind(key, handler);
  };
}
```

**实现逻辑**:
1. 解析快捷键字符串
2. 如果是单个快捷键，添加到hotkeys映射
3. 如果是序列快捷键，添加到sequences映射
4. 返回解绑函数

**使用示例**:
```typescript
// 绑定单个快捷键
const dispose = hotkey.bind('cmd+s', () => {
  console.log('Save');
});

// 绑定序列快捷键
hotkey.bind('g,g', () => {
  console.log('Go to line');
});

// 取消绑定
dispose();
```

##### 2.2.2.2 unbind() - 解绑快捷键

**源码位置**: [`packages/editor-core/src/hotkey.ts`](packages/editor-core/src/hotkey.ts)

```typescript
unbind(key: string, handler: () => void): void {
  const keys = this.parseKey(key);
  
  if (keys.length === 1) {
    // 单个快捷键
    const k = keys[0];
    const handlers = this.hotkeys.get(k);
    if (handlers) {
      const index = handlers.indexOf(handler);
      if (index > -1) {
        handlers.splice(index, 1);
        if (handlers.length === 0) {
          this.hotkeys.delete(k);
        }
      }
    }
  } else {
    // 序列快捷键
    const seqKey = keys.join(',');
    const handlers = this.sequences.get(seqKey);
    if (handlers) {
      const index = handlers.findIndex((item) => item.handler === handler);
      if (index > -1) {
        handlers.splice(index, 1);
        if (handlers.length === 0) {
          this.sequences.delete(seqKey);
        }
      }
    }
  }
}
```

**实现逻辑**:
1. 解析快捷键字符串
2. 如果是单个快捷键，从hotkeys映射中删除
3. 如果是序列快捷键，从sequences映射中删除
4. 清理空映射

**使用示例**:
```typescript
// 定义处理函数
const saveHandler = () => {
  console.log('Save');
};

// 绑定快捷键
hotkey.bind('cmd+s', saveHandler);

// 解绑快捷键
hotkey.unbind('cmd+s', saveHandler);
```

##### 2.2.2.3 handleKeyDown() - 处理按键按下

**源码位置**: [`packages/editor-core/src/hotkey.ts`](packages/editor-core/src/hotkey.ts)

```typescript
handleKeyDown(e: KeyboardEvent): void {
  const key = this.getKeyFromEvent(e);
  
  // 检查单个快捷键
  const handlers = this.hotkeys.get(key);
  if (handlers) {
    e.preventDefault();
    handlers.forEach((handler) => handler());
    return;
  }
  
  // 检查序列快捷键
  this.checkSequences(key);
}
```

**实现逻辑**:
1. 从事件中提取按键
2. 检查是否有匹配的单个快捷键
3. 如果有，阻止默认行为并触发处理函数
4. 检查序列快捷键

**使用示例**:
```typescript
// 监听键盘事件
document.addEventListener('keydown', (e) => {
  hotkey.handleKeyDown(e);
});
```

##### 2.2.2.4 handleKeyUp() - 处理按键抬起

**源码位置**: [`packages/editor-core/src/hotkey.ts`](packages/editor-core/src/hotkey.ts)

```typescript
handleKeyUp(e: KeyboardEvent): void {
  // 处理按键抬起事件
  // 可以用于重置序列状态
}
```

**实现逻辑**:
- 处理按键抬起事件
- 可以用于重置序列状态

**使用示例**:
```typescript
// 监听键盘事件
document.addEventListener('keyup', (e) => {
  hotkey.handleKeyUp(e);
});
```

##### 2.2.2.5 parseKey() - 解析快捷键字符串

**源码位置**: [`packages/editor-core/src/hotkey.ts`](packages/editor-core/src/hotkey.ts)

```typescript
parseKey(key: string): string[] {
  // 解析快捷键字符串
  // 支持格式：'cmd+s', 'ctrl+shift+s', 'g,g'
  return key.split(',').map((k) => this.normalizeKey(k.trim()));
}
```

**实现逻辑**:
1. 按逗号分割序列
2. 规范化每个按键
3. 返回按键数组

**使用示例**:
```typescript
// 解析单个快捷键
const keys = hotkey.parseKey('cmd+s');
// 返回: ['cmd+s']

// 解析序列快捷键
const keys = hotkey.parseKey('g,g');
// 返回: ['g', 'g']
```

##### 2.2.2.6 resetSequences() - 重置序列

**源码位置**: [`packages/editor-core/src/hotkey.ts`](packages/editor-core/src/hotkey.ts)

```typescript
resetSequences() {
  // 重置所有序列状态
  this.sequences.forEach((handlers) => {
    handlers.forEach((item) => {
      if (item.resetTimer) {
        clearTimeout(item.resetTimer);
        item.resetTimer = 0;
      }
    });
  });
}
```

**实现逻辑**:
1. 遍历所有序列
2. 清除所有重置定时器
3. 重置序列状态

**使用示例**:
```typescript
// 重置序列状态
hotkey.resetSequences();
```

### 2.3 按键映射表

#### 2.3.1 MAP - 按键名称映射

**源码位置**: [`packages/editor-core/src/hotkey.ts`](packages/editor-core/src/hotkey.ts)

```typescript
const MAP = {
  'backspace': 8,
  'tab': 9,
  'enter': 13,
  'shift': 16,
  'ctrl': 17,
  'alt': 18,
  'pause/break': 19,
  'caps lock': 20,
  'escape': 27,
  'space': 32,
  'page up': 33,
  'page down': 34,
  'end': 35,
  'home': 36,
  'left arrow': 37,
  'up arrow': 38,
  'right arrow': 39,
  'down arrow': 40,
  'insert': 45,
  'delete': 46,
  '0': 48,
  '1': 49,
  '2': 50,
  '3': 51,
  '4': 52,
  '5': 53,
  '6': 54,
  '7': 55,
  '8': 56,
  '9': 57,
  'a': 65,
  'b': 66,
  'c': 67,
  'd': 68,
  'e': 69,
  'f': 70,
  'g': 71,
  'h': 72,
  'i': 73,
  'j': 74,
  'k': 75,
  'l': 76,
  'm': 77,
  'n': 78,
  'o': 79,
  'p': 80,
  'q': 81,
  'r': 82,
  's': 83,
  't': 84,
  'u': 85,
  'v': 86,
  'w': 87,
  'x': 88,
  'y': 89,
  'z': 90,
  'left window key': 91,
  'right window key': 92,
  'select key': 93,
  'numpad 0': 96,
  'numpad 1': 97,
  'numpad 2': 98,
  'numpad 3': 99,
  'numpad 4': 100,
  'numpad 5': 101,
  'numpad 6': 102,
  'numpad 7': 103,
  'numpad 8': 104,
  'numpad 9': 105,
  'multiply': 106,
  'add': 107,
  'subtract': 109,
  'decimal point': 110,
  'divide': 111,
  'f1': 112,
  'f2': 113,
  'f3': 114,
  'f4': 115,
  'f5': 116,
  'f6': 117,
  'f7': 118,
  'f8': 119,
  'f9': 120,
  'f10': 121,
  'f11': 122,
  'f12': 123,
  'f13': 124,
  'f14': 125,
  'f15': 126,
  'f16': 127,
  'f17': 128,
  'f18': 129,
  'f19': 130,
  'f20': 131,
  'f21': 132,
  'f22': 133,
  'f23': 134,
  'f24': 135,
  'num lock': 144,
  'scroll lock': 145,
  'semi-colon': 186,
  'equal sign': 187,
  'comma': 188,
  'dash': 189,
  'period': 190,
  'forward slash': 191,
  'grave accent': 192,
  'open bracket': 219,
  'back slash': 220,
  'close bracket': 221,
  'single quote': 222,
};
```

#### 2.3.2 KEYCODE_MAP - 按键码映射

**源码位置**: [`packages/editor-core/src/hotkey.ts`](packages/editor-core/src/hotkey.ts)

```typescript
const KEYCODE_MAP = {
  8: 'backspace',
  9: 'tab',
  13: 'enter',
  16: 'shift',
  17: 'ctrl',
  18: 'alt',
  19: 'pause/break',
  20: 'caps lock',
  27: 'escape',
  32: 'space',
  33: 'page up',
  34: 'page down',
  35: 'end',
  36: 'home',
  37: 'left arrow',
  38: 'up arrow',
  39: 'right arrow',
  40: 'down arrow',
  45: 'insert',
  46: 'delete',
  // ... 更多映射
};
```

#### 2.3.3 SHIFT_MAP - Shift键映射

**源码位置**: [`packages/editor-core/src/hotkey.ts`](packages/editor-core/src/hotkey.ts)

```typescript
const SHIFT_MAP = {
  '`': '~',
  '1': '!',
  '2': '@',
  '3': '#',
  '4': '$',
  '5': '%',
  '6': '^',
  '7': '&',
  '8': '*',
  '9': '(',
  '0': ')',
  '-': '_',
  '=': '+',
  '[': '{',
  ']': '}',
  '\\': '|',
  ';': ':',
  "'": '"',
  ',': '<',
  '.': '>',
  '/': '?',
};
```

#### 2.3.4 SPECIAL_ALIASES - 特殊别名

**源码位置**: [`packages/editor-core/src/hotkey.ts`](packages/editor-core/src/hotkey.ts)

```typescript
const SPECIAL_ALIASES = {
  'option': 'alt',
  'command': 'meta',
  'return': 'enter',
  'escape': 'esc',
  'mod': /Mac|iPod|iPhone|iPad/.test(navigator.platform) ? 'meta' : 'ctrl',
};
```

## 3. 交互与通信

### 3.1 模块内部数据流向

```
┌─────────────────────────────────────────────────────────────┐
│              Hotkey 内部数据流                           │
│                                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐  │  │
│  │  │   hotkeys   │  │  sequences  │  │  │
│  │  │   (Map)     │  │   (Map)     │  │  │
│  │  └──────────────┘  └──────────────┘  │  │
│  │                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐  │  │
│  │  │   MAP       │  │ KEYCODE_MAP │  │  │
│  │  └──────────────┘  └──────────────┘  │  │
│  │                                        │  │
│  └──────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

### 3.2 与其他模块的具体交互方式

#### 3.2.1 与EditorCore交互

**交互方式**: EditorCore使用hotkey实例

**代码示例**:
```typescript
// Editor中创建Hotkey
const hotkey = new Hotkey();

// 绑定快捷键
hotkey.bind('cmd+s', () => {
  console.log('Save');
});

// 监听键盘事件
document.addEventListener('keydown', (e) => {
  hotkey.handleKeyDown(e);
});
```

**API引用**:
- [`hotkey.bind()`](packages/editor-core/src/hotkey.ts) - 绑定快捷键
- [`hotkey.unbind()`](packages/editor-core/src/hotkey.ts) - 解绑快捷键
- [`hotkey.handleKeyDown()`](packages/editor-core/src/hotkey.ts) - 处理按键按下

## 4. 依赖关系

### 4.1 外部库依赖

| 依赖包 | 版本 | 用途 |
|--------|------|------|
| 无 | - | 纯JavaScript实现 |

### 4.2 内部模块依赖

| 模块 | 依赖方式 | 用途 |
|------|---------|------|
| 无 | - | 独立模块 |

## 5. 关键技术点

### 5.1 应用的设计模式

#### 5.1.1 命令模式（Command Pattern）

**实现方式**: 快捷键绑定到回调函数

**代码示例**:
```typescript
bind(key: string, handler: () => void): () => void {
  const keys = this.parseKey(key);
  // ... 绑定逻辑
  
  return () => {
    this.unbind(key, handler);
  };
}
```

**优势**:
- 封装操作
- 易于扩展
- 支持解绑

### 5.2 技术难点的解决方案

#### 5.2.1 跨平台修饰键问题

**问题**: Mac使用Cmd键，Windows使用Ctrl键

**解决方案**: 使用mod别名自动适配

**核心代码**:
```typescript
const SPECIAL_ALIASES = {
  'option': 'alt',
  'command': 'meta',
  'return': 'enter',
  'escape': 'esc',
  'mod': /Mac|iPod|iPhone|iPad/.test(navigator.platform) ? 'meta' : 'ctrl',
};
```

**特点**:
- 自动检测平台
- Mac使用meta（Cmd）
- 其他平台使用ctrl

#### 5.2.2 序列快捷键实现

**问题**: 如何实现按键序列（如 `g g`）？

**解决方案**: 使用定时器延迟重置

**核心代码**:
```typescript
checkSequences(key: string) {
  // 检查序列快捷键
  // 使用定时器延迟重置序列状态
}
```

**特点**:
- 支持按键序列
- 自动重置序列状态
- 防止误触发

### 5.3 性能优化手段

#### 5.3.1 使用Map存储快捷键

**实现**: 使用Map存储快捷键映射

**代码**:
```typescript
private hotkeys = new Map<string, Array<() => void>>();
```

**优势**:
- O(1)时间复杂度查找
- 快速定位快捷键
- 减少遍历开销

## 6. 总结

Hotkey模块是LowCodeEngine的快捷键管理核心，提供了：

1. **完善的快捷键绑定**：bind、unbind方法
2. **灵活的快捷键格式**：单键、组合键、序列键
3. **跨平台支持**：自动适配不同平台的修饰键
4. **序列快捷键支持**：支持按键序列
5. **高效的查找机制**：Map存储，O(1)查找
6. **完整的按键映射**：按键名称、按键码、Shift键映射

该模块设计简洁高效，功能完善，是整个低代码引擎的"快捷键管理器"，负责管理所有键盘快捷键。
