# EditorCore 模块详细设计

## 1. 模块概述

### 1.1 功能定位

EditorCore 是 LowCodeEngine 的核心编辑器模块，负责整个编辑器的生命周期管理、依赖注入、事件总线、配置管理等基础功能。它是引擎的"大脑"，协调其他所有模块的工作。

### 1.2 核心职责

1. **编辑器生命周期管理**：管理编辑器的初始化、运行和销毁
2. **依赖注入容器（IoC Container）**：提供依赖注入和获取机制
3. **事件总线（Event Bus）**：提供事件发布和订阅机制
4. **配置管理**：管理引擎的全局配置
5. **插件加载与管理**：协调插件的加载和初始化
6. **物料（Assets）管理**：管理物料包的加载和转换

### 1.3 在整体架构中的位置

```
┌─────────────────────────────────────────────────────────────┐
│                    应用层 (Application)                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │   插件系统    │  │   面板组件    │  │   自定义扩展   │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                     Shell层 (Shell)                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Editor Core (本模块)              │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  │  │
│  │  │ EventBus │  │  Config  │  │   DI      │  │  │
│  │  └──────────┘  └──────────┘  └──────────┘  │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                   核心层 (Core)                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │  Designer    │  │  Renderer  │  │  Skeleton  │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## 2. 核心设计与实现

### 2.1 核心类/组件结构图

```mermaid
classDiagram
    class Editor {
        -context: Map
        -eventBus: EventBus
        -config: EditorConfig
        -components: PluginClassSet
        -hooks: HookConfig[]
        -waits: Map
        +init(config, components)
        +get(key)
        +set(key, value)
        +onceGot(key)
        +onGot(key, fn)
        +destroy()
    }
    
    class EventBus {
        -eventEmitter: EventEmitter
        -name: string
        +on(event, listener)
        +off(event, listener)
        +emit(event, ...args)
        +prependListener(event, listener)
    }
    
    class EngineConfig {
        -config: Object
        -waits: Map
        -preference: Preference
        +get(key, defaultValue)
        +set(key, value)
        +has(key)
        +setConfig(config)
        +onceGot(key)
        +onGot(key, fn)
        +getPreference()
    }
    
    class Preference {
        -storage: Storage
        +get(key, defaultValue)
        +set(key, value)
        +remove(key)
    }
    
    Editor --> EventBus
    Editor --> EngineConfig
    EngineConfig --> Preference
```

### 2.2 Editor 类详解

#### 2.2.1 类定义

**源文件**: [`packages/editor-core/src/editor.ts`](packages/editor-core/src/editor.ts:70)

```typescript
export class Editor extends EventEmitter implements IEditor {
  // IoC容器
  @obx.shallow private context = new Map<IPublicTypeEditorValueKey, any>();

  // 事件总线
  eventBus: EventBus;

  // 配置
  config?: EditorConfig;

  // 组件集合
  components?: PluginClassSet;

  // 生命周期钩子
  private hooks: HookConfig[] = [];

  // 等待队列
  private waits = new Map<
    IPublicTypeEditorValueKey,
    Array<{
      once?: boolean;
      resolve: (data: any) => void;
    }>
  >();

  constructor(readonly viewName: string = 'global', readonly workspaceMode: boolean = false) {
    super();
    this.setMaxListeners(200);
    this.eventBus = new EventBus(this);
  }
}
```

#### 2.2.2 关键方法详解

##### 2.2.2.1 get() - 获取依赖

**源码位置**: [`packages/editor-core/src/editor.ts:107-111`](packages/editor-core/src/editor.ts:107)

```typescript
get<T = undefined, KeyOrType = any>(
    keyOrType: KeyOrType,
  ): IPublicTypeEditorGetResult<T, KeyOrType> | undefined {
  return this.context.get(keyOrType as any);
}
```

**实现逻辑**:
- 从IoC容器（Map）中获取指定类型的依赖
- 支持泛型，提供类型安全的依赖获取
- 如果依赖不存在，返回undefined

**使用示例**:
```typescript
const designer = editor.get('designer');
const project = editor.get('project');
```

##### 2.2.2.2 set() - 设置依赖

**源码位置**: [`packages/editor-core/src/editor.ts:117-127`](packages/editor-core/src/editor.ts:117)

```typescript
set(key: IPublicTypeEditorValueKey, data: any): void | Promise<void> {
  if (key === 'assets') {
    return this.setAssets(data);
  }
  // 存储到engineConfig
  if (!keyBlacklist.includes(key as string)) {
    engineConfig.set(key as any, data);
  }
  this.context.set(key, data);
  this.notifyGot(key);
}
```

**实现逻辑**:
1. 特殊处理`assets`，调用`setAssets`方法
2. 将非黑名单的key存储到`engineConfig`
3. 将所有依赖存储到IoC容器
4. 触发等待队列的回调

**黑名单列表**:
```typescript
const keyBlacklist = [
  'designer',
  'skeleton',
  'currentDocument',
  'simulator',
  'plugins',
  'setters',
  'material',
  'innerHotkey',
  'innerPlugins',
];
```

##### 2.2.2.3 onceGot() - 异步等待依赖

**源码位置**: [`packages/editor-core/src/editor.ts:211-219`](packages/editor-core/src/editor.ts:211)

```typescript
onceGot<T = undefined, KeyOrType extends IPublicTypeEditorValueKey = any>(
  keyOrType: KeyOrType,
): Promise<IPublicTypeEditorGetResult<T, KeyOrType>> {
  const x = this.context.get(keyOrType);
  if (x !== undefined) {
    return Promise.resolve(x);
  }
  return new Promise((resolve) => {
    this.setWait(keyOrType, resolve, true);
  });
}
```

**实现逻辑**:
1. 首先检查依赖是否已存在
2. 如果存在，直接返回Promise.resolve
3. 如果不存在，创建Promise并注册到等待队列
4. `once=true`表示只触发一次

**使用场景**:
```typescript
// 等待simulator就绪
const simulator = await editor.onceGot('simulator');

// 等待assets加载完成
const assets = await editor.onceGot('assets');
```

##### 2.2.2.4 onGot() - 监听依赖变化

**源码位置**: [`packages/editor-core/src/editor.ts:221-233`](packages/editor-core/src/editor.ts:221)

```typescript
onGot<T = undefined, KeyOrType extends IPublicTypeEditorValueKey = any>(
  keyOrType: KeyOrType,
  fn: (data: IPublicTypeEditorGetResult<T, KeyOrType>) => void,
): () => void {
  const x = this.context.get(keyOrType);
  if (x !== undefined) {
    fn(x);
  }
  this.setWait(keyOrType, fn);
  return () => {
    this.delWait(keyOrType, fn);
  };
}
```

**实现逻辑**:
1. 如果依赖已存在，立即调用回调
2. 注册回调到等待队列
3. 返回解绑函数

**使用场景**:
```typescript
// 监听simulator变化
const dispose = editor.onGot('simulator', (simulator) => {
  console.log('Simulator ready:', simulator);
});

// 取消监听
dispose();
```

##### 2.2.2.5 init() - 初始化编辑器

**源码位置**: [`packages/editor-core/src/editor.ts:250-269`](packages/editor-core/src/editor.ts:250)

```typescript
async init(config?: EditorConfig, components?: PluginClassSet): Promise<any> {
  this.config = config || {};
  this.components = components || {};
  const { hooks = [], lifeCycles } = this.config;

  this.emit('editor.beforeInit');
  const init = (lifeCycles && lifeCycles.init) || ((): void => { });

  try {
    await init(this);
    // 注册快捷键
    // 注册 hooks
    this.registerHooks(hooks);
    this.emit('editor.afterInit');

    return true;
  } catch (err) {
    console.error(err);
  }
}
```

**初始化流程**:
```
调用 init()
    ↓
触发 editor.beforeInit 事件
    ↓
执行 lifeCycles.init 回调
    ↓
注册 hooks
    ↓
触发 editor.afterInit 事件
    ↓
返回 Promise<true>
```

##### 2.2.2.6 destroy() - 销毁编辑器

**源码位置**: [`packages/editor-core/src/editor.ts:271-286`](packages/editor-core/src/editor.ts:271)

```typescript
destroy(): void {
  if (!this.config) {
    return;
  }
  try {
    const { lifeCycles = {} } = this.config;

    this.unregisterHooks();

    if (lifeCycles.destroy) {
      lifeCycles.destroy(this);
    }
  } catch (err) {
    console.warn(err);
  }
}
```

### 2.3 状态管理策略与数据流转逻辑

#### 2.3.1 IoC容器机制

**设计模式**: 依赖注入容器（Dependency Injection Container）

**实现方式**: 使用ES6 Map作为轻量级IoC容器

**核心代码**:
```typescript
@obx.shallow private context = new Map<IPublicTypeEditorValueKey, any>();
```

**特点**:
- 使用MobX的`@obx.shallow`装饰器，使容器本身是响应式的
- 支持任意类型的依赖存储
- 提供类型安全的依赖获取

**数据流转**:
```
插件注册依赖
    ↓
editor.set('myPlugin', pluginInstance)
    ↓
存储到 context Map
    ↓
其他模块获取依赖
    ↓
editor.get('myPlugin')
```

#### 2.3.2 等待队列机制

**设计目的**: 解决依赖异步加载问题

**实现方式**: 使用Map管理等待队列

**核心代码**:
```typescript
private waits = new Map<
  IPublicTypeEditorValueKey,
  Array<{
    once?: boolean;
    resolve: (data: any) => void;
  }>
>();
```

**notifyGot方法**:
```typescript
private notifyGot(key: IPublicTypeEditorValueKey) {
  let waits = this.waits.get(key);
  if (!waits) {
    return;
  }
  waits = waits.slice().reverse();
  let i = waits.length;
  while (i--) {
    waits[i].resolve(this.get(key));
    if (waits[i].once) {
      waits.splice(i, 1);
    }
  }
  if (waits.length > 0) {
    this.waits.set(key, waits);
  } else {
    this.waits.delete(key);
  }
}
```

**工作流程**:
```
onceGot('simulator') 被调用
    ↓
simulator 不存在
    ↓
注册 resolve 到 waits['simulator']
    ↓
set('simulator', simulatorInstance)
    ↓
notifyGot('simulator')
    ↓
调用 waits['simulator'][0].resolve(simulatorInstance)
    ↓
Promise resolve
```

## 3. 交互与通信

### 3.1 模块内部数据流向

```
┌─────────────────────────────────────────────────────────────┐
│                    Editor Core 内部数据流                │
│                                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐  │  │
│  │  │   Context   │  │   Waits     │  │  │
│  │  │   (IoC容器) │  │   (等待队列) │  │  │
│  │  └──────────────┘  └──────────────┘  │  │
│  │                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐  │  │
│  │  │  EventBus  │  │  Config     │  │  │
│  │  └──────────────┘  └──────────────┘  │  │
│  │                                        │  │
│  └──────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

### 3.2 与其他模块的具体交互方式

#### 3.2.1 与Designer模块交互

**交互方式**: 通过IoC容器获取Designer实例

**代码示例**:
```typescript
// 在Editor中存储Designer
editor.set('designer', designerInstance);

// 在其他模块中获取Designer
const designer = editor.get('designer');
```

**API引用**: 
- [`project.currentDocument`](packages/designer/src/project/project.ts:113) - 获取当前文档
- [`project.simulator`](packages/designer/src/project/project.ts:109) - 获取模拟器

#### 3.2.2 与Project模块交互

**交互方式**: 通过IoC容器获取Project实例

**代码示例**:
```typescript
// 在Editor中存储Project
editor.set('project', projectInstance);

// 在其他模块中获取Project
const project = editor.get('project');
```

**API引用**:
- [`project.openDocument()`](packages/designer/src/project/project.ts:309) - 打开文档
- [`project.createDocument()`](packages/designer/src/project/project.ts:302) - 创建文档
- [`project.exportSchema()`](packages/designer/src/project/project.ts:176) - 导出Schema

#### 3.2.3 与EventBus交互

**交互方式**: Editor自身提供EventBus实例

**代码示例**:
```typescript
// 使用Editor的EventBus
editor.eventBus.on('customEvent', (data) => {
  console.log('Custom event:', data);
});

// 触发事件
editor.eventBus.emit('customEvent', { data: 'value' });
```

#### 3.2.4 与Config模块交互

**交互方式**: 通过`engineConfig`单例

**代码示例**:
```typescript
import { engineConfig } from '@alilc/lowcode-editor-core';

// 设置配置
engineConfig.set('enableCondition', true);

// 获取配置
const enableCondition = engineConfig.get('enableCondition', false);

// 等待配置
const config = await engineConfig.onceGot('customConfig');
```

## 4. 依赖关系

### 4.1 外部库依赖

| 依赖包 | 版本 | 用途 |
|--------|------|------|
| `events` | 内置 | 事件发射器，提供EventEmitter |
| `@alilc/lowcode-types` | ^1.3.2 | 类型定义 |
| `@alilc/lowcode-utils` | ^1.3.2 | 工具函数 |
| `mobx` | ^6.3.0 | 响应式状态管理 |
| `strict-event-emitter-types` | ^2.0.0 | EventEmitter类型定义 |

### 4.2 内部模块依赖

| 模块 | 依赖方式 | 用途 |
|------|---------|------|
| `EngineConfig` | 直接导入 | 配置管理 |
| `EventBus` | 内部实现 | 事件总线 |
| `globalLocale` | 直接导入 | 国际化 |
| `assetsTransform` | 直接导入 | 物料转换 |

### 4.3 依赖关系图

```mermaid
graph TD
    Editor[Editor Core] --> EventBus[Event Bus]
    Editor --> EngineConfig[Engine Config]
    Editor --> globalLocale[Global Locale]
    Editor --> assetsTransform[Assets Transform]
    
    Editor --> Designer[Designer Module]
    Editor --> Project[Project Module]
    Editor --> Skeleton[Skeleton Module]
    
    EngineConfig --> Preference[Preference]
    
    Designer --> DocumentModel[Document Model]
    Designer --> ComponentMeta[Component Meta]
    
    DocumentModel --> Node[Node]
    DocumentModel --> Selection[Selection]
    DocumentModel --> History[History]
```

## 5. 关键技术点

### 5.1 应用的设计模式

#### 5.1.1 依赖注入模式（Dependency Injection）

**实现方式**: 使用Map作为轻量级IoC容器

**优势**:
- 简单高效，无额外依赖
- 类型安全，支持泛型
- 易于测试和维护

**代码示例**:
```typescript
@obx.shallow private context = new Map<IPublicTypeEditorValueKey, any>();

get(key: string): any {
  return this.context.get(key);
}

set(key: string, value: any): void {
  this.context.set(key, value);
}
```

#### 5.1.2 观察者模式（Observer Pattern）

**实现方式**: 使用EventEmitter实现事件发布订阅

**特点**:
- 松耦合：发布者和订阅者互不依赖
- 异步：支持异步事件处理
- 可扩展：易于添加新的事件类型

**代码示例**:
```typescript
class Editor extends EventEmitter {
  eventBus: EventBus;

  on(event: string, listener: Function): () => void {
    return this.eventBus.on(event, listener);
  }

  emit(event: string, ...args: any[]): void {
    this.eventBus.emit(event, ...args);
  }
}
```

#### 5.1.3 Promise模式（Promise Pattern）

**实现方式**: 使用Promise解决异步依赖问题

**onceGot实现**:
```typescript
onceGot(key: string): Promise<any> {
  const x = this.context.get(key);
  if (x !== undefined) {
    return Promise.resolve(x);
  }
  return new Promise((resolve) => {
    this.setWait(key, resolve, true);
  });
}
```

**优势**:
- 标准化：使用ES6 Promise
- 可组合：支持Promise.all、Promise.race等
- 错误处理：统一的错误处理机制

#### 5.1.4 Disposable模式

**实现方式**: 事件监听返回解绑函数

**代码示例**:
```typescript
onGot(key: string, fn: Function): () => void {
  const x = this.context.get(key);
  if (x !== undefined) {
    fn(x);
  }
  this.setWait(key, fn);
  return () => {
    this.delWait(key, fn);
  };
}
```

**使用方式**:
```typescript
const dispose = editor.onGot('simulator', (simulator) => {
  // 处理逻辑
});

// 需要清理时调用
dispose();
```

### 5.2 技术难点的解决方案

#### 5.2.1 异步依赖加载问题

**问题**: 模块初始化顺序不确定，某些依赖可能还未加载

**解决方案**: 实现等待队列机制

**核心逻辑**:
1. `onceGot()`注册等待回调
2. 依赖被设置时触发所有等待回调
3. 支持once和多次触发模式

**代码示例**:
```typescript
private notifyGot(key: string) {
  let waits = this.waits.get(key);
  if (!waits) {
    return;
  }
  waits = waits.slice().reverse();
  let i = waits.length;
  while (i--) {
    waits[i].resolve(this.get(key));
    if (waits[i].once) {
      waits.splice(i, 1);
    }
  }
  if (waits.length > 0) {
    this.waits.set(key, waits);
  } else {
    this.waits.delete(key);
  }
}
```

#### 5.2.2 事件监听器内存泄漏问题

**问题**: 事件监听器未正确清理导致内存泄漏

**解决方案**: Disposable模式，返回解绑函数

**实现机制**:
```typescript
on(event: string, listener: Function): () => void {
  this.eventEmitter.on(event, listener);
  return () => {
    this.eventEmitter.off(event, listener);
  };
}
```

**最佳实践**:
```typescript
class MyPlugin {
  private disposes: (() => void)[] = [];

  init(editor) {
    const dispose1 = editor.eventBus.on('event1', this.handle1);
    const dispose2 = editor.eventBus.on('event2', this.handle2);
    
    this.disposes.push(dispose1, dispose2);
  }

  destroy() {
    this.disposes.forEach(dispose => dispose());
  }
}
```

#### 5.2.3 配置管理的一致性问题

**问题**: 配置分散在多个地方，难以统一管理

**解决方案**: 统一的Config模块

**EngineConfig特性**:
1. 支持严格模式：只允许预定义的配置项
2. 支持等待机制：`onceGot`、`onGot`
3. 支持用户偏好：`getPreference()`
4. 支持批量设置：`setConfig()`

**严格模式实现**:
```typescript
const VALID_ENGINE_OPTIONS = {
  enableCondition: { type: 'boolean', description: '...' },
  designMode: { type: 'string', enum: ['design', 'live'], default: 'design' },
  // ... 更多预定义选项
};

setEngineOptions(engineOptions: IPublicTypeEngineOptions) {
  const strictMode = getStrictModeValue(engineOptions, STRICT_PLUGIN_MODE_DEFAULT) === true;
  if (strictMode) {
    const isValidKey = (key: string) => {
      const result = (VALID_ENGINE_OPTIONS as any)[key];
      return !(result === undefined || result === null);
    };
    Object.keys(engineOptions).forEach((key) => {
      if (isValidKey(key)) {
        this.set(key, (engineOptions as any)[key]);
      } else {
        logger.warn(`failed to config ${key} to engineConfig, only predefined options can be set under strict mode`);
      }
    });
  } else {
    this.setConfig(engineOptions as any);
  }
}
```

### 5.3 性能优化手段

#### 5.3.1 事件监听器数量限制

**实现**: 设置EventEmitter的最大监听器数量

**代码**:
```typescript
constructor(readonly viewName: string = 'global', readonly workspaceMode: boolean = false) {
  super();
  this.setMaxListeners(200);
  this.eventBus = new EventBus(this);
}
```

**目的**: 防止内存泄漏，限制单个事件的最大监听器数量

#### 5.3.2 MobX响应式优化

**实现**: 使用`@obx.shallow`装饰器

**代码**:
```typescript
@obx.shallow private context = new Map<IPublicTypeEditorValueKey, any>();
```

**优势**:
- `shallow`模式：只监听Map本身的引用变化，不监听Map内部值的变化
- 减少响应式追踪开销
- 提高性能

#### 5.3.3 延迟清理策略

**实现**: 使用`setTimeout`延迟清理等待队列

**代码**:
```typescript
private resetTimer = 0;

private resetSequences() {
  if (this.resetTimer) {
    clearTimeout(this.resetTimer);
  }
  this.resetTimer = window.setTimeout(this.resetSequences, 1000);
}
```

**目的**: 
- 给多次连续操作留出合并窗口
- 减少不必要的重置操作
- 提升用户体验

### 5.4 安全性考虑

#### 5.4.1 配置验证

**严格模式**:
- 只允许预定义的配置项
- 防止插件传入未经验证的配置
- 提供清晰的错误提示

**代码示例**:
```typescript
const isValidKey = (key: string) => {
  const result = (VALID_ENGINE_OPTIONS as any)[key];
  return !(result === undefined || result === null);
};

if (!isValidKey(key)) {
  logger.warn(`failed to config ${key} to engineConfig, only predefined options can be set under strict mode`);
  return;
}
```

#### 5.4.2 错误边界

**init方法的错误处理**:
```typescript
async init(config?: EditorConfig, components?: PluginClassSet): Promise<any> {
  // ...
  try {
    await init(this);
    // ...
    return true;
  } catch (err) {
    console.error(err);
  }
}
```

**特点**:
- 捕获初始化过程中的错误
- 防止错误导致整个编辑器崩溃
- 提供友好的错误日志

## 6. 总结

EditorCore模块是LowCodeEngine的核心基础设施，提供了：

1. **完善的依赖注入机制**：基于Map的轻量级IoC容器
2. **强大的事件系统**：基于EventEmitter的发布订阅模式
3. **统一的配置管理**：EngineConfig提供配置的读写和等待机制
4. **生命周期管理**：init/destroy钩子，支持插件生命周期
5. **异步依赖支持**：onceGot/onGot等待队列机制
6. **内存管理优化**：Disposable模式、事件监听器限制
7. **类型安全**：完整的TypeScript类型定义

该模块设计精简高效，为其他所有模块提供了坚实的基础设施，是整个低代码引擎的"大脑"和"中枢"。
