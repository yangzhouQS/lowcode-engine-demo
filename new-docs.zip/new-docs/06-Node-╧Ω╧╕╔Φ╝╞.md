# Node 模块详细设计

## 1. 模块概述

### 1.1 功能定位

Node 是 LowCodeEngine 的节点模型模块，代表文档树中的单个组件节点。它是构建整个文档树的基本单元，负责管理节点的属性、子节点、父节点关系、生命周期等核心功能。

### 1.2 核心职责

1. **节点标识**：管理节点的唯一ID和组件名称
2. **属性管理**：管理节点的属性（Props）
3. **子节点管理**：管理节点的子节点列表
4. **父子关系**：维护节点之间的父子关系
5. **节点类型判断**：判断节点类型（Page、Component、Slot、Leaf等）
6. **节点操作**：节点的插入、删除、移动等操作
7. **Schema导入导出**：节点Schema的导入和导出
8. **生命周期管理**：节点的创建、销毁、挂载等生命周期
9. **状态管理**：节点的锁定、隐藏、伪状态等
10. **Slot管理**：管理Slot节点的特殊逻辑

### 1.3 在整体架构中的位置

```
┌─────────────────────────────────────────────────────────────┐
│                    应用层 (Application)                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │   插件系统    │  │   面板组件    │  │   自定义扩展   │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                     Shell层 (Shell)                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Editor Core                             │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                   核心层 (Core)                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Designer                               │  │
│  │  ┌──────────────────────────────────────────────┐  │  │
│  │  │          Project                             │  │  │
│  │  └──────────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                   文档层 (Document)                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │        DocumentModel                                │  │
│  │  ┌──────────────────────────────────────────────┐  │  │
│  │  │              Node (本模块)            │  │  │
│  │  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  │  │  │
│  │  │  │   Props  │  │NodeChildren│  │  Slot    │  │  │  │
│  │  │  └──────────┘  └──────────┘  └──────────┘  │  │  │
│  │  └──────────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## 2. 核心设计与实现

### 2.1 核心类/组件结构图

```mermaid
classDiagram
    class Node {
        -id: string
        -componentName: string
        -props: IProps
        -_children: INodeChildren
        -_parent: INode
        -_slotFor: IProp
        -_slots: INode[]
        -_conditionGroup: IExclusiveGroup
        +remove()
        +insertBefore()
        +insertAfter()
        +export()
        +import()
        +contains()
        +select()
        +hover()
    }
    
    class Props {
        -node: INode
        -props: Map~string, IProp~
        +get()
        +set()
        +merge()
        +export()
        +import()
    }
    
    class Prop {
        -key: string
        -value: any
        +getValue()
        +setValue()
        +export()
        +import()
    }
    
    class NodeChildren {
        -owner: INode
        -children: INode[]
        +insert()
        +delete()
        +indexOf()
        +get()
        +export()
        +import()
    }
    
    class ExclusiveGroup {
        -name: string
        -nodes: INode[]
        +add()
        +remove()
        +setVisible()
        +isVisible()
    }
    
    Node --> Props
    Node --> NodeChildren
    Node --> ExclusiveGroup
    Props --> Prop
```

### 2.2 Node 类详解

#### 2.2.1 类定义

**源文件**: [`packages/designer/src/document/node/node.ts`](packages/designer/src/document/node/node.ts:215)

```typescript
export class Node<Schema extends IPublicTypeNodeSchema = IPublicTypeNodeSchema> implements IBaseNode {
  private emitter: IEventBus;

  /**
   * 是节点实例
   */
  readonly isNode = true;

  /**
   * 节点 id
   */
  readonly id: string;

  /**
   * 节点组件类型
   * 特殊节点：
   *  * Page 页面
   *  * Block 区块
   *  * Component 组件/元件
   *  * Fragment 碎片节点，无 props，有指令
   *  * Leaf 文字节点 | 表达式节点，无 props，无指令？
   *  * Slot 插槽节点，无 props，正常 children，有 slotArgs，有指令
   */
  readonly componentName: string;

  /**
   * 属性抽象
   */
  props: IProps;

  protected _children?: INodeChildren;

  /**
   * @deprecated
   */
  private _addons: { [key: string]: { exportData: () => any; isProp: boolean } } = {};

  @obx.ref private _parent: INode | null = null;

  /**
   * 父级节点
   */
  get parent(): INode | null {
    return this._parent;
  }

  /**
   * 当前节点子集
   */
  get children(): INodeChildren | null {
    return this._children || null;
  }

  /**
   * 当前节点深度
   */
  @computed get zLevel(): number {
    if (this._parent) {
      return this._parent.zLevel + 1;
    }
    return 0;
  }

  @computed get title(): string | IPublicTypeI18nData | ReactElement {
    let t = this.getExtraProp('title');
    if (t) {
      const v = t.getAsString();
      if (v) {
        return v;
      }
    }
    return this.componentMeta.title;
  }

  get icon() {
    return this.componentMeta.icon;
  }

  isInited = false;

  _settingEntry: ISettingTopEntry;

  get settingEntry(): ISettingTopEntry {
    if (this._settingEntry) return this._settingEntry;
    this._settingEntry = this.document.designer.createSettingEntry([this]);
    return this._settingEntry;
  }

  private autoruns?: Array<() => void>;

  private _isRGLContainer = false;

  set isRGLContainer(status: boolean) {
    this._isRGLContainer = status;
  }

  get isRGLContainer(): boolean {
    return !!this._isRGLContainer;
  }

  set isRGLContainerNode(status: boolean) {
    this._isRGLContainer = status;
  }

  get isRGLContainerNode(): boolean {
    return !!this._isRGLContainer;
  }

  get isEmptyNode() {
    return this.isEmpty();
  }

  private _slotFor?: IProp | null | undefined = null;

  @obx.shallow _slots: INode[] = [];

  get slots(): INode[] {
    return this._slots;
  }

  /* istanbul ignore next */
  @obx.ref private _conditionGroup: IExclusiveGroup | null = null;

  /* istanbul ignore next */
  get conditionGroup(): IExclusiveGroup | null {
    return this._conditionGroup;
  }

  private purged = false;

  /**
   * 是否已销毁
   */
  get isPurged() {
    return this.purged;
  }

  private purging: boolean = false;

  /**
   * 是否正在销毁
   */
  get isPurging() {
    return this.purging;
  }

  @obx.shallow status: NodeStatus = {
    inPlaceEditing: false,
    locking: false,
    pseudo: false,
  };

  constructor(readonly document: IDocumentModel, nodeSchema: Schema) {
    makeObservable(this);
    const { componentName, id, children, props, ...extras } = nodeSchema;
    this.id = document.nextId(id);
    this.componentName = componentName;
    if (this.componentName === 'Leaf') {
      this.props = new Props(this, {
        children: isDOMText(children) || isJSExpression(children) ? children : '',
      });
    } else {
      this.props = new Props(this, props, extras);
      this._children = new NodeChildren(this as INode, this.initialChildren(children));
      this._children.internalInitParent();
      this.props.merge(
        this.upgradeProps(this.initProps(props || {})),
        this.upgradeProps(extras),
      );
      this.setupAutoruns();
    }

    this.initBuiltinProps();

    this.isInited = true;
    this.emitter = createModuleEventBus('Node');
    const { editor } = this.document.designer;
    this.onVisibleChange((visible: boolean) => {
      editor?.eventBus.emit(EDITOR_EVENT.NODE_VISIBLE_CHANGE, this, visible);
    });
    this.onChildrenChange((info?: { type: string; node: INode }) => {
      editor?.eventBus.emit(EDITOR_EVENT.NODE_CHILDREN_CHANGE, {
        type: info?.type,
        node: this,
      });
    });
  }
}
```

#### 2.2.2 关键方法详解

##### 2.2.2.1 remove() - 移除节点

**源码位置**: [`packages/designer/src/document/node/node.ts:615-634`](packages/designer/src/document/node/node.ts:615)

```typescript
remove(
  useMutator = true,
  purge = true,
  options: NodeRemoveOptions = { suppressRemoveEvent: false },
) {
  if (this.parent) {
    if (!options.suppressRemoveEvent) {
      this.document.designer.editor?.eventBus.emit('node.remove.topLevel', {
        node: this,
        index: this.parent?.children?.indexOf(this),
      });
    }
    if (this.isSlot()) {
      this.parent.removeSlot(this);
      this.parent.children?.internalDelete(this, purge, useMutator, { suppressRemoveEvent: true });
    } else {
      this.parent.children?.internalDelete(this, purge, useMutator, { suppressRemoveEvent: true });
    }
  }
}
```

**实现逻辑**:
1. 检查是否有父节点
2. 如果不抑制事件，发布节点移除事件
3. 如果是Slot节点，从父节点的slots中移除
4. 从父节点的children中删除节点
5. 支持是否触发联动逻辑（useMutator）
6. 支持是否销毁节点（purge）

**使用示例**:
```typescript
// 移除节点（默认触发联动和销毁）
node.remove();

// 移除节点但不触发联动
node.remove(false);

// 移除节点但不销毁
node.remove(true, false);

// 移除节点且不发布事件
node.remove(true, true, { suppressRemoveEvent: true });
```

##### 2.2.2.2 insertBefore() - 在指定节点前插入

**源码位置**: [`packages/designer/src/document/node/node.ts:1129-1132`](packages/designer/src/document/node/node.ts:1129)

```typescript
insertBefore(node: INode, ref?: INode, useMutator = true) {
  const nodeInstance = ensureNode(node, this.document);
  this.children?.internalInsert(nodeInstance, ref ? ref.index : null, useMutator);
}
```

**实现逻辑**:
1. 确保node是Node实例
2. 调用children的internalInsert方法
3. 插入位置为ref的索引
4. 支持是否触发联动逻辑

**使用示例**:
```typescript
// 在ref节点前插入
parent.insertBefore(newNode, refNode);

// 在父节点末尾插入
parent.insertBefore(newNode);
```

##### 2.2.2.3 insertAfter() - 在指定节点后插入

**源码位置**: [`packages/designer/src/document/node/node.ts:1134-1137`](packages/designer/src/document/node/node.ts:1134)

```typescript
insertAfter(node: any, ref?: INode, useMutator = true) {
  const nodeInstance = ensureNode(node, this.document);
  this.children?.internalInsert(nodeInstance, ref ? (ref.index || 0) + 1 : null, useMutator);
}
```

**实现逻辑**:
1. 确保node是Node实例
2. 调用children的internalInsert方法
3. 插入位置为ref的索引+1
4. 支持是否触发联动逻辑

**使用示例**:
```typescript
// 在ref节点后插入
parent.insertAfter(newNode, refNode);

// 在父节点末尾插入
parent.insertAfter(newNode);
```

##### 2.2.2.4 export() - 导出Schema

**源码位置**: [`packages/designer/src/document/node/node.ts:947-994`](packages/designer/src/document/node/node.ts:947)

```typescript
export<T = IPublicTypeNodeSchema>(stage: IPublicEnumTransformStage = IPublicEnumTransformStage.Save, options: any = {}): T {
  stage = compatStage(stage);
  const baseSchema: any = {
    componentName: this.componentName,
  };

  if (stage !== IPublicEnumTransformStage.Clone) {
    baseSchema.id = this.id;
  }
  if (stage === IPublicEnumTransformStage.Render) {
    baseSchema.docId = this.document.id;
  }

  if (this.isLeaf()) {
    if (!options.bypassChildren) {
      baseSchema.children = this.props.get('children')?.export(stage);
    }
    return baseSchema;
  }

  const { props = {}, extras } = this.props.export(stage) || {};
  const _extras_: { [key: string]: any } = {
    ...extras,
  };
  /* istanbul ignore next */
  Object.keys(this._addons).forEach((key) => {
    const addon = this._addons[key];
    if (addon) {
      if (addon.isProp) {
        (props as any)[getConvertedExtraKey(key)] = addon.exportData();
      } else {
        _extras_[key] = addon.exportData();
      }
    }
  });

  const schema: any = {
    ...baseSchema,
    props: this.document.designer.transformProps(props, this, stage),
    ...this.document.designer.transformProps(_extras_, this, stage),
  };

  if (this.isParental() && this.children && this.children.size > 0 && !options.bypassChildren) {
    schema.children = this.children.export(stage);
  }

  return schema;
}
```

**实现逻辑**:
1. 兼容处理转换阶段
2. 创建基础Schema（包含componentName）
3. 根据阶段添加ID和docId
4. 如果是Leaf节点，导出children属性
5. 导出props和extras
6. 处理addons（已废弃）
7. 通过designer转换props
8. 如果是父节点且存在子节点，导出children
9. 返回完整Schema

**使用示例**:
```typescript
// 导出保存阶段的Schema
const schema = node.export(IPublicEnumTransformStage.Save);

// 导出渲染阶段的Schema
const renderSchema = node.export(IPublicEnumTransformStage.Render);

// 导出克隆阶段的Schema（不包含ID）
const cloneSchema = node.export(IPublicEnumTransformStage.Clone);

// 导出时不包含子节点
const schemaWithoutChildren = node.export(IPublicEnumTransformStage.Save, { bypassChildren: true });
```

##### 2.2.2.5 import() - 导入Schema

**源码位置**: [`packages/designer/src/document/node/node.ts:919-938`](packages/designer/src/document/node/node.ts:919)

```typescript
import(data: Schema, checkId = false) {
  const { componentName, id, children, props, ...extras } = data;
  if (this.isSlot()) {
    foreachReverse(
      this.children!,
      (subNode: INode) => {
        subNode.remove(true, true);
      },
      (iterable, idx) => (iterable as INodeChildren).get(idx),
    );
  }
  if (this.isParental()) {
    this.props.import(props, extras);
    this._children?.import(children, checkId);
  } else {
    this.props
      .get('children', true)!
      .setValue(isDOMText(children) || isJSExpression(children) ? children : '');
  }
}
```

**实现逻辑**:
1. 解构Schema数据
2. 如果是Slot节点，倒序删除所有子节点
3. 如果是父节点，导入props和children
4. 如果是Leaf节点，设置children属性

**使用示例**:
```typescript
// 导入Schema
node.import({
  componentName: 'Button',
  props: {
    type: 'primary',
    children: 'Click me'
  }
});

// 导入时不检查ID
node.import(schema, false);
```

##### 2.2.2.6 contains() - 检查是否包含节点

**源码位置**: [`packages/designer/src/document/node/node.ts:999-1001`](packages/designer/src/document/node/node.ts:999)

```typescript
contains(node: INode): boolean {
  return contains(this, node);
}
```

**实现逻辑**:
- 调用contains工具函数
- 检查节点是否在当前节点的子树中

**使用示例**:
```typescript
// 检查节点是否包含另一个节点
if (parentNode.contains(childNode)) {
  console.log('childNode 是 parentNode 的子节点');
}
```

##### 2.2.2.7 select() - 选择节点

**源码位置**: [`packages/designer/src/document/node/node.ts:659-661`](packages/designer/src/document/node/node.ts:659)

```typescript
select() {
  this.document.selection.select(this.id);
}
```

**实现逻辑**:
- 调用document的selection.select方法
- 传入当前节点的ID

**使用示例**:
```typescript
// 选择节点
node.select();
```

##### 2.2.2.8 hover() - 悬停高亮

**源码位置**: [`packages/designer/src/document/node/node.ts:666-672`](packages/designer/src/document/node/node.ts:666)

```typescript
hover(flag = true) {
  if (flag) {
    this.document.designer.detecting.capture(this);
  } else {
    this.document.designer.detecting.release(this);
  }
}
```

**实现逻辑**:
- 如果flag为true，调用detecting.capture捕获节点
- 如果flag为false，调用detecting.release释放节点

**使用示例**:
```typescript
// 悬停高亮
node.hover(true);

// 取消悬停高亮
node.hover(false);
```

##### 2.2.2.9 getProp() - 获取属性

**源码位置**: [`packages/designer/src/document/node/node.ts:813-815`](packages/designer/src/document/node/node.ts:813)

```typescript
getProp(path: string, createIfNone = true): IProp | null {
  return this.props.query(path, createIfNone) || null;
}
```

**实现逻辑**:
- 调用props.query方法
- 支持路径查询
- 支持不存在时创建

**使用示例**:
```typescript
// 获取属性
const prop = node.getProp('type');

// 获取嵌套属性
const nestedProp = node.getProp('style.color');

// 获取属性，不存在时不创建
const prop = node.getProp('type', false);
```

##### 2.2.2.10 getExtraProp() - 获取额外属性

**源码位置**: [`packages/designer/src/document/node/node.ts:817-819`](packages/designer/src/document/node/node.ts:817)

```typescript
getExtraProp(key: string, createIfNone = true): IProp | null {
  return this.props.get(getConvertedExtraKey(key), createIfNone) || null;
}
```

**实现逻辑**:
- 转换key为内部格式
- 调用props.get方法
- 支持不存在时创建

**使用示例**:
```typescript
// 获取标题属性
const titleProp = node.getExtraProp('title');

// 获取锁定状态
const lockedProp = node.getExtraProp('isLocked');

// 获取条件属性
const conditionProp = node.getExtraProp('condition');
```

##### 2.2.2.11 setExtraProp() - 设置额外属性

**源码位置**: [`packages/designer/src/document/node/node.ts:821-823`](packages/designer/src/document/node/node.ts:821)

```typescript
setExtraProp(key: string, value: IPublicTypeCompositeValue) {
  this.getProp(getConvertedExtraKey(key), true)?.setValue(value);
}
```

**实现逻辑**:
- 转换key为内部格式
- 获取或创建属性
- 设置属性值

**使用示例**:
```typescript
// 设置标题
node.setExtraProp('title', 'My Button');

// 设置锁定状态
node.setExtraProp('isLocked', true);

// 设置条件
node.setExtraProp('condition', 'this.state.visible');
```

##### 2.2.2.12 setVisible() - 设置可见性

**源码位置**: [`packages/designer/src/document/node/node.ts:796-799`](packages/designer/src/document/node/node.ts:796)

```typescript
setVisible(flag: boolean): void {
  this.getExtraProp('hidden')?.setValue(!flag);
  this.emitter.emit('visibleChange', flag);
}
```

**实现逻辑**:
- 设置hidden属性为!flag
- 发布visibleChange事件

**使用示例**:
```typescript
// 显示节点
node.setVisible(true);

// 隐藏节点
node.setVisible(false);

// 监听可见性变化
node.onVisibleChange((visible) => {
  console.log('Node visibility changed:', visible);
});
```

##### 2.2.2.13 getVisible() - 获取可见性

**源码位置**: [`packages/designer/src/document/node/node.ts:801-803`](packages/designer/src/document/node/node.ts:801)

```typescript
getVisible(): boolean {
  return !this.getExtraProp('hidden')?.getValue();
}
```

**实现逻辑**:
- 获取hidden属性
- 返回!hidden

**使用示例**:
```typescript
// 检查节点是否可见
if (node.getVisible()) {
  console.log('Node is visible');
}
```

### 2.3 节点类型判断

#### 2.3.1 isRoot() - 是否为根节点

**源码位置**: [`packages/designer/src/document/node/node.ts:478-480`](packages/designer/src/document/node/node.ts:478)

```typescript
isRoot(): boolean {
  return this.isRootNode;
}

get isRootNode(): boolean {
  return this.document.rootNode === (this as any);
}
```

**实现逻辑**:
- 检查节点是否为文档的根节点

#### 2.3.2 isPage() - 是否为页面节点

**源码位置**: [`packages/designer/src/document/node/node.ts:486-492`](packages/designer/src/document/node/node.ts:486)

```typescript
isPage(): boolean {
  return this.isPageNode;
}

get isPageNode(): boolean {
  return this.isRootNode && this.componentName === 'Page';
}
```

**实现逻辑**:
- 检查是否为根节点且组件名称为'Page'

#### 2.3.3 isComponent() - 是否为组件节点

**源码位置**: [`packages/designer/src/document/node/node.ts:494-500`](packages/designer/src/document/node/node.ts:494)

```typescript
isComponent(): boolean {
  return this.isComponentNode;
}

get isComponentNode(): boolean {
  return this.isRootNode && this.componentName === 'Component';
}
```

**实现逻辑**:
- 检查是否为根节点且组件名称为'Component'

#### 2.3.4 isSlot() - 是否为Slot节点

**源码位置**: [`packages/designer/src/document/node/node.ts:502-508`](packages/designer/src/document/node/node.ts:502)

```typescript
isSlot(): boolean {
  return this.isSlotNode;
}

get isSlotNode(): boolean {
  return this._slotFor != null && this.componentName === 'Slot';
}
```

**实现逻辑**:
- 检查是否设置了slotFor且组件名称为'Slot'

#### 2.3.5 isParental() - 是否为父节点

**源码位置**: [`packages/designer/src/document/node/node.ts:513-519`](packages/designer/src/document/node/node.ts:513)

```typescript
isParental(): boolean {
  return this.isParentalNode;
}

get isParentalNode(): boolean {
  return !this.isLeafNode;
}
```

**实现逻辑**:
- 检查是否不是Leaf节点

#### 2.3.6 isLeaf() - 是否为叶子节点

**源码位置**: [`packages/designer/src/document/node/node.ts:524-529`](packages/designer/src/document/node/node.ts:524)

```typescript
isLeaf(): boolean {
  return this.isLeafNode;
}

get isLeafNode(): boolean {
  return this.componentName === 'Leaf';
}
```

**实现逻辑**:
- 检查组件名称是否为'Leaf'

### 2.4 节点深度计算

#### 2.4.1 zLevel属性

**源码位置**: [`packages/designer/src/document/node/node.ts:271-276`](packages/designer/src/document/node/node.ts:271)

```typescript
@computed get zLevel(): number {
  if (this._parent) {
    return this._parent.zLevel + 1;
  }
  return 0;
}
```

**实现逻辑**:
- 如果有父节点，返回父节点的zLevel + 1
- 否则返回0

**特点**:
- 使用MobX的@computed装饰器
- 自动计算节点深度
- 根节点深度为0

### 2.5 节点生命周期

#### 2.5.1 构造阶段

**流程**:
```
new Node(document, schema)
    ↓
解析schema（componentName, id, props, children, extras）
    ↓
生成唯一ID
    ↓
如果是Leaf节点
    ↓
创建Props（只包含children）
    ↓
否则
    ↓
创建Props（包含props和extras）
    ↓
创建NodeChildren
    ↓
初始化父子关系
    ↓
合并props
    ↓
设置autoruns
    ↓
初始化内置props
    ↓
标记为已初始化
    ↓
创建事件总线
    ↓
监听可见性变化
    ↓
监听子节点变化
```

#### 2.5.2 销毁阶段

**源码位置**: [`packages/designer/src/document/node/node.ts:1081-1090`](packages/designer/src/document/node/node.ts:1081)

```typescript
purge() {
  if (this.purged) {
    return;
  }
  this.purged = true;
  this.autoruns?.forEach((dispose) => dispose());
  this.props.purge();
  this.settingEntry?.purge();
  // this.document.destroyNode(this);
}
```

**流程**:
```
purge()
    ↓
检查是否已销毁
    ↓
标记为已销毁
    ↓
释放所有autoruns
    ↓
销毁props
    ↓
销毁settingEntry
    ↓
（注释掉的）通知文档销毁节点
```

### 2.6 节点关系管理

#### 2.6.1 父子关系

**internalSetParent方法**:
```typescript
internalSetParent(parent: INode | null, useMutator = false) {
  if (this._parent === parent) {
    return;
  }

  // 解除老的父子关系
  if (this._parent) {
    if (this.isSlot()) {
      this._parent.unlinkSlot(this);
    } else {
      this._parent.children?.unlinkChild(this);
    }
  }
  if (useMutator) {
    this._parent?.didDropOut(this);
  }
  if (parent) {
    // 建立新的父子关系
    this._parent = parent;
    this.document.removeWillPurge(this);
    if (!this.conditionGroup) {
      // 初始化conditionGroup
      const grp = this.getExtraProp('conditionGroup', false)?.getAsString();
      if (grp) {
        this.setConditionGroup(grp);
      }
    }

    if (useMutator) {
      parent.didDropIn(this);
    }
  }
}
```

**特点**:
- 处理Slot节点的特殊逻辑
- 支持触发联动逻辑
- 自动初始化conditionGroup

#### 2.6.2 兄弟节点

**nextSibling属性**:
```typescript
get nextSibling(): INode | null | undefined {
  if (!this.parent) {
    return null;
  }
  const { index } = this;
  if (typeof index !== 'number') {
    return null;
  }
  if (index < 0) {
    return null;
  }
  return this.parent.children?.get(index + 1);
}
```

**prevSibling属性**:
```typescript
get prevSibling(): INode | null | undefined {
  if (!this.parent) {
    return null;
  }
  const { index } = this;
  if (typeof index !== 'number') {
    return null;
  }
  if (index < 1) {
    return null;
  }
  return this.parent.children?.get(index - 1);
}
```

**特点**:
- 基于index计算兄弟节点
- 边界检查
- 返回null表示不存在

### 2.7 Slot节点管理

#### 2.7.1 Slot节点特点

**定义**:
- 组件名称为'Slot'
- 设置了slotFor属性
- 不在正常的children树中
- 存储在父节点的slots数组中

#### 2.7.2 Slot节点操作

**addSlot方法**:
```typescript
addSlot(slotNode: INode) {
  const slotName = slotNode?.getExtraProp('name')?.getAsString();
  // 一个组件下的所有 slot，相同 slotName 的 slot 应该是唯一的
  if (includeSlot(this, slotName)) {
    removeSlot(this, slotName);
  }
  slotNode.internalSetParent(this as INode, true);
  this._slots.push(slotNode);
}
```

**removeSlot方法**:
```typescript
removeSlot(slotNode: INode): boolean {
  const i = this._slots.indexOf(slotNode);
  if (i < 0) {
    return false;
  }
  this._slots.splice(i, 1);
  return false;
}
```

**unlinkSlot方法**:
```typescript
unlinkSlot(slotNode: INode) {
  const i = this._slots.indexOf(slotNode);
  if (i < 0) {
    return false;
  }
  this._slots.splice(i, 1);
}
```

**特点**:
- 相同slotName的Slot节点唯一
- 自动替换同名Slot
- 从slots数组中管理

### 2.8 ConditionGroup管理

#### 2.8.1 ConditionGroup概念

**定义**:
- 一组互斥的节点
- 同一时间只有一个节点可见
- 用于实现条件渲染

#### 2.8.2 ConditionGroup操作

**setConditionGroup方法**:
```typescript
setConditionGroup(grp: IPublicModelExclusiveGroup | string | null) {
  let _grp: IExclusiveGroup | null = null;
  if (!grp) {
    this.getExtraProp('conditionGroup', false)?.remove();
    if (this._conditionGroup) {
      this._conditionGroup.remove(this);
      this._conditionGroup = null;
    }
    return;
  }
  if (!isExclusiveGroup(grp)) {
    if (this.prevSibling?.conditionGroup?.name === grp) {
      _grp = this.prevSibling.conditionGroup;
    } else if (this.nextSibling?.conditionGroup?.name === grp) {
      _grp = this.nextSibling.conditionGroup;
    } else if (typeof grp === 'string') {
      _grp = new ExclusiveGroup(grp);
    }
  }
  if (_grp && this._conditionGroup !== _grp) {
    this.getExtraProp('conditionGroup', true)?.setValue(_grp.name);
    if (this._conditionGroup) {
      this._conditionGroup.remove(this);
    }
    this._conditionGroup = _grp;
    _grp?.add(this);
  }
}
```

**特点**:
- 支持字符串和ExclusiveGroup对象
- 自动复用兄弟节点的ConditionGroup
- 从旧组移除，添加到新组

### 2.9 节点状态管理

#### 2.9.1 状态属性

**定义**:
```typescript
export interface NodeStatus {
  locking: boolean;
  pseudo: boolean;
  inPlaceEditing: boolean;
}

@obx.shallow status: NodeStatus = {
  inPlaceEditing: false,
  locking: false,
  pseudo: false,
};
```

#### 2.9.2 状态操作

**lock方法**:
```typescript
lock(flag = true) {
  this.setExtraProp('isLocked', flag);
}
```

**isLocked属性**:
```typescript
get isLocked(): boolean {
  return !!this.getExtraProp('isLocked')?.getValue();
}
```

**特点**:
- 使用ExtraProp存储状态
- 支持锁定/解锁
- MobX响应式

## 3. 交互与通信

### 3.1 模块内部数据流向

```
┌─────────────────────────────────────────────────────────────┐
│                    Node 内部数据流                         │
│                                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │                                        │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  │  │
│  │  │   Props  │  │_children │  │ _parent  │  │  │
│  │  └──────────┘  └──────────┘  └──────────┘  │  │
│  │                                        │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  │  │
│  │  │ _slots   │  │_condition│  │  status  │  │  │
│  │  │          │  │  Group   │  │          │  │  │
│  │  └──────────┘  └──────────┘  └──────────┘  │  │
│  │                                        │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  │  │
│  │  │ emitter  │  │autoruns  │  │_slotFor │  │  │
│  │  └──────────┘  └──────────┘  └──────────┘  │  │
│  │                                        │  │
│  └──────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

### 3.2 与其他模块的具体交互方式

#### 3.2.1 与DocumentModel交互

**交互方式**: DocumentModel创建和管理Node

**代码示例**:
```typescript
// DocumentModel中创建Node
const node = new Node(this, schema);
this._nodesMap.set(node.id, node);
this.nodes.add(node);

// DocumentModel中移除Node
this.nodes.delete(node);
this._nodesMap.delete(node.id);
```

**API引用**:
- [`document.createNode()`](packages/designer/src/document/document-model.ts:427) - 创建节点
- [`document.getNode()`](packages/designer/src/document/document-model.ts:397) - 获取节点
- [`document.removeNode()`](packages/designer/src/document/document-model.ts:492) - 移除节点

#### 3.2.2 与Props交互

**交互方式**: Node包含Props实例

**代码示例**:
```typescript
// Node中创建Props
this.props = new Props(this, props, extras);

// 获取属性
const prop = node.getProp('type');

// 设置属性
node.setExtraProp('title', 'My Button');
```

**API引用**:
- [`node.props`](packages/designer/src/document/node/node.ts:243) - Props实例
- [`node.getProp()`](packages/designer/src/document/node/node.ts:813) - 获取属性
- [`node.setExtraProp()`](packages/designer/src/document/node/node.ts:821) - 设置属性

#### 3.2.3 与NodeChildren交互

**交互方式**: Node包含NodeChildren实例

**代码示例**:
```typescript
// Node中创建NodeChildren
this._children = new NodeChildren(this as INode, this.initialChildren(children));

// 获取子节点
const children = node.children;

// 插入子节点
node.insertBefore(newNode, refNode);
```

**API引用**:
- [`node.children`](packages/designer/src/document/node/node.ts:264) - NodeChildren实例
- [`node.insertBefore()`](packages/designer/src/document/node/node.ts:1129) - 在指定节点前插入
- [`node.insertAfter()`](packages/designer/src/document/node/node.ts:1134) - 在指定节点后插入

#### 3.2.4 与ComponentMeta交互

**交互方式**: 通过document获取ComponentMeta

**代码示例**:
```typescript
// 获取组件元数据
const meta = node.componentMeta;

// 检查嵌套规则
const canNest = meta.checkNestingUp(node, parentNode);

// 获取组件标题
const title = meta.title;
```

**API引用**:
- [`node.componentMeta`](packages/designer/src/document/node/node.ts:677) - 组件元数据
- [`componentMeta.checkNestingUp()`](packages/designer/src/component-meta/index.ts) - 检查父级嵌套规则
- [`componentMeta.checkNestingDown()`](packages/designer/src/component-meta/index.ts) - 检查子级嵌套规则

#### 3.2.5 与Selection交互

**交互方式**: 通过document.selection

**代码示例**:
```typescript
// 选择节点
node.select();

// 检查是否被选中
if (document.selection.has(node.id)) {
  console.log('Node is selected');
}
```

**API引用**:
- [`node.select()`](packages/designer/src/document/node/node.ts:659) - 选择节点
- [`document.selection.has()`](packages/designer/src/document/selection.ts) - 检查是否被选中

## 4. 依赖关系

### 4.1 外部库依赖

| 依赖包 | 版本 | 用途 |
|--------|------|------|
| `react` | ^16.8.0 | React类型定义 |
| `@alilc/lowcode-editor-core` | ^1.1.0 | 编辑器核心（EventBus、Config等） |
| `@alilc/lowcode-types` | ^1.3.2 | 类型定义 |
| `@alilc/lowcode-utils` | ^1.3.2 | 工具函数 |
| `mobx` | ^6.3.0 | 响应式状态管理 |

### 4.2 内部模块依赖

| 模块 | 依赖方式 | 用途 |
|------|---------|------|
| `Props` | 直接导入 | 属性管理 |
| `NodeChildren` | 直接导入 | 子节点管理 |
| `ExclusiveGroup` | 直接导入 | 条件组管理 |
| `DocumentModel` | 构造函数参数 | 文档实例 |
| `ComponentMeta` | 通过document | 组件元数据 |
| `Selection` | 通过document | 选择器 |

### 4.3 依赖关系图

```mermaid
graph TD
    Node[Node] --> Props[Props]
    Node --> NodeChildren[NodeChildren]
    Node --> ExclusiveGroup[ExclusiveGroup]
    Node --> DocumentModel[DocumentModel]
    
    DocumentModel --> ComponentMeta[ComponentMeta]
    DocumentModel --> Selection[Selection]
    
    Props --> Prop[Prop]
    NodeChildren --> Node[Node]
    
    ComponentMeta --> Configure[Configure]
    Selection --> EditorCore[Editor Core]
```

## 5. 关键技术点

### 5.1 应用的设计模式

#### 5.1.1 组合模式（Composite Pattern）

**实现方式**: Node树形结构

**代码示例**:
```typescript
class Node {
  private _children?: INodeChildren;
  
  get children(): INodeChildren | null {
    return this._children || null;
  }
  
  contains(node: INode): boolean {
    return contains(this, node);
  }
}

function contains(node1: INode, node2: INode): boolean {
  if (node1 === node2) {
    return true;
  }
  if (!node1.isParentalNode || !node2.parent) {
    return false;
  }
  const p = getZLevelTop(node2, node1.zLevel);
  if (!p) {
    return false;
  }
  return node1 === p;
}
```

**优势**:
- 统一处理单个节点和节点树
- 便于遍历和操作
- 支持递归操作

#### 5.1.2 观察者模式（Observer Pattern）

**实现方式**: EventBus发布节点事件

**代码示例**:
```typescript
export class Node<Schema extends IPublicTypeNodeSchema = IPublicTypeNodeSchema> implements IBaseNode {
  private emitter: IEventBus;
  
  constructor(readonly document: IDocumentModel, nodeSchema: Schema) {
    // ... 初始化逻辑
    
    this.emitter = createModuleEventBus('Node');
    
    const { editor } = this.document.designer;
    this.onVisibleChange((visible: boolean) => {
      editor?.eventBus.emit(EDITOR_EVENT.NODE_VISIBLE_CHANGE, this, visible);
    });
    this.onChildrenChange((info?: { type: string; node: INode }) => {
      editor?.eventBus.emit(EDITOR_EVENT.NODE_CHILDREN_CHANGE, {
        type: info?.type,
        node: this,
      });
    });
  }
  
  onVisibleChange(func: (flag: boolean) => any): () => void {
    const wrappedFunc = wrapWithEventSwitch(func);
    this.emitter.on('visibleChange', wrappedFunc);
    return () => {
      this.emitter.removeListener('visibleChange', wrappedFunc);
    };
  }
  
  onChildrenChange(fn: (param?: { type: string; node: INode }) => void): IPublicTypeDisposable | undefined {
    const wrappedFunc = wrapWithEventSwitch(fn);
    return this.children?.onChange(wrappedFunc);
  }
  
  onPropChange(func: (info: IPublicTypePropChangeOptions) => void): IPublicTypeDisposable {
    const wrappedFunc = wrapWithEventSwitch(func);
    this.emitter.on('propChange', wrappedFunc);
    return () => {
      this.emitter.removeListener('propChange', wrappedFunc);
    };
  }
}
```

**优势**:
- 松耦合
- 易于扩展
- 支持多个订阅者

#### 5.1.3 模板方法模式（Template Method Pattern）

**实现方式**: export/import方法定义模板，子类可以覆盖

**代码示例**:
```typescript
export<T = IPublicTypeNodeSchema>(stage: IPublicEnumTransformStage = IPublicEnumTransformStage.Save, options: any = {}): T {
  stage = compatStage(stage);
  const baseSchema: any = {
    componentName: this.componentName,
  };

  if (stage !== IPublicEnumTransformStage.Clone) {
    baseSchema.id = this.id;
  }
  if (stage === IPublicEnumTransformStage.Render) {
    baseSchema.docId = this.document.id;
  }

  if (this.isLeaf()) {
    if (!options.bypassChildren) {
      baseSchema.children = this.props.get('children')?.export(stage);
    }
    return baseSchema;
  }

  const { props = {}, extras } = this.props.export(stage) || {};
  // ... 更多处理

  return schema;
}
```

**优势**:
- 定义算法骨架
- 子类可以覆盖特定步骤
- 代码复用

### 5.2 技术难点的解决方案

#### 5.2.1 Slot节点的特殊处理

**问题**: Slot节点不在正常的children树中，如何管理？

**解决方案**: 使用slots数组单独管理Slot节点

**核心代码**:
```typescript
@obx.shallow _slots: INode[] = [];

addSlot(slotNode: INode) {
  const slotName = slotNode?.getExtraProp('name')?.getAsString();
  // 一个组件下的所有 slot，相同 slotName 的 slot 应该是唯一的
  if (includeSlot(this, slotName)) {
    removeSlot(this, slotName);
  }
  slotNode.internalSetParent(this as INode, true);
  this._slots.push(slotNode);
}

removeSlot(slotNode: INode): boolean {
  const i = this._slots.indexOf(slotNode);
  if (i < 0) {
    return false;
  }
  this._slots.splice(i, 1);
  return false;
}

isSlot(): boolean {
  return this._slotFor != null && this.componentName === 'Slot';
}
```

**特点**:
- Slot节点存储在slots数组中
- 相同slotName的Slot节点唯一
- 自动替换同名Slot

#### 5.2.2 ConditionGroup的互斥逻辑

**问题**: 如何实现一组节点的互斥可见性？

**解决方案**: 使用ExclusiveGroup管理互斥节点

**核心代码**:
```typescript
setConditionGroup(grp: IPublicModelExclusiveGroup | string | null) {
  let _grp: IExclusiveGroup | null = null;
  if (!grp) {
    this.getExtraProp('conditionGroup', false)?.remove();
    if (this._conditionGroup) {
      this._conditionGroup.remove(this);
      this._conditionGroup = null;
    }
    return;
  }
  if (!isExclusiveGroup(grp)) {
    if (this.prevSibling?.conditionGroup?.name === grp) {
      _grp = this.prevSibling.conditionGroup;
    } else if (this.nextSibling?.conditionGroup?.name === grp) {
      _grp = this.nextSibling.conditionGroup;
    } else if (typeof grp === 'string') {
      _grp = new ExclusiveGroup(grp);
    }
  }
  if (_grp && this._conditionGroup !== _grp) {
    this.getExtraProp('conditionGroup', true)?.setValue(_grp.name);
    if (this._conditionGroup) {
      this._conditionGroup.remove(this);
    }
    this._conditionGroup = _grp;
    _grp?.add(this);
  }
}
```

**特点**:
- 自动复用兄弟节点的ConditionGroup
- 从旧组移除，添加到新组
- 支持字符串和ExclusiveGroup对象

#### 5.2.3 节点ID的唯一性保证

**问题**: 如何确保节点ID在文档中唯一？

**解决方案**: 由DocumentModel统一生成ID

**核心代码**:
```typescript
constructor(readonly document: IDocumentModel, nodeSchema: Schema) {
  makeObservable(this);
  const { componentName, id, children, props, ...extras } = nodeSchema;
  this.id = document.nextId(id);
  // ... 其他初始化
}
```

**特点**:
- 由DocumentModel统一生成ID
- 自动处理ID冲突
- 确保ID唯一性

#### 5.2.4 节点深度的自动计算

**问题**: 如何高效计算节点的深度？

**解决方案**: 使用MobX的@computed装饰器

**核心代码**:
```typescript
@computed get zLevel(): number {
  if (this._parent) {
    return this._parent.zLevel + 1;
  }
  return 0;
}
```

**特点**:
- 自动计算节点深度
- 基于父节点的zLevel
- MobX响应式

### 5.3 性能优化手段

#### 5.3.1 MobX响应式优化

**实现**: 使用`@obx.shallow`和`@obx.ref`装饰器

**代码**:
```typescript
@obx.ref private _parent: INode | null = null;
@obx.shallow _slots: INode[] = [];
@obx.shallow status: NodeStatus = {
  inPlaceEditing: false,
  locking: false,
  pseudo: false,
};
```

**优势**:
- `ref`模式：只监听对象的引用变化
- `shallow`模式：只监听数组本身的引用变化
- 减少响应式追踪开销
- 提升性能

#### 5.3.2 节点查找优化

**实现**: 通过DocumentModel的nodesMap查找

**代码**:
```typescript
getNode(id: string): INode | null {
  return this.document.getNode(id);
}
```

**优势**:
- O(1)时间复杂度查找
- 快速定位节点
- 减少遍历开销

#### 5.3.3 事件监听器的自动清理

**实现**: 返回解绑函数

**代码**:
```typescript
onVisibleChange(func: (flag: boolean) => any): () => void {
  const wrappedFunc = wrapWithEventSwitch(func);
  this.emitter.on('visibleChange', wrappedFunc);
  return () => {
    this.emitter.removeListener('visibleChange', wrappedFunc);
  };
}
```

**优势**:
- 自动清理监听器
- 防止内存泄漏
- Disposable模式

### 5.4 安全性考虑

#### 5.4.1 节点操作的权限控制

**实现**: 通过isLocked属性控制

**代码**:
```typescript
lock(flag = true) {
  this.setExtraProp('isLocked', flag);
}

get isLocked(): boolean {
  return !!this.getExtraProp('isLocked')?.getValue();
}

canSelect(): boolean {
  const onSelectHook = this.componentMeta?.advanced?.callbacks?.onSelectHook;
  const canSelect = typeof onSelectHook === 'function' ? onSelectHook(this.internalToShellNode()!) : true;
  return canSelect;
}
```

**特点**:
- 支持锁定节点
- 防止误操作
- 支持自定义选择逻辑

#### 5.4.2 节点销毁的保护机制

**实现**: 检查是否已销毁

**代码**:
```typescript
purge() {
  if (this.purged) {
    return;
  }
  this.purged = true;
  this.autoruns?.forEach((dispose) => dispose());
  this.props.purge();
  this.settingEntry?.purge();
}
```

**特点**:
- 防止重复销毁
- 保护资源
- 确保一致性

## 6. 总结

Node模块是LowCodeEngine的节点模型核心，提供了：

1. **完善的节点标识**：唯一ID、组件名称
2. **强大的属性管理**：Props系统、ExtraProps
3. **灵活的子节点管理**：NodeChildren、插入、删除、移动
4. **完整的父子关系**：父子、兄弟、包含关系
5. **多样的节点类型**：Page、Component、Slot、Leaf等
6. **丰富的节点操作**：插入、删除、移动、选择、悬停
7. **灵活的Schema导入导出**：多阶段转换、条件处理
8. **完整的生命周期**：创建、初始化、销毁
9. **状态管理**：锁定、隐藏、伪状态
10. **Slot节点支持**：特殊的Slot节点管理
11. **ConditionGroup支持**：互斥节点组
12. **高效的事件系统**：可见性、子节点、属性变化事件

该模块设计精巧，功能完善，是整个低代码引擎的"节点模型核心"，负责管理所有节点级别的状态和逻辑。
