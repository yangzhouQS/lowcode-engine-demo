# LowCodeEngine API设计与实现

## 1. API设计概述

LowCodeEngine 提供了一套完整、类型安全的API体系，采用命名空间和模型两种组织方式。API设计遵循以下原则：

1. **命名空间组织**: 按功能模块划分命名空间
2. **模型对象**: 通过API返回模型对象，提供深度操作能力
3. **事件驱动**: 基于事件的松耦合设计
4. **Disposable模式**: 事件绑定返回解绑函数，避免内存泄漏
5. **Getter模式**: 属性访问使用`.xxx`而非`.getXxx()`

### 1.1 API分类

```
API体系
├── 命名空间 (Namespaces)
│   ├── init - 初始化API
│   ├── skeleton - 面板API
│   ├── material - 物料API
│   ├── project - 项目API
│   ├── canvas - 画布API
│   ├── hotkey - 快捷键API
│   ├── setters - 设置器API
│   ├── event - 事件API
│   ├── config - 配置API
│   ├── common - 通用API
│   ├── logger - 日志API
│   └── workspace - 工作空间API
└── 模型 (Models)
    ├── DocumentModel - 文档模型
    ├── Node - 节点模型
    ├── NodeChildren - 节点孩子模型
    ├── Props - 属性集模型
    ├── Prop - 属性模型
    ├── SettingField - 设置属性模型
    ├── SettingTopEntry - 设置属性集模型
    ├── ComponentMeta - 物料元数据模型
    ├── Selection - 画布选中模型
    ├── Detecting - 画布hover模型
    ├── History - 操作历史模型
    ├── Window - 低代码设计器窗口模型
    ├── ModalNodesManager - 模态节点管理器模型
    ├── PluginInstance - 插件实例模型
    └── DropLocation - 拖拽放置位置模型
```

## 2. 初始化API (init)

### 2.1 init函数

初始化引擎的核心函数，负责创建编辑器实例并启动引擎。

**函数签名**:
```typescript
function init(container?: Element, options?: IPublicTypeEngineOptions): void
```

**参数说明**:
- `container`: 可选，引擎挂载的DOM元素，默认为`document.getElementById('lce')`
- `options`: 可选，引擎初始化配置选项

**配置选项** ([`IPublicTypeEngineOptions`](https://github.com/alibaba/lowcode-engine/blob/main/packages/types/src/shell/type/engine-options.ts)):
```typescript
interface IPublicTypeEngineOptions {
  // 设计模式
  designMode?: 'design' | 'live' | 'preview';
  
  // 设备类型
  device?: 'desktop' | 'mobile' | 'iphone' | 'android';
  
  // 是否启用条件渲染
  enableCondition?: boolean;
  
  // 是否启用画布拖拽
  enableCanvasDrag?: boolean;
  
  // 默认语言
  locale?: string;
  
  // 主题
  theme?: 'light' | 'dark';
  
  // 物料描述
  assets?: IPublicTypeAssetsJson;
  
  // 组件描述
  componentMetadatas?: IPublicTypeComponentMetadata[];
  
  // 设计器配置
  designer?: DesignerProps;
  
  // 应用助手
  appHelper?: {
    utils?: Record<string, any>;
    constants?: Record<string, any>;
  };
  
  // 插件
  plugins?: PluginClassSet;
  
  // 生命周期钩子
  lifeCycles?: {
    init?: (editor: IPublicModelEditor) => void | Promise<void>;
    destroy?: (editor: IPublicModelEditor) => void;
  };
}
```

**使用示例**:

```typescript
import { init, skeleton } from '@alilc/lowcode-engine';

// 基础初始化
init(document.getElementById('lce'));

// 带配置初始化
init(document.getElementById('lce'), {
  designMode: 'design',
  device: 'desktop',
  enableCondition: true,
  locale: 'zh-CN',
  theme: 'light'
});

// 添加Logo到顶部区域
skeleton.add({
  area: 'topArea',
  type: 'Widget',
  name: 'logo',
  content: LogoComponent,
  contentProps: {
    logo: 'https://example.com/logo.png',
    href: '/',
  },
  props: {
    align: 'left',
    width: 100,
  },
});
```

**默认打开移动端画布**:
```typescript
import { init } from '@alilc/lowcode-engine';

init({
  device: 'mobile',
});
```

**使用utils第三方工具扩展**:
```typescript
import { init } from '@alilc/lowcode-engine';

init({
  device: 'mobile',
  appHelper: {
    utils: {
      formatDate: (date) => {
        return new Date(date).toLocaleDateString();
      },
      calculateAge: (birthDate) => {
        // 计算年龄逻辑
      }
    }
  }
});
```

### 2.2 初始化流程

```
调用 init()
    ↓
创建 Editor 实例
    ↓
初始化 EventBus
    ↓
加载插件 (Plugins)
    ↓
初始化 Designer
    ↓
初始化 Project
    ↓
初始化 Simulator
    ↓
初始化 Renderer
    ↓
触发 editor.afterInit 事件
    ↓
引擎就绪
```

## 3. 配置API (config)

配置模块负责引擎配置的读写操作。

### 3.1 get方法

获取指定key的值。

**函数签名**:
```typescript
get(key: string, defaultValue?: any): any;
```

**参数说明**:
- `key`: 配置键名
- `defaultValue`: 可选，默认值

**返回值**: 配置值

**使用示例**:
```typescript
import { config } from '@alilc/lowcode-engine';

// 获取配置
const enableCondition = config.get('enableCondition', true);
const theme = config.get('theme', 'light');
const customConfig = config.get('customConfig', { a: 1, b: 2 });
```

### 3.2 set方法

设置指定key的值。

**函数签名**:
```typescript
set(key: string, value: any): void;
```

**参数说明**:
- `key`: 配置键名
- `value`: 配置值

**使用示例**:
```typescript
import { config } from '@alilc/lowcode-engine';

// 设置配置
config.set('enableCondition', false);
config.set('theme', 'dark');
config.set('customKey', { data: 'value' });
```

### 3.3 has方法

判断指定key是否有值。

**函数签名**:
```typescript
has(key: string): boolean;
```

**参数说明**:
- `key`: 配置键名

**返回值**: 是否存在该配置

**使用示例**:
```typescript
import { config } from '@alilc/lowcode-engine';

// 检查配置是否存在
if (config.has('customKey')) {
  const value = config.get('customKey');
}
```

### 3.4 setConfig方法

批量设置配置。

**函数签名**:
```typescript
setConfig(config: { [key: string]: any }): void;
```

**参数说明**:
- `config`: 配置对象

**使用示例**:
```typescript
import { config } from '@alilc/lowcode-engine';

// 批量设置配置
config.setConfig({
  enableCondition: false,
  theme: 'dark',
  customKey: { data: 'value' }
});
```

### 3.5 getPreference方法

获取全局Preference管理器，用于管理浏览器侧用户偏好设置。

**函数签名**:
```typescript
getPreference(): IPublicModelPreference;
```

**返回值**: Preference管理器实例

**使用示例**:
```typescript
import { config } from '@alilc/lowcode-engine';

// 设置大纲树面板钉住状态
config.getPreference().set(
  'outline-master-pane-pinned-status-isFloat',
  false,
  'skeleton'
);

// 获取大纲树面板钉住状态
const isPinned = config.getPreference().get(
  'outline-master-pane-pinned-status-isFloat',
  'skeleton'
);
```

### 3.6 onceGot方法

获取指定key的值，若此时还未赋值则等待，只执行一次。

**函数签名**:
```typescript
onceGot(key: string): Promise<any>;
```

**参数说明**:
- `key`: 配置键名

**返回值**: Promise，解析为配置值

**使用示例**:
```typescript
import { config } from '@alilc/lowcode-engine';

// 等待配置值
config.onceGot('assets').then(value => {
  console.log('Assets loaded:', value);
});

// 使用async/await
const assets = await config.onceGot('assets');
```

### 3.7 onGot方法

获取指定key的值，函数回调模式，若多次被赋值，回调会被多次调用。

**函数签名**:
```typescript
onGot(key: string, fn: (data: any) => void): () => void;
```

**参数说明**:
- `key`: 配置键名
- `fn`: 回调函数

**返回值**: 解绑函数

**使用示例**:
```typescript
import { config } from '@alilc/lowcode-engine';

// 监听配置变化
const dispose = config.onGot('theme', (value) => {
  console.log(`Theme changed to: ${value}`);
});

// 设置配置，触发回调
config.set('theme', 'dark'); // 输出: Theme changed to: dark
config.set('theme', 'light'); // 输出: Theme changed to: light

// 取消监听
dispose();
```

## 4. 项目API (project)

项目API是引擎编排模块的入口，所有模型实例都需要通过project来获得。

### 4.1 变量

#### currentDocument

获取当前的document实例。

**类型**: `IPublicModelDocumentModel | null`

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

const currentDoc = project.currentDocument;
if (currentDoc) {
  console.log('Current document:', currentDoc.fileName);
}
```

#### documents

获取当前project下所有documents。

**类型**: `IPublicModelDocumentModel[]`

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

const allDocs = project.documents;
allDocs.forEach(doc => {
  console.log('Document:', doc.fileName);
});
```

#### simulatorHost

获取模拟器的host。

**类型**: `IPublicApiSimulatorHost | null`

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

const simulator = project.simulatorHost;
if (simulator) {
  simulator.scrollTo({ left: 0, top: 100 });
}
```

### 4.2 方法

#### openDocument

打开一个document。

**函数签名**:
```typescript
openDocument(doc?: string | IPublicTypeRootSchema): IPublicModelDocumentModel | null;
```

**参数说明**:
- `doc`: 可选，文档ID或Schema

**返回值**: DocumentModel实例

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

// 通过ID打开文档
const doc = project.openDocument('page1');

// 通过Schema打开文档
const doc = project.openDocument({
  componentName: 'Page',
  fileName: 'page1',
  props: {},
  children: []
});
```

#### createDocument

创建一个document。

**函数签名**:
```typescript
createDocument(data?: IPublicTypeRootSchema): IPublicModelDocumentModel | null;
```

**参数说明**:
- `data`: 可选，文档Schema

**返回值**: DocumentModel实例

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

const doc = project.createDocument({
  componentName: 'Page',
  fileName: 'new-page',
  props: {},
  children: []
});
```

#### removeDocument

删除一个document。

**函数签名**:
```typescript
removeDocument(doc: IPublicModelDocumentModel): void;
```

**参数说明**:
- `doc`: DocumentModel实例

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

const doc = project.currentDocument;
if (doc) {
  project.removeDocument(doc);
}
```

#### getDocumentByFileName

根据fileName获取document。

**函数签名**:
```typescript
getDocumentByFileName(fileName: string): IPublicModelDocumentModel | null;
```

**参数说明**:
- `fileName`: 文件名

**返回值**: DocumentModel实例

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

const doc = project.getDocumentByFileName('page1');
```

#### getDocumentById

根据id获取document。

**函数签名**:
```typescript
getDocumentById(id: string): IPublicModelDocumentModel | null;
```

**参数说明**:
- `id`: 文档ID

**返回值**: DocumentModel实例

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

const doc = project.getDocumentById('doc-123');
```

#### exportSchema

导出project schema。

**函数签名**:
```typescript
exportSchema(stage: IPublicEnumTransformStage): IPublicTypeProjectSchema;
```

**参数说明**:
- `stage`: 转换阶段

**返回值**: ProjectSchema

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';
import { IPublicEnumTransformStage } from '@alilc/lowcode-types';

// 导出用于渲染的Schema
const renderSchema = project.exportSchema(IPublicEnumTransformStage.Render);

// 导出用于保存的Schema
const saveSchema = project.exportSchema(IPublicEnumTransformStage.Save);

// 导出用于序列化的Schema
const serializeSchema = project.exportSchema(IPublicEnumTransformStage.Serialize);
```

#### importSchema

导入project schema。

**函数签名**:
```typescript
importSchema(schema?: IPublicTypeProjectSchema): void;
```

**参数说明**:
- `schema`: 待导入的project数据

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

// 导入Schema
project.importSchema({
  componentName: 'Page',
  fileName: 'imported-page',
  props: {},
  children: []
});
```

#### addPropsTransducer

增加一个属性的管道处理函数。

**函数签名**:
```typescript
addPropsTransducer(
  transducer: IPublicTypePropsTransducer,
  stage: IPublicEnumTransformStage
): void;
```

**参数说明**:
- `transducer`: 属性转换函数
- `stage`: 转换阶段

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';
import { IPublicEnumTransformStage } from '@alilc/lowcode-types';

// 在保存时删除每一个组件的props.hidden
project.addPropsTransducer((props) => {
  delete props.hidden;
  return props;
}, IPublicEnumTransformStage.Save);
```

#### setI18n

设置多语言语料。

**函数签名**:
```typescript
setI18n(value: object): void;
```

**参数说明**:
- `value`: 国际化数据对象

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

project.setI18n({
  'zh-CN': {
    'button.save': '保存',
    'button.cancel': '取消'
  },
  'en-US': {
    'button.save': 'Save',
    'button.cancel': 'Cancel'
  }
});
```

#### setConfig

设置当前项目配置。

**函数签名**:
```typescript
setConfig(value: IPublicTypeAppConfig): void;
setConfig<T extends keyof IPublicTypeAppConfig>(key: T, value: IPublicTypeAppConfig[T]): void;
```

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

// 设置整个配置
project.setConfig({
  customProp: 'value'
});

// 设置单个配置项
project.setConfig('customProp', 'value');
```

### 4.3 事件

#### onRemoveDocument

绑定删除文档事件。

**函数签名**:
```typescript
onRemoveDocument(fn: (data: { id: string }) => void): IPublicTypeDisposable;
```

**参数说明**:
- `fn`: 回调函数

**返回值**: Disposable对象

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

const dispose = project.onRemoveDocument((data) => {
  console.log('Document removed:', data.id);
});

// 取消监听
dispose();
```

#### onChangeDocument

当前project内的document变更事件。

**函数签名**:
```typescript
onChangeDocument(fn: (doc: IPublicModelDocumentModel) => void): IPublicTypeDisposable;
```

**参数说明**:
- `fn`: 回调函数

**返回值**: Disposable对象

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

const dispose = project.onChangeDocument((doc) => {
  console.log('Document changed:', doc.fileName);
});

// 取消监听
dispose();
```

#### onSimulatorHostReady

当前project的模拟器ready事件。

**函数签名**:
```typescript
onSimulatorHostReady(fn: (host: IPublicApiSimulatorHost) => void): IPublicTypeDisposable;
```

**参数说明**:
- `fn`: 回调函数

**返回值**: Disposable对象

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

const dispose = project.onSimulatorHostReady((host) => {
  console.log('Simulator ready:', host);
});

// 取消监听
dispose();
```

#### onSimulatorRendererReady

当前project的渲染器ready事件。

**函数签名**:
```typescript
onSimulatorRendererReady(fn: () => void): IPublicTypeDisposable;
```

**参数说明**:
- `fn`: 回调函数

**返回值**: Disposable对象

**使用示例**:
```typescript
import { project } from '@alilc/lowcode-engine';

const dispose = project.onSimulatorRendererReady(() => {
  console.log('Renderer ready');
});

// 取消监听
dispose();
```

## 5. 画布API (canvas)

画布API提供对画布拖拽相关的能力。

### 5.1 变量

#### dragon

获取拖拽操作对象的实例。

**类型**: `IPublicModelDragon | null`

**使用示例**:
```typescript
import { canvas } from '@alilc/lowcode-engine';

const dragon = canvas.dragon;
if (dragon) {
  // 使用dragon进行拖拽操作
}
```

#### activeTracker

获取活动追踪器实例。

**类型**: `IPublicModelActiveTracker | null`

**使用示例**:
```typescript
import { canvas } from '@alilc/lowcode-engine';

const tracker = canvas.activeTracker;
if (tracker) {
  // 使用tracker追踪活动节点
}
```

#### isInLiveEditing

是否处于LiveEditing状态。

**类型**: `boolean`

**使用示例**:
```typescript
import { canvas } from '@alilc/lowcode-engine';

if (canvas.isInLiveEditing) {
  console.log('Currently in live editing mode');
}
```

#### clipboard

全局剪贴板实例。

**类型**: `IPublicModelClipboard`

**使用示例**:
```typescript
import { canvas } from '@alilc/lowcode-engine';

// 复制节点
canvas.clipboard.copy([node1, node2]);

// 粘贴节点
canvas.clipboard.paste();
```

### 5.2 方法

#### createLocation

创建一个文档插入位置对象。

**函数签名**:
```typescript
createLocation(locationData: IPublicTypeLocationData): IPublicModelDropLocation;
```

**参数说明**:
- `locationData`: 位置数据

**返回值**: DropLocation实例

**使用示例**:
```typescript
import { canvas } from '@alilc/lowcode-engine';

const location = canvas.createLocation({
  target: node,
  detail: {
    type: 'Children',
    index: 0
  }
});
```

#### createScroller

创建一个滚动控制器Scroller。

**函数签名**:
```typescript
createScroller(scrollable: IPublicTypeScrollable): IPublicModelScroller;
```

**参数说明**:
- `scrollable`: 可滚动对象

**返回值**: Scroller实例

**使用示例**:
```typescript
import { canvas } from '@alilc/lowcode-engine';

const scroller = canvas.createScroller({
  scrollTarget: document.getElementById('scroll-container')
});

// 滚动到指定位置
scroller.scrollTo({ left: 0, top: 100 });
```

#### createScrollTarget

创建一个ScrollTarget。

**函数签名**:
```typescript
createScrollTarget(shell: HTMLDivElement): IPublicModelScrollTarget;
```

**参数说明**:
- `shell`: DOM元素

**返回值**: ScrollTarget实例

## 6. 物料API (material)

物料API负责物料相关的操作，包括资产包、设计器辅助层、物料元数据等。

### 6.1 变量

#### componentsMap

获取组件map结构。

**类型**: `{ [key: string]: IPublicTypeNpmInfo | ComponentType<any> | object }`

**使用示例**:
```typescript
import { material } from '@alilc/lowcode-engine';

const componentsMap = material.componentsMap;
console.log('Available components:', Object.keys(componentsMap));
```

### 6.2 方法

#### setAssets

设置资产包结构。

**函数签名**:
```typescript
setAssets(assets: IPublicTypeAssetsJson): void;
```

**参数说明**:
- `assets`: 资产包数据

**使用示例**:
```typescript
import { material } from '@alilc/lowcode-engine';
import assets from '@alilc/mc-assets-<siteId>/assets.json';

// 直接在项目中引用npm包
material.setAssets(assets);
```

动态加载资产包:
```typescript
import { material } from '@alilc/lowcode-engine';

// 通过接口动态引入资产包
const res = await window.fetch('https://fusion.alicdn.com/assets/default@0.1.95/assets.json');
const assets = await res.text();
material.setAssets(JSON.parse(assets));
```

#### getAssets

获取资产包结构。

**函数签名**:
```typescript
getAssets(): IPublicTypeAssetsJson;
```

**返回值**: 资产包数据

**使用示例**:
```typescript
import { material } from '@alilc/lowcode-engine';

const assets = material.getAssets();
console.log('Current assets:', assets);
```

#### loadIncrementalAssets

加载增量的资产包结构。

**函数签名**:
```typescript
loadIncrementalAssets(incrementalAssets: IPublicTypeAssetsJson): Promise<void>;
```

**参数说明**:
- `incrementalAssets`: 增量资产包数据

**使用示例**:
```typescript
import { material } from '@alilc/lowcode-engine';
import assets1 from '@alilc/mc-assets-<siteId>/assets.json';
import assets2 from '@alilc/mc-assets-<siteId>/assets.json';

material.setAssets(assets1);
material.loadIncrementalAssets(assets2);
```

更新特定物料的描述文件:
```typescript
import { material } from '@alilc/lowcode-engine';

material.loadIncrementalAssets({
  version: '',
  components: [
    {
      "componentName": 'Button',
      "props": [{ name: 'new', title: 'new', propType: 'string' }]
    }
  ],
});
```

#### addBuiltinComponentAction

在设计器辅助层增加一个扩展action。

**函数签名**:
```typescript
addBuiltinComponentAction(action: IPublicTypeComponentAction): void;
```

**参数说明**:
- `action`: 组件操作配置

**使用示例**:
```typescript
import { material } from '@alilc/lowcode-engine';

material.addBuiltinComponentAction({
  name: 'myIconName',
  content: {
    icon: () => 'x',
    title: 'hover title',
    action(node) {
      console.log('myIconName 扩展位被点击');
    }
  },
  important: true,
  condition: true,
});
```

#### removeBuiltinComponentAction

移除设计器辅助层的指定action。

**函数签名**:
```typescript
removeBuiltinComponentAction(name: string): void;
```

**参数说明**:
- `name`: action名称

**内置action名称**:
- `remove`: 删除
- `hide`: 隐藏
- `copy`: 复制
- `lock`: 锁定
- `unlock`: 解锁

**使用示例**:
```typescript
import { material } from '@alilc/lowcode-engine';

material.removeBuiltinComponentAction('myIconName');
```

#### modifyBuiltinComponentAction

修改已有的设计器辅助层的指定action。

**函数签名**:
```typescript
modifyBuiltinComponentAction(
  actionName: string,
  handle: (action: IPublicTypeComponentAction) => void
): void;
```

**参数说明**:
- `actionName`: action名称
- `handle`: 修改函数

**使用示例**:
```typescript
import { material } from '@alilc/lowcode-engine';

// 给原始的remove扩展时间添加执行前后的日志
material.modifyBuiltinComponentAction('remove', (action) => {
  const originAction = action.content.action;
  action.content.action = (node) => {
    console.log('before remove!');
    originAction(node);
    console.log('after remove!');
  }
});
```

#### addContextMenuOption

添加右键菜单项。

**函数签名**:
```typescript
addContextMenuOption(action: IPublicTypeContextMenuAction): void;
```

**参数说明**:
- `action`: 菜单项配置

**使用示例**:
```typescript
import { material } from '@alilc/lowcode-engine';
import { IPublicEnumContextMenuType } from '@alilc/lowcode-types';

material.addContextMenuOption({
  name: 'parentItem',
  title: 'Parent Item',
  condition: (nodes) => true,
  items: [
    {
      name: 'childItem1',
      title: 'Child Item 1',
      action: (nodes) => console.log('Child Item 1 clicked', nodes),
      condition: (nodes) => true
    },
    // 分割线
    {
      type: IPublicEnumContextMenuType.SEPARATOR,
      name: 'separator.1'
    }
  ]
});
```

#### removeContextMenuOption

删除特定右键菜单项。

**函数签名**:
```typescript
removeContextMenuOption(name: string): void;
```

**参数说明**:
- `name`: 菜单项名称

#### adjustContextMenuLayout

调整右键菜单项布局。

**函数签名**:
```typescript
adjustContextMenuLayout(fn: (actions: IPublicTypeContextMenuItem[]) => IPublicTypeContextMenuItem[]): void;
```

**参数说明**:
- `fn`: 布局调整函数

**使用示例**:
```typescript
import { material } from '@alilc/lowcode-engine';

// 通过adjustContextMenuLayout补充分割线
material.adjustContextMenuLayout((actions) => {
  const names = ['a', 'b'];
  const newActions = [];
  actions.forEach(d => {
    newActions.push(d);
    if (names.includes(d.name)) {
      newActions.push({ type: 'separator' });
    }
  });
  return newActions;
});
```

#### getComponentMeta

获取指定名称的物料元数据。

**函数签名**:
```typescript
getComponentMeta(componentName: string): IPublicModelComponentMeta | null;
```

**参数说明**:
- `componentName`: 组件名称

**返回值**: 组件元数据

**使用示例**:
```typescript
import { material } from '@alilc/lowcode-engine';

const meta = material.getComponentMeta('Button');
if (meta) {
  console.log('Component title:', meta.title);
  console.log('Component description:', meta.description);
}
```

#### getComponentMetasMap

获取所有已注册的物料元数据。

**函数签名**:
```typescript
getComponentMetasMap(): Map<string, IPublicModelComponentMeta>;
```

**返回值**: 组件元数据Map

**使用示例**:
```typescript
import { material } from '@alilc/lowcode-engine';

const metasMap = material.getComponentMetasMap();
metasMap.forEach((meta, componentName) => {
  console.log(`${componentName}: ${meta.title}`);
});
```

#### refreshComponentMetasMap

刷新componentMetasMap，可触发模拟器里的components重新构建。

**函数签名**:
```typescript
refreshComponentMetasMap(): void;
```

**使用示例**:
```typescript
import { material } from '@alilc/lowcode-engine';

material.refreshComponentMetasMap();
```

#### registerMetadataTransducer

注册物料元数据管道函数。

**函数签名**:
```typescript
registerMetadataTransducer(
  transducer: IPublicTypeMetadataTransducer,
  level?: number,
  id?: string
): void;
```

**参数说明**:
- `transducer`: 元数据转换函数
- `level`: 执行级别
- `id`: 转换器ID

**使用示例**:
```typescript
import { material } from '@alilc/lowcode-engine';

// 给每一个组件的配置添加高级配置面板
function addonCombine(metadata) {
  const { componentName, configure = {} } = metadata;
  const advanceGroup = [];
  const combined = [];

  advanceGroup.push({
    name: 'condition',
    title: { type: 'i18n', 'zh-CN': '是否渲染', 'en-US': 'Condition' },
    defaultValue: true,
    setter: [
      { componentName: 'BoolSetter' },
      { componentName: 'VariableSetter' },
    ],
    extraProps: {
      display: 'block',
    },
  });

  combined.push({
    name: '#advanced',
    title: { type: 'i18n', 'zh-CN': '高级', 'en-US': 'Advanced' },
    items: advanceGroup,
  });

  return {
    ...metadata,
    configure: {
      ...configure,
      combined,
    },
  };
}

material.registerMetadataTransducer(addonCombine, 1, 'parse-func');
```

#### getRegisteredMetadataTransducers

获取所有物料元数据管道函数。

**函数签名**:
```typescript
getRegisteredMetadataTransducers(): IPublicTypeMetadataTransducer[];
```

**返回值**: 元数据转换器数组

### 6.3 事件

#### onChangeAssets

监听assets变化的事件。

**函数签名**:
```typescript
onChangeAssets(fn: () => void): IPublicTypeDisposable;
```

**参数说明**:
- `fn`: 回调函数

**返回值**: Disposable对象

**使用示例**:
```typescript
import { material } from '@alilc/lowcode-engine';

const dispose = material.onChangeAssets(() => {
  console.log('Assets changed');
});

// 取消监听
dispose();
```

## 7. 设置器API (setters)

设置器API负责注册和管理设置器。

### 7.1 方法

#### getSetter

获取指定setter。

**函数签名**:
```typescript
getSetter(type: string): IPublicTypeRegisteredSetter | null;
```

**参数说明**:
- `type`: setter类型

**返回值**: 注册的setter

**使用示例**:
```typescript
import { setters } from '@alilc/lowcode-engine';

const stringSetter = setters.getSetter('StringSetter');
```

#### getSettersMap

获取已注册的所有settersMap。

**函数签名**:
```typescript
getSettersMap(): Map<string, IPublicTypeRegisteredSetter & { type: string }>;
```

**返回值**: setters Map

**使用示例**:
```typescript
import { setters } from '@alilc/lowcode-engine';

const settersMap = setters.getSettersMap();
settersMap.forEach((setter, type) => {
  console.log(`Setter: ${type}`);
});
```

#### registerSetter

注册一个setter。

**函数签名**:
```typescript
registerSetter(
  typeOrMaps: string | { [key: string]: IPublicTypeCustomView | IPublicTypeRegisteredSetter },
  setter?: IPublicTypeCustomView | IPublicTypeRegisteredSetter
): void;
```

**参数说明**:
- `typeOrMaps`: setter类型或setter映射
- `setter`: setter实现

**使用示例**:
```typescript
import { setters } from '@alilc/lowcode-engine';

// 注册单个setter
setters.registerSetter('AltStringSetter', AltStringSetter);

// 批量注册setter
setters.registerSetter({
  'StringSetter': StringSetter,
  'NumberSetter': NumberSetter,
  'ColorSetter': ColorSetter
});
```

### 7.2 开发自定义Setter

**Setter组件示例**:
```typescript
import * as React from "react";
import { Input } from "@alifd/next";

interface AltStringSetterProps {
  // 当前值
  value: string;
  // 默认值
  initialValue: string;
  // setter唯一输出
  onChange: (val: string) => void;
  // AltStringSetter特殊配置
  placeholder: string;
}

export default class AltStringSetter extends React.PureComponent<AltStringSetterProps> {
  componentDidMount() {
    const { onChange, value, defaultValue } = this.props;
    if (value == undefined && defaultValue) {
      onChange(defaultValue);
    }
  }

  // 声明Setter的title
  static displayName = 'AltStringSetter';

  render() {
    const { onChange, value, placeholder } = this.props;
    return (
      <Input
        value={value}
        placeholder={placeholder || ""}
        onChange={(val: any) => onChange(val)}
      />
    );
  }
}
```

**注册Setter**:
```typescript
import AltStringSetter from './AltStringSetter';
import { setters } from '@alilc/lowcode-engine';

setters.registerSetter('AltStringSetter', AltStringSetter);
```

**在物料中使用Setter**:
```typescript
{
  "componentName": "Message",
  "title": "Message",
  "props": [
    {
      "name": "title",
      "propType": "string",
      "description": "标题",
      "defaultValue": "标题"
    }
  ],
  "configure": {
    "props": {
      "isExtends": true,
      "override": [
        {
          "name": "title",
          "setter": "AltStringSetter"
        }
      ]
    }
  }
}
```

## 8. 事件API (event)

事件API负责事件处理，支持自定义监听事件、触发事件。

### 8.1 方法

#### on

监听事件。

**函数签名**:
```typescript
on(event: string, listener: (...args: any[]) => void): IPublicTypeDisposable;
```

**参数说明**:
- `event`: 事件名称
- `listener`: 事件回调

**返回值**: Disposable对象

**使用示例**:
```typescript
import { event } from '@alilc/lowcode-engine';

// 监听事件
const dispose = event.on('common:myEvent', (data) => {
  console.log('Event triggered:', data);
});

// 取消监听
dispose();
```

#### prependListener

监听事件，会在其他回调函数之前执行。

**函数签名**:
```typescript
prependListener(event: string, listener: (...args: any[]) => void): IPublicTypeDisposable;
```

**参数说明**:
- `event`: 事件名称
- `listener`: 事件回调

**返回值**: Disposable对象

#### off

取消监听事件。

**函数签名**:
```typescript
off(event: string, listener: (...args: any[]) => void): void;
```

**参数说明**:
- `event`: 事件名称
- `listener`: 事件回调

#### emit

触发事件。

**函数签名**:
```typescript
emit(event: string, ...args: any[]): void;
```

**参数说明**:
- `event`: 事件名称
- `args`: 事件参数

**使用示例**:
```typescript
import { event } from '@alilc/lowcode-engine';

// 触发事件
event.emit('myEvent', { data: 'value' });
```

### 8.2 Setter和Plugin之间的联动

**在A setter中进行事件注册**:
```typescript
import { event } from '@alilc/lowcode-engine';

const SETTER_NAME = 'SetterA';

class SetterA extends React.Component {
  componentDidMount() {
    // 使用field.id来标记setter
    this.emitEventName = `${SETTER_NAME}-${this.props.field.id}`;
    event.on(`common:${this.emitEventName}.bindEvent`, this.bindEvent);
  }

  bindEvent = (eventName) => {
    // do something
  }

  componentWillUnmount() {
    // setter销毁时需要把事件也注销掉
    event.off(`common:${this.emitEventName}.bindEvent`, this.bindEvent);
  }
}
```

**在B setter中触发事件**:
```typescript
import { event } from '@alilc/lowcode-engine';

class SetterB extends React.Component {
  bindFunction = () => {
    const { field, value } = this.props;
    // 触发事件与插件进行通信
    event.emit('eventBindDialog.openDialog', field.name, this.emitEventName);
  }
}
```

## 9. 骨架API (skeleton)

骨架API负责面板和布局管理。

### 9.1 方法

#### add

添加面板。

**函数签名**:
```typescript
add(config: SkeletonConfig): void;
```

**参数说明**:
- `config`: 面板配置

**面板区域**:
- `topArea`: 顶部区域
- `leftArea`: 左侧区域
- `rightArea`: 右侧区域
- `bottomArea`: 底部区域
- `mainArea`: 主区域

**使用示例**:
```typescript
import { skeleton } from '@alilc/lowcode-engine';

// 添加Logo到顶部区域
skeleton.add({
  area: 'topArea',
  type: 'Widget',
  name: 'logo',
  content: LogoComponent,
  contentProps: {
    logo: 'https://example.com/logo.png',
    href: '/',
  },
  props: {
    align: 'left',
    width: 100,
  },
});

// 添加组件库到左侧区域
skeleton.add({
  area: 'leftArea',
  type: 'Panel',
  name: 'components',
  title: '组件库',
  content: ComponentPanel,
  props: {
    width: 300,
  },
});
```

#### remove

移除面板。

**函数签名**:
```typescript
remove(name: string): void;
```

**参数说明**:
- `name`: 面板名称

## 10. 快捷键API (hotkey)

快捷键API负责快捷键管理。

### 10.1 方法

#### bind

绑定快捷键。

**函数签名**:
```typescript
bind(key: string, handler: (e: KeyboardEvent) => void, options?: HotkeyOptions): () => void;
```

**参数说明**:
- `key`: 快捷键组合
- `handler`: 处理函数
- `options`: 配置选项

**返回值**: 解绑函数

**使用示例**:
```typescript
import { hotkey } from '@alilc/lowcode-engine';

// 绑定Ctrl+S保存
const dispose = hotkey.bind('mod+s', (e) => {
  e.preventDefault();
  console.log('Save triggered');
});

// 取消绑定
dispose();
```

## 11. 插件API (plugins)

插件API负责插件管理。

### 11.1 方法

#### register

注册插件。

**函数签名**:
```typescript
register(plugin: PluginClass): Promise<void>;
```

**参数说明**:
- `plugin`: 插件类

**使用示例**:
```typescript
import { plugins } from '@alilc/lowcode-engine';
import { IPublicModelPluginContext } from '@alilc/lowcode-types';

const MyPlugin = (ctx: IPublicModelPluginContext) => {
  return {
    name: 'my-plugin',
    async init() {
      console.log('Plugin initialized');
    },
  };
};

MyPlugin.pluginName = 'MyPlugin';
await plugins.register(MyPlugin);
```

## 12. API设计约定

### 12.1 命名规范

1. 所有API命名空间都按照variables / functions / events来组织
2. 事件的命名格式为：`on[Will|Did]VerbNoun?`
3. 基于Disposable模式，事件绑定返回解绑函数
4. 属性导出统一用`.xxx`的getter模式，不使用`.getXxx()`

### 12.2 事件命名规范

```
editor.beforeInit     // 编辑器初始化前
editor.afterInit      // 编辑器初始化后
designer.dragstart    // 拖拽开始
designer.drag         // 拖拽中
designer.dragend      // 拖拽结束
document.change       // 文档变化
selection.change     // 选择变化
```

### 12.3 Disposable模式

所有事件绑定都返回Disposable对象，用于取消监听：

```typescript
const dispose = event.on('myEvent', handler);

// 取消监听
dispose();
```

## 13. 总结

LowCodeEngine 提供了一套完整、类型安全的API体系，涵盖：

1. **初始化API**: 引擎初始化和配置
2. **配置API**: 配置管理
3. **项目API**: 项目和文档管理
4. **画布API**: 画布拖拽和操作
5. **物料API**: 物料管理和元数据
6. **设置器API**: 设置器注册和管理
7. **事件API**: 事件处理
8. **骨架API**: 面板和布局管理
9. **快捷键API**: 快捷键管理
10. **插件API**: 插件管理

所有API都遵循统一的设计约定，提供一致的开发体验。完整的类型定义确保了类型安全，Disposable模式避免了内存泄漏。
